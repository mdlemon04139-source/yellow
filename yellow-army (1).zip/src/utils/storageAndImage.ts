/**
 * Global in-memory cache to guarantee that user-uploaded photos are NEVER lost
 * even across page re-renders, storage quota limits, or auth transitions.
 */
export const inMemoryImageStore = new Map<string, { avatarUrl?: string; coverUrl?: string }>();

/**
 * Detects if a URL is a real user-uploaded or custom photo rather than a placeholder/cartoon
 */
export const isUserCustomPhoto = (url?: string): boolean => {
  if (!url || typeof url !== 'string' || url.trim().length === 0) return false;
  const trimmed = url.trim();
  // Filter out cartoon SVG placeholders
  if (trimmed.includes('data:image/svg') || trimmed.includes('<svg')) return false;
  // Filter out default placeholder template unsplash images
  if (
    trimmed.includes('photo-1534528741775') ||
    trimmed.includes('photo-1507003211169') ||
    trimmed.includes('photo-1500648767791')
  ) {
    return false;
  }
  // User uploaded base64 data URL (JPEG, PNG, WEBP)
  if (trimmed.startsWith('data:image/')) return true;
  // Firebase Storage / Cloudinary / Google user content / custom URLs
  if (
    trimmed.includes('firebasestorage') ||
    trimmed.includes('storage.googleapis.com') ||
    trimmed.includes('cloudinary') ||
    trimmed.includes('googleusercontent.com')
  ) {
    return true;
  }
  // Any external valid URL
  return trimmed.startsWith('http://') || trimmed.startsWith('https://');
};

/**
 * Detects if a URL is a real user-uploaded cover rather than default cover
 */
export const isUserCustomCover = (url?: string): boolean => {
  if (!url || typeof url !== 'string' || url.trim().length === 0) return false;
  const trimmed = url.trim();
  const defaultCover = 'photo-1579783900882';
  if (trimmed.includes(defaultCover)) return false;
  if (trimmed.startsWith('data:image/')) return true;
  if (
    trimmed.includes('firebasestorage') ||
    trimmed.includes('storage.googleapis.com') ||
    trimmed.includes('cloudinary')
  ) {
    return true;
  }
  return trimmed.startsWith('http://') || trimmed.startsWith('https://');
};

/**
 * Helper to recursively trim oversized payloads if quota is exceeded without destroying user photos
 */
function pruneOversizedBlobs(obj: any): any {
  if (!obj) return obj;
  return obj;
}

/**
 * Safe local storage utilities that gracefully handle QuotaExceededError and corrupted data
 */
export const safeStorage = {
  getItem: <T = string>(key: string, fallback: T | null = null): T | null => {
    try {
      const item = localStorage.getItem(key);
      if (item === null) return fallback;
      try {
        return JSON.parse(item) as T;
      } catch {
        return item as unknown as T;
      }
    } catch (e) {
      console.warn(`[SafeStorage] Error reading key "${key}":`, e);
      return fallback;
    }
  },

  setItem: (key: string, value: unknown): boolean => {
    try {
      const serialized = typeof value === 'string' ? value : JSON.stringify(value);
      localStorage.setItem(key, serialized);
      return true;
    } catch (e) {
      console.warn(`[SafeStorage] QuotaExceeded or write error for key "${key}", applying resilient recovery:`, e);
      try {
        // 1. Clear non-critical high-volume cache keys first
        localStorage.removeItem('yellow_army_activities');
        localStorage.removeItem('yellow_army_broadcasts');
        localStorage.removeItem('yellow_army_notifications');

        const serialized = typeof value === 'string' ? value : JSON.stringify(value);
        localStorage.setItem(key, serialized);
        return true;
      } catch (recoveryErr) {
        console.warn(`[SafeStorage] Secondary write failure for key "${key}":`, recoveryErr);
        return false;
      }
    }
  },

  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.warn(`[SafeStorage] Error removing key "${key}":`, e);
    }
  },
};

/**
 * Normalizes phone numbers for duplicate detection (extracts clean digits, takes last 10 digits for BD)
 */
export const normalizePhoneDigits = (phone?: string): string => {
  if (!phone) return '';
  const digits = phone.replace(/\D/g, '');
  if (digits.length >= 10) {
    return digits.slice(-10); // Matches e.g. 1712345678 across 01712345678 and +8801712345678
  }
  return digits;
};

/**
 * Normalizes email for case-insensitive matching
 */
export const normalizeEmail = (email?: string): string => {
  return (email || '').trim().toLowerCase();
};

/**
 * Deduplicate an array of objects by their `id` property
 */
export const deduplicateById = <T extends { id?: string }>(items: T[]): T[] => {
  if (!Array.isArray(items)) return [];
  const seen = new Set<string>();
  const result: T[] = [];

  for (const item of items) {
    if (!item) continue;
    const id = item.id;
    if (id) {
      if (!seen.has(id)) {
        seen.add(id);
        result.push(item);
      }
    } else {
      result.push(item);
    }
  }

  return result;
};

/**
 * Advanced canonical deduplication and merging for Volunteer accounts.
 * Eliminates duplicate/cloned profiles by unifying records matching email, phone digits, or ID code.
 * Returns merged canonical volunteer list AND an array of duplicate Firestore document IDs to purge.
 */
export const mergeAndDeduplicateVolunteers = (
  volunteers: any[]
): { merged: any[]; duplicateIdsToDelete: string[] } => {
  if (!Array.isArray(volunteers)) return { merged: [], duplicateIdsToDelete: [] };

  const canonicalList: any[] = [];
  const duplicateIdsToDelete: string[] = [];

  for (const candidate of volunteers) {
    if (!candidate || !candidate.id) continue;

    const candEmail = normalizeEmail(candidate.email);

    // Skip deleted legacy mock vol-super-admin-alt account so it never appears in the army list
    if (candidate.id === 'vol-super-admin-alt') {
      duplicateIdsToDelete.push(candidate.id);
      continue;
    }

    const candPhone = normalizePhoneDigits(candidate.mobileNo);
    const candIdCode = (candidate.volunteerIdCode || '').trim().toUpperCase();
    const candName = (candidate.fullName || '').trim().toLowerCase();

    // Check if matching record already exists in canonicalList
    // CRITICAL: Distinct users MUST NEVER be merged by phone, name, or volunteerIdCode.
    // Only merge if they share the exact same user ID / Firebase UID or exact same verified email.
    const matchIndex = canonicalList.findIndex((existing) => {
      // 1. Direct ID or Firebase UID match
      if (existing.id && candidate.id && existing.id === candidate.id) return true;
      if (existing.firebaseUid && candidate.firebaseUid && existing.firebaseUid === candidate.firebaseUid) return true;
      if (existing.id && candidate.firebaseUid && existing.id === candidate.firebaseUid) return true;
      if (existing.firebaseUid && candidate.id && existing.firebaseUid === candidate.id) return true;

      // 2. Exact email match (if valid real email and not a placeholder)
      if (
        candEmail &&
        candEmail.includes('@') &&
        !candEmail.includes('placeholder') &&
        !candEmail.includes('volunteer_') &&
        normalizeEmail(existing.email) === candEmail
      ) {
        return true;
      }

      return false;
    });

    if (matchIndex === -1) {
      // No duplicate found yet, add candidate
      canonicalList.push({ ...candidate });
    } else {
      // DUPLICATE FOUND: Merge candidate with existing
      const existing = canonicalList[matchIndex];

      // Decide canonical ID (prefer super-admin or one with Board Member or oldest)
      const isCandidateSuper =
        candidate.id === 'vol-super-admin' ||
        candidate.adminRole === 'Super Admin' ||
        candidate.email?.toLowerCase() === 'admin.yellownetwork@gmail.com' ||
        candidate.email?.toLowerCase() === 'yellownetwork@gmail.com' ||
        candidate.email?.toLowerCase() === 'mdrahat73184@gmail.com';

      const isExistingSuper =
        existing.id === 'vol-super-admin' ||
        existing.adminRole === 'Super Admin' ||
        existing.email?.toLowerCase() === 'admin.yellownetwork@gmail.com' ||
        existing.email?.toLowerCase() === 'yellownetwork@gmail.com' ||
        existing.email?.toLowerCase() === 'mdrahat73184@gmail.com';

      const isCandidateRealAuth = typeof candidate.id === 'string' && candidate.id.length > 20 && !candidate.id.startsWith('vol-');
      const isExistingRealAuth = typeof existing.id === 'string' && existing.id.length > 20 && !existing.id.startsWith('vol-');

      let canonical = existing;
      let nonCanonical = candidate;

      if (isCandidateSuper && !isExistingSuper) {
        canonical = candidate;
        nonCanonical = existing;
      } else if (isExistingSuper && !isCandidateSuper) {
        canonical = existing;
        nonCanonical = candidate;
      } else if (isCandidateRealAuth && !isExistingRealAuth) {
        canonical = candidate;
        nonCanonical = existing;
      } else if (isExistingRealAuth && !isCandidateRealAuth) {
        canonical = existing;
        nonCanonical = candidate;
      }

      // Track duplicate ID for permanent deletion from Firestore (NEVER delete real Firebase Auth UIDs)
      const isNonCanonicalRealAuth = typeof nonCanonical.id === 'string' && (nonCanonical.id.length > 20 && !nonCanonical.id.startsWith('vol-') && !nonCanonical.id.startsWith('mock-'));
      if (nonCanonical.id && nonCanonical.id !== canonical.id && !isNonCanonicalRealAuth && nonCanonical.id.startsWith('vol-')) {
        duplicateIdsToDelete.push(nonCanonical.id);
      }

      const isTargetPermanentAdmin = isCandidateSuper || isExistingSuper;

      // Merge fields into unified record
      const unified = {
        ...nonCanonical,
        ...canonical,
        // Canonical record holds the authoritative source of truth for role
        roleInVBD: canonical.roleInVBD || nonCanonical.roleInVBD || 'General Member',
        // Board type strictly applies when role is Board Member
        boardType:
          (canonical.roleInVBD === 'Board Member' || (!canonical.roleInVBD && nonCanonical.roleInVBD === 'Board Member'))
            ? (canonical.boardType || nonCanonical.boardType || 'Upazila Board')
            : undefined,
        adminRole: isTargetPermanentAdmin
          ? 'Super Admin'
          : (canonical.adminRole || nonCanonical.adminRole || 'General Member'),
        // Pending roles are respected from the authoritative record
        pendingRole: canonical.pendingRole !== undefined ? canonical.pendingRole : nonCanonical.pendingRole,
        pendingBoardType: canonical.pendingBoardType !== undefined ? canonical.pendingBoardType : nonCanonical.pendingBoardType,
        // Preserve canonical scores so deductions and real-time adjustments are not overwritten by Math.max
        xp: typeof canonical.xp === 'number'
          ? canonical.xp
          : typeof canonical.volunteeringScore === 'number'
          ? canonical.volunteeringScore
          : (nonCanonical.xp ?? nonCanonical.volunteeringScore ?? 0),
        volunteeringScore: typeof canonical.xp === 'number'
          ? canonical.xp
          : typeof canonical.volunteeringScore === 'number'
          ? canonical.volunteeringScore
          : (nonCanonical.xp ?? nonCanonical.volunteeringScore ?? 0),
        dhp: typeof canonical.dhp === 'number'
          ? canonical.dhp
          : typeof canonical.dhpPoints === 'number'
          ? canonical.dhpPoints
          : (nonCanonical.dhp ?? nonCanonical.dhpPoints ?? 0),
        dhpPoints: typeof canonical.dhp === 'number'
          ? canonical.dhp
          : typeof canonical.dhpPoints === 'number'
          ? canonical.dhpPoints
          : (nonCanonical.dhp ?? nonCanonical.dhpPoints ?? 0),
        totalVolunteerHours: Math.max(canonical.totalVolunteerHours || 0, nonCanonical.totalVolunteerHours || 0),
        projectsAttendedCount: Math.max(canonical.projectsAttendedCount || 0, nonCanonical.projectsAttendedCount || 0),
        // Richest details: prioritize real user uploaded custom photos over default placeholders
        avatarUrl: (() => {
          const memoryPhotos =
            inMemoryImageStore.get(canonical.id) ||
            inMemoryImageStore.get(nonCanonical.id) ||
            inMemoryImageStore.get((canonical.email || '').toLowerCase()) ||
            inMemoryImageStore.get((nonCanonical.email || '').toLowerCase());

          let chosenAvatar = '';
          if (isUserCustomPhoto(canonical.avatarUrl)) {
            chosenAvatar = canonical.avatarUrl;
          } else if (isUserCustomPhoto(nonCanonical.avatarUrl)) {
            chosenAvatar = nonCanonical.avatarUrl;
          } else if (memoryPhotos?.avatarUrl && isUserCustomPhoto(memoryPhotos.avatarUrl)) {
            chosenAvatar = memoryPhotos.avatarUrl;
          } else if (canonical.avatarUrl && !canonical.avatarUrl.includes('data:image/svg') && !canonical.avatarUrl.includes('photo-15')) {
            chosenAvatar = canonical.avatarUrl;
          } else if (nonCanonical.avatarUrl && !nonCanonical.avatarUrl.includes('data:image/svg') && !nonCanonical.avatarUrl.includes('photo-15')) {
            chosenAvatar = nonCanonical.avatarUrl;
          } else {
            chosenAvatar = canonical.avatarUrl || nonCanonical.avatarUrl || '';
          }

          if (isUserCustomPhoto(chosenAvatar)) {
            if (canonical.id) inMemoryImageStore.set(canonical.id, { ...(inMemoryImageStore.get(canonical.id) || {}), avatarUrl: chosenAvatar });
            if (canonical.email) inMemoryImageStore.set(canonical.email.toLowerCase(), { ...(inMemoryImageStore.get(canonical.email.toLowerCase()) || {}), avatarUrl: chosenAvatar });
          }
          return chosenAvatar;
        })(),
        coverUrl: (() => {
          const memoryPhotos =
            inMemoryImageStore.get(canonical.id) ||
            inMemoryImageStore.get(nonCanonical.id) ||
            inMemoryImageStore.get((canonical.email || '').toLowerCase()) ||
            inMemoryImageStore.get((nonCanonical.email || '').toLowerCase());

          let chosenCover: string | undefined = undefined;
          if (isUserCustomCover(canonical.coverUrl)) {
            chosenCover = canonical.coverUrl;
          } else if (isUserCustomCover(nonCanonical.coverUrl)) {
            chosenCover = nonCanonical.coverUrl;
          } else if (memoryPhotos?.coverUrl && isUserCustomCover(memoryPhotos.coverUrl)) {
            chosenCover = memoryPhotos.coverUrl;
          } else {
            chosenCover = canonical.coverUrl || nonCanonical.coverUrl;
          }

          if (isUserCustomCover(chosenCover)) {
            if (canonical.id) inMemoryImageStore.set(canonical.id, { ...(inMemoryImageStore.get(canonical.id) || {}), coverUrl: chosenCover });
            if (canonical.email) inMemoryImageStore.set(canonical.email.toLowerCase(), { ...(inMemoryImageStore.get(canonical.email.toLowerCase()) || {}), coverUrl: chosenCover });
          }
          return chosenCover;
        })(),
        bio: (canonical.bio && canonical.bio.length > 20) ? canonical.bio : (nonCanonical.bio || canonical.bio),
        mobileNo:
          canonical.mobileNo && !canonical.mobileNo.includes('01700000000')
            ? canonical.mobileNo
            : nonCanonical.mobileNo || canonical.mobileNo,
        email:
          canonical.email && !canonical.email.includes('volunteer_')
            ? canonical.email
            : nonCanonical.email || canonical.email,
        dateOfBirth: canonical.dateOfBirth || nonCanonical.dateOfBirth,
        lastBloodDonationDate: canonical.lastBloodDonationDate || nonCanonical.lastBloodDonationDate,
        upazila: canonical.upazila || nonCanonical.upazila,
        isOnline: canonical.isOnline || nonCanonical.isOnline,
      };

      canonicalList[matchIndex] = unified;
    }
  }

  return { merged: canonicalList, duplicateIdsToDelete };
};

/**
 * Recursively strips any `undefined` properties from an object or array
 * so that Firestore operations (setDoc, updateDoc) never fail with
 * "Unsupported field value: undefined".
 */
export const cleanFirestoreData = <T = any>(data: T): T => {
  if (data === undefined || data === null) {
    return data;
  }
  if (Array.isArray(data)) {
    return data
      .filter((item) => item !== undefined)
      .map((item) => cleanFirestoreData(item)) as unknown as T;
  }
  if (typeof data === 'object' && !(data instanceof Date)) {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
      if (key === 'password') continue; // Never store passwords in Firestore
      if (value !== undefined) {
        cleaned[key] = cleanFirestoreData(value);
      }
    }
    return cleaned as T;
  }
  return data;
};

/**
 * Generates an ultra-unique collision-free ID
 */
export const generateUniqueId = (prefix: string = 'id'): string => {
  const timestamp = Date.now();
  const randomPart = Math.random().toString(36).substring(2, 9);
  const microTime = (typeof performance !== 'undefined' && performance.now) 
    ? Math.floor(performance.now() * 100).toString(36)
    : Math.floor(Math.random() * 1000).toString(36);
  return `${prefix}-${timestamp}-${randomPart}${microTime}`;
};

/**
 * Compresses an image file or data URL to a lightweight JPEG Data URL
 * to avoid browser QuotaExceededError and ensure fast rendering.
 */
export const compressImage = (
  file: File,
  maxWidth: number = 600,
  maxHeight: number = 600,
  quality: number = 0.75
): Promise<string> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (readerEvent) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(readerEvent.target?.result as string || '');
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      };

      img.onerror = () => {
        resolve(readerEvent.target?.result as string || '');
      };

      img.src = readerEvent.target?.result as string;
    };

    reader.onerror = () => {
      resolve('');
    };

    reader.readAsDataURL(file);
  });
};
