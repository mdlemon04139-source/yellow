export const translations = {
  en: {
    // App Brand & Headers
    appName: 'Yellow Army',
    districtChapter: 'Mymensingh District',
    liveRadio: 'District Broadcast',
    connectedCloud: 'Firebase Cloud Active',
    offlineMode: 'Local Cache Active',
    
    // Top Bar & Navigation
    searchPlaceholder: 'Search projects, volunteers, blood donors...',
    scheduleButton: 'New Initiative',
    signIn: 'Sign In',
    joinArmy: 'Join Army',
    myAccount: 'My Account',
    signOut: 'Sign Out',
    switchRole: 'Switch User',
    
    // Nav Tabs
    tabHome: 'Home',
    tabCalendar: 'Schedule',
    tabArmy: 'Army Directory',
    tabRadio: 'Broadcast',
    tabProfile: 'Profile',
    
    // Bottom Nav
    home: 'Home',
    calendar: 'Schedule',
    volunteers: 'Volunteers',
    radio: 'Broadcast',
    profile: 'Profile',

    // Upazila Navigator
    regionTitle: 'Mymensingh Upazila Navigator',
    allDistrict: 'All Mymensingh District',
    upazilasCount: '13 Upazilas',
    selectUpazilaPrompt: 'Select an upazila to view localized volunteer initiatives and members',
    changeRegion: 'Change Area',
    selectedBadge: 'Active Focus',
    resetFilter: 'Show All District',
    
    // Stat Cards
    thisYear: 'This Year Initiatives',
    thisMonth: 'This Month Operations',
    ongoing: 'Ongoing Projects',
    upcoming: 'Upcoming Schedule',
    totalInitiatives: 'Initiatives',
    activeOnField: 'Live on Field',
    currentMonth: 'Current Month',
    nextInPipeline: 'Next in Pipeline',
    
    // Active Projects
    activeProjectsTitle: 'Active Field Operations & Initiatives',
    activeProjectsSubtitle: 'Real-time project tracking across Mymensingh District',
    createProject: 'Launch Initiative',
    allCategories: 'All Categories',
    completedProjects: 'Recent Completed Projects',
    topPinnedProjects: 'Featured Priority Projects',
    noProjectsFound: 'No active initiatives found.',
    launchFirstPrompt: 'Be the first volunteer to initiate a project!',
    deleteConfirm: 'Are you sure you want to remove this initiative?',
    deleteAction: 'Remove',
    cancel: 'Cancel',
    attendees: 'Volunteers',
    joinNow: 'Join Project',
    joined: 'Enrolled',
    details: 'Details',
    
    // Project Launch Modal
    modalTitle: 'Launch Project or Schedule Meeting',
    projectType: 'Initiative Type',
    fieldProject: 'Field Project (Social Action)',
    coordMeeting: 'Coordination Meeting (Assembly)',
    initiativeTitle: 'Initiative Title',
    titlePlaceholder: 'e.g., Brahmaputra Clean River & Waste Management Drive',
    upazilaScope: 'Upazila Scope',
    venue: 'Venue / Location',
    venuePlaceholder: 'e.g., Mymensingh Sadar Riverfront Ghat',
    photoUpload: 'Project Banner Photo',
    chooseFromGallery: 'Upload from Device Gallery',
    orEnterUrl: 'Or enter image link',
    startDate: 'Start Date & Time',
    endDate: 'End Date & Time',
    description: 'Description & Action Plan',
    descPlaceholder: 'Detail the initiative objectives, duties, and volunteer equipment needed...',
    targetBeneficiaries: 'Target Beneficiaries',
    targetTrees: 'Target Trees / Blood Units',
    publishButton: 'Publish to Yellow Army',
    
    // Profile & ID Card
    smartIdTitle: 'Yellow Army Volunteer Smart ID',
    editProfile: 'Edit Profile Information',
    saveProfile: 'Save Changes',
    profilePhotoUpload: 'Upload Profile Photo from Gallery',
    volunteerIdCode: 'Volunteer ID',
    roleLabel: 'Role',
    upazilaLabel: 'Upazila',
    bloodGroupLabel: 'Blood Group',
    genderLabel: 'Gender',
    mobileLabel: 'Mobile Number',
    emailLabel: 'Email Address',
    dobLabel: 'Date of Birth',
    hoursVolunteered: 'Hours Volunteered',
    projectsCompleted: 'Initiatives Joined',
    badgesTitle: 'Earned Badges & Milestones',
    settingsTitle: 'App Settings & Preferences',
    languageToggle: 'Language Selection',
    bangla: 'বাংলা (Bengali)',
    english: 'English',
    
    // Activity Logs
    activityFeed: 'Live Field Activity Stream',
    
    // Recent Completed
    recentCompletedTitle: 'Recently Completed Initiatives',
    recentCompletedSubtitle: 'Impact delivered by Yellow Army teams in Mymensingh',
    lastThree: 'Recent 3',
    viewArchive: 'View Calendar Archive',
    completedBadge: 'Completed',
    
    // Top Pinned Section
    topProjectsTitle: 'Priority Featured Projects',
    topProjectsSubtitle: 'District-wide flagship initiatives with high community impact',
    pinProjectAdmin: 'Pin to Top (Admin)',
    unpinProject: 'Unpin',
    addToTop: 'Add Project to Top Pinned',
    noTopProjects: 'No priority projects pinned right now.',
    
    // Army Directory
    armyDirectoryTitle: 'Yellow Army Volunteer Directory',
    armyDirectorySubtitle: 'Registered volunteers & emergency blood donors in Mymensingh District',
    registerVolunteer: 'Register Volunteer',
    searchVolunteers: 'Search by name, ID, phone, email, or upazila...',
    filterUpazila: 'Upazila Filter',
    filterBlood: 'Emergency Blood Group',
    filterRole: 'Role Filter',
    allBloodGroups: 'All Blood Groups (Emergency Life Saver)',
    allRoles: 'All Roles',
    serviceHours: 'Hours Volunteered',
    initiativesJoined: 'Initiatives Joined',
    volunteerId: 'Volunteer ID',
    emailAddress: 'Email Address',
    mobileNo: 'Mobile Number',
    gender: 'Gender',
    dateOfBirth: 'Date of Birth',
    joinDate: 'Join Date',
    bloodGroup: 'Blood Group',
    roleInVBD: 'Role',
    armyBadges: 'Badges',
    milestoneBadges: 'Earned Badges & Honors',
    initiativesEnrolled: 'Initiatives Enrolled',
    settings: 'Settings',
    languageSetting: 'Language Preference',
    saveSettings: 'Save Settings',
    shareCard: 'Share ID Card',
    
    // Calendar View
    calendarTitle: 'District Schedule & Calendar',
    calendarSubtitle: 'Upcoming field projects, volunteer meetings & assemblies',
    allDates: 'All Dates',
    
    // Radio
    radioTitle: 'Yellow Army Live Radio & SOS Broadcast',
    radioSubtitle: 'Real-time voice bulletins, emergency notices & announcements',
    broadcastSOS: 'Broadcast SOS / Alert',
    playVoiceNote: 'Play Bulletin',
    pauseVoiceNote: 'Pause',
    likeBroadcast: 'Acknowledge / Like',
    
    // Auth Modal
    loginTitle: 'Sign in to Yellow Army',
    signupTitle: 'Register New Volunteer',
    continueWithGoogle: 'Continue with Google',
    orWithEmail: 'Or sign in with Email / Phone',
    fullName: 'Full Name',
    password: 'Password',
    completeProfile: 'Complete Volunteer Profile',
    registerAndJoin: 'Complete Registration & Enter',
  },
  
  bn: {
    // App Brand & Headers
    appName: 'Yellow Army',
    districtChapter: 'ময়মনসিংহ জেলা',
    liveRadio: 'জেলা ব্রডকাস্ট',
    connectedCloud: 'ফায়ারবেস ক্লাউড কানেক্টেড',
    offlineMode: 'লোকাল ক্যাশ মোড',
    
    // Top Bar & Navigation
    searchPlaceholder: 'প্রজেক্ট, ভলান্টিয়ার, রক্তদাতা খুঁজুন...',
    scheduleButton: 'নতুন কার্যক্রম',
    signIn: 'লগইন করুন',
    joinArmy: 'যোগ দিন',
    myAccount: 'আমার প্রোফাইল',
    signOut: 'লগআউট',
    switchRole: 'ইউজার পরিবর্তন',
    
    // Nav Tabs
    tabHome: 'হোম',
    tabCalendar: 'ক্যালেন্ডার',
    tabArmy: 'ভলান্টিয়ার্স',
    tabRadio: 'ব্রডকাস্ট',
    tabProfile: 'প্রোফাইল',
    
    // Bottom Nav
    home: 'হোম',
    calendar: 'ক্যালেন্ডার',
    volunteers: 'ভলান্টিয়ার্স',
    radio: 'ব্রডকাস্ট',
    profile: 'প্রোফাইল',

    // Upazila Navigator
    regionTitle: 'ময়মনসিংহ উপজেলা ফিল্টার',
    allDistrict: 'সমগ্র ময়মনসিংহ জেলা',
    upazilasCount: '১৩টি উপজেলা',
    selectUpazilaPrompt: 'নির্দিষ্ট উপজেলার প্রজেক্ট ও ভলান্টিয়ার দেখতে উপজেলা নির্বাচন করুন',
    changeRegion: 'উপজেলা পরিবর্তন',
    selectedBadge: 'নির্বাচিত এলাকা',
    resetFilter: 'সারা জেলা দেখুন',
    
    // Stat Cards
    thisYear: 'এই বছরের প্রজেক্ট',
    thisMonth: 'এই মাসের প্রজেক্ট',
    ongoing: 'চলমান প্রজেক্ট',
    upcoming: 'আসন্ন কার্যক্রম',
    totalInitiatives: 'কার্যক্রম',
    activeOnField: 'মাঠে চলমান',
    currentMonth: 'চলতি মাস',
    nextInPipeline: 'পরবর্তী পরিকল্পনা',
    
    // Active Projects
    activeProjectsTitle: 'চলমান ফিল্ড অপারেশন ও প্রজেক্ট',
    activeProjectsSubtitle: 'ময়মনসিংহ জেলার রিয়েল-টাইম প্রজেক্ট ট্র্যাকিং',
    createProject: 'প্রজেক্ট শুরু করুন',
    allCategories: 'সকল ক্যাটাগরি',
    completedProjects: 'সম্প্রতি সমাপ্ত কার্যক্রম',
    topPinnedProjects: 'শীর্ষ সফল প্রজেক্টসমূহ',
    noProjectsFound: 'কোনো প্রজেক্ট পাওয়া যায়নি।',
    launchFirstPrompt: 'প্রথম ভলান্টিয়ার হিসেবে নতুন প্রজেক্ট শুরু করুন!',
    deleteConfirm: 'আপনি কি নিশ্চিতভাবে এই প্রজেক্টটি মুছে ফেলতে চান?',
    deleteAction: 'মুছে ফেলুন',
    cancel: 'বাতিল',
    attendees: 'ভলান্টিয়ার',
    joinNow: 'যোগ দিন',
    joined: 'যুক্ত আছেন',
    details: 'বিস্তারিত দেখুন',
    
    // Project Launch Modal
    modalTitle: 'নতুন প্রজেক্ট / সমন্বয় সভা শুরু করুন',
    projectType: 'ক্যাটাগরি / ধরন',
    fieldProject: 'ফিল্ড প্রজেক্ট (সমাজসেবা)',
    coordMeeting: 'সমন্বয় সভা (এক্সিকিউটিভ)',
    initiativeTitle: 'কার্যক্রমের নাম',
    titlePlaceholder: 'যেমন: ব্রহ্মপুত্র নদ পরিচ্ছন্নতা ও বৃক্ষরোপণ কর্মসূচি',
    upazilaScope: 'উপজেলা আওতা',
    venue: 'ভেন্যু ও স্থান',
    venuePlaceholder: 'যেমন: মুক্তাগাছা মডেল হাইস্কুল মাঠ',
    photoUpload: 'প্রজেক্ট ব্যানার ছবি',
    chooseFromGallery: 'গ্যালারি / ডিভাইস থেকে ছবি আপলোড করুন',
    orEnterUrl: 'অথবা ছবির লিঙ্ক দিন',
    startDate: 'শুরুর সময় ও তারিখ',
    endDate: 'শেষের সময় ও তারিখ',
    description: 'প্রজেক্টের বিবরণ ও কর্মপরিকল্পনা',
    descPlaceholder: 'প্রজেক্টের উদ্দেশ্য, ভলান্টিয়ারদের দায়িত্ব ও প্রভাব সম্পর্কে লিখুন...',
    targetBeneficiaries: 'উপকৃত মানুষের লক্ষ্যমাত্রা',
    targetTrees: 'গাছ / রক্তের ব্যাগ লক্ষ্যমাত্রা',
    publishButton: 'ইয়েলো আর্মিতে প্রকাশ করুন',
    
    // Profile & ID Card
    smartIdTitle: 'ইয়েলো আর্মি ভলান্টিয়ার স্মার্ট আইডি কার্ড',
    editProfile: 'প্রোফাইল তথ্য পরিবর্তন',
    saveProfile: 'সংরক্ষণ করুন',
    profilePhotoUpload: 'গ্যালারি থেকে প্রোফাইল ছবি আপলোড করুন',
    volunteerIdCode: 'ভলান্টিয়ার আইডি',
    roleLabel: 'পদবি',
    upazilaLabel: 'উপজেলা',
    bloodGroupLabel: 'রক্তের গ্রুপ',
    genderLabel: 'লিঙ্গ',
    mobileLabel: 'মোবাইল নম্বর',
    emailLabel: 'ইমেইল এড্রেস',
    dobLabel: 'জন্ম তারিখ',
    hoursVolunteered: 'স্বেচ্ছাসেবা ঘণ্টা',
    projectsCompleted: 'সম্পন্ন কার্যক্রম',
    badgesTitle: 'অর্জিত ব্যাজ ও সম্মাননা',
    settingsTitle: 'অ্যাপ সেটিংস ও পছন্দসমূহ',
    languageToggle: 'ভাষার পছন্দ',
    bangla: 'বাংলা (Bengali)',
    english: 'English',
    
    // Activity Logs
    activityFeed: 'লাইভ ফিল্ড এক্টিভিটি ফিড',
    
    // Recent Completed
    recentCompletedTitle: 'সম্প্রতি সমাপ্ত প্রজেক্টসমূহ',
    recentCompletedSubtitle: 'ময়মনসিংহে ইয়েলো আর্মি ভলান্টিয়ারদের সফল কার্যক্রমের প্রভাব',
    lastThree: 'শেষ ৩টি',
    viewArchive: 'ক্যালেন্ডার আর্কাইভ দেখুন',
    completedBadge: 'সমাপ্ত',
    
    // Top Pinned Section
    topProjectsTitle: 'শীর্ষ অগ্রাধিকার প্রজেক্টসমূহ',
    topProjectsSubtitle: 'ময়মনসিংহ জেলার সর্বোচ্চ প্রভাব সৃষ্টিকারী ফ্ল্যাগশিপ উদ্যোগ',
    pinProjectAdmin: 'শীর্ষে পিন করুন (অ্যাডমিন)',
    unpinProject: 'আনপিন করুন',
    addToTop: 'শীর্ষ প্রজেক্ট তালিকায় যোগ করুন',
    noTopProjects: 'বর্তমানে কোনো অগ্রাধিকার প্রজেক্ট পিন করা নেই।',
    
    // Army Directory
    armyDirectoryTitle: 'ইয়েলো আর্মি ভলান্টিয়ার ডিরেক্টরি',
    armyDirectorySubtitle: 'ময়মনসিংহ জেলার নিবন্ধিত ভলান্টিয়ার ও জরুরি রক্তদাতাদের তালিকা',
    registerVolunteer: 'নতুন ভলান্টিয়ার রেজিস্ট্রেশন',
    searchVolunteers: 'নাম, আইডি, ফোন নম্বর, ইমেইল বা উপজেলা দিয়ে খুঁজুন...',
    filterUpazila: 'উপজেলা ফিল্টার',
    filterBlood: 'জরুরি রক্তের গ্রুপ ফিল্টার',
    filterRole: 'পদবি ফিল্টার',
    allBloodGroups: 'সকল রক্তের গ্রুপ (জীবন রক্ষাকারী)',
    allRoles: 'সকল পদবি',
    serviceHours: 'স্বেচ্ছাসেবা ঘণ্টা',
    initiativesJoined: 'যুক্ত কার্যক্রম',
    volunteerId: 'ভলান্টিয়ার আইডি',
    emailAddress: 'ইমেইল এড্রেস',
    mobileNo: 'মোবাইল নম্বর',
    gender: 'লিঙ্গ',
    dateOfBirth: 'জন্ম তারিখ',
    joinDate: 'যোগদানের তারিখ',
    bloodGroup: 'রক্তের গ্রুপ',
    roleInVBD: 'পদবি',
    armyBadges: 'ব্যাজ',
    milestoneBadges: 'অর্জিত ব্যাজ ও সম্মাননা',
    initiativesEnrolled: 'যুক্ত কার্যক্রম',
    settings: 'সেটিংস',
    languageSetting: 'ভাষা নির্বাচন (Language)',
    saveSettings: 'সেটিংস সংরক্ষণ করুন',
    shareCard: 'আইডি কার্ড শেয়ার করুন',
    
    // Calendar View
    calendarTitle: 'জেলা সমন্বয় ও ক্যালেন্ডার',
    calendarSubtitle: 'আসন্ন সকল ফিল্ড প্রজেক্ট, সমন্বয় সভা ও কার্যক্রমের সময়সূচি',
    allDates: 'সকল তারিখ',
    
    // Radio
    radioTitle: 'ইয়েলো আর্মি লাইভ রেডিও ও জরুরি ব্রডকাস্ট',
    radioSubtitle: 'ময়মনসিংহের সকল ভলান্টিয়ারদের জন্য রিয়েল-টাইম ভয়েস বার্তা ও জরুরি নোটিশ',
    broadcastSOS: 'জরুরি বার্তা প্রকাশ করুন',
    playVoiceNote: 'বার্তা শুনুন',
    pauseVoiceNote: 'থামান',
    likeBroadcast: 'সমর্থন জানান',
    
    // Auth Modal
    loginTitle: 'ইয়েলো আর্মিতে সাইন ইন করুন',
    signupTitle: 'নতুন ভলান্টিয়ার নিবন্ধন',
    continueWithGoogle: 'গুগল দিয়ে প্রবেশ করুন',
    orWithEmail: 'অথবা ইমেইল ও পাসওয়ার্ড দিয়ে',
    fullName: 'পুরো নাম',
    password: 'পাসওয়ার্ড',
    completeProfile: 'ভলান্টিয়ার প্রোফাইল পূরণ করুন',
    registerAndJoin: 'রেজিস্ট্রেশন সম্পন্ন করে যুক্ত হন',
  },
};

export const getCategoryBadge = (title: string, type: 'Project' | 'Meeting') => {
  if (type === 'Meeting') {
    return {
      emoji: '🤝',
      name: 'Meeting',
      color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      borderAccent: 'border-emerald-400',
      tagBg: 'bg-emerald-50',
    };
  }
  const lower = title.toLowerCase();
  if (lower.includes('blood') || lower.includes('রক্ত') || lower.includes('donor')) {
    return {
      emoji: '🩸',
      name: 'Blood Camp',
      color: 'bg-rose-100 text-rose-900 border-rose-300',
      borderAccent: 'border-rose-400',
      tagBg: 'bg-rose-50',
    };
  }
  if (lower.includes('tree') || lower.includes('green') || lower.includes('গাছ') || lower.includes('plant')) {
    return {
      emoji: '🌳',
      name: 'Green Drive',
      color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      borderAccent: 'border-emerald-400',
      tagBg: 'bg-emerald-50',
    };
  }
  if (lower.includes('education') || lower.includes('child') || lower.includes('shishu') || lower.includes('শিক্ষা')) {
    return {
      emoji: '📚',
      name: 'Education',
      color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      borderAccent: 'border-emerald-400',
      tagBg: 'bg-emerald-50',
    };
  }
  if (lower.includes('clean') || lower.includes('river') || lower.includes('পরিচ্ছন্ন') || lower.includes('waste')) {
    return {
      emoji: '🧹',
      name: 'Cleanliness',
      color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      borderAccent: 'border-emerald-400',
      tagBg: 'bg-emerald-50',
    };
  }
  if (lower.includes('winter') || lower.includes('warmth') || lower.includes('cloth') || lower.includes('শীত')) {
    return {
      emoji: '🧥',
      name: 'Winter Relief',
      color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      borderAccent: 'border-emerald-400',
      tagBg: 'bg-emerald-50',
    };
  }
  return {
    emoji: '⚡',
    name: 'Social Action',
    color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
    borderAccent: 'border-emerald-400',
    tagBg: 'bg-emerald-50',
  };
};
