import {
  getDoc as fbGetDoc,
  getDocs as fbGetDocs,
  setDoc as fbSetDoc,
  updateDoc as fbUpdateDoc,
  deleteDoc as fbDeleteDoc,
  DocumentReference,
  Query,
  SetOptions,
  UpdateData,
  WithFieldValue,
  DocumentSnapshot,
  QuerySnapshot,
} from 'firebase/firestore';

export interface FirestoreAuditRecord {
  type: 'getDoc' | 'getDocs' | 'setDoc' | 'updateDoc' | 'deleteDoc';
  path: string;
  docCount: number;
  timestamp: number;
}

export interface FirestoreAuditStats {
  getDocCalls: number;
  getDocsCalls: number;
  setDocCalls: number;
  updateDocCalls: number;
  deleteDocCalls: number;
  totalCalls: number;
  documentReads: number;
  documentWrites: number;
  documentDeletes: number;
  history: FirestoreAuditRecord[];
}

const stats: FirestoreAuditStats = {
  getDocCalls: 0,
  getDocsCalls: 0,
  setDocCalls: 0,
  updateDocCalls: 0,
  deleteDocCalls: 0,
  totalCalls: 0,
  documentReads: 0,
  documentWrites: 0,
  documentDeletes: 0,
  history: [],
};

export const getFirestoreStats = (): FirestoreAuditStats => {
  return {
    ...stats,
    history: [...stats.history],
  };
};

export const resetFirestoreStats = (): void => {
  stats.getDocCalls = 0;
  stats.getDocsCalls = 0;
  stats.setDocCalls = 0;
  stats.updateDocCalls = 0;
  stats.deleteDocCalls = 0;
  stats.totalCalls = 0;
  stats.documentReads = 0;
  stats.documentWrites = 0;
  stats.documentDeletes = 0;
  stats.history = [];
};

// Expose on global window object for live debugging and verification in the browser console
if (typeof window !== 'undefined') {
  (window as any).__fsStats = getFirestoreStats;
  (window as any).__fsResetStats = resetFirestoreStats;
}

/**
 * Audited getDoc: tracks call count and records 1 document read if doc exists.
 */
export async function auditGetDoc<T = any>(
  docRef: DocumentReference<T>
): Promise<DocumentSnapshot<T>> {
  stats.getDocCalls++;
  stats.totalCalls++;
  const snap = await fbGetDoc(docRef);
  const docCount = snap.exists() ? 1 : 0;
  stats.documentReads += docCount;
  stats.history.push({
    type: 'getDoc',
    path: docRef.path,
    docCount,
    timestamp: Date.now(),
  });
  return snap;
}

/**
 * Audited getDocs: tracks call count AND records actual number of documents returned.
 * (Accurately reflects billable reads recorded in Firebase Console)
 */
export async function auditGetDocs<T = any>(
  queryRef: Query<T>,
  pathHint?: string
): Promise<QuerySnapshot<T>> {
  stats.getDocsCalls++;
  stats.totalCalls++;
  const snap = await fbGetDocs(queryRef);
  const docCount = snap.size;
  stats.documentReads += docCount;
  stats.history.push({
    type: 'getDocs',
    path: pathHint || 'query',
    docCount,
    timestamp: Date.now(),
  });
  return snap;
}

/**
 * Audited setDoc: tracks call count and document write.
 */
export async function auditSetDoc<T = any>(
  docRef: DocumentReference<T>,
  data: WithFieldValue<T>,
  options?: SetOptions
): Promise<void> {
  stats.setDocCalls++;
  stats.totalCalls++;
  stats.documentWrites++;
  stats.history.push({
    type: 'setDoc',
    path: docRef.path,
    docCount: 1,
    timestamp: Date.now(),
  });
  if (options) {
    return fbSetDoc(docRef, data, options);
  }
  return fbSetDoc(docRef, data);
}

/**
 * Audited updateDoc: tracks call count and document write.
 */
export async function auditUpdateDoc<T = any>(
  docRef: DocumentReference<T>,
  data: UpdateData<T> | any
): Promise<void> {
  stats.updateDocCalls++;
  stats.totalCalls++;
  stats.documentWrites++;
  stats.history.push({
    type: 'updateDoc',
    path: docRef.path,
    docCount: 1,
    timestamp: Date.now(),
  });
  return fbUpdateDoc(docRef, data as any);
}

/**
 * Audited deleteDoc: tracks call count and document deletion.
 */
export async function auditDeleteDoc<T = any>(
  docRef: DocumentReference<T>
): Promise<void> {
  stats.deleteDocCalls++;
  stats.totalCalls++;
  stats.documentDeletes++;
  stats.history.push({
    type: 'deleteDoc',
    path: docRef.path,
    docCount: 1,
    timestamp: Date.now(),
  });
  return fbDeleteDoc(docRef);
}
