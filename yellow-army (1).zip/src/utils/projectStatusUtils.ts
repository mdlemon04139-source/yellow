import { ProjectMeeting } from '../types';

/**
 * Calculates the current effective status of an initiative:
 * - If status is manually marked as 'completed' or 'archived', it remains so.
 * - Otherwise:
 *   - If current time >= closingTime, it automatically becomes 'completed'.
 *   - If current time is within 24 hours before startingTime (or between start and close), it becomes 'ongoing'.
 *   - Before 24 hours of startingTime, it remains 'upcoming'.
 */
export const getEffectiveProjectStatus = (
  project: Pick<ProjectMeeting, 'status' | 'startingTime' | 'closingTime'>
): 'upcoming' | 'ongoing' | 'completed' | 'archived' => {
  const rawStatus = (project.status || '').toLowerCase().trim();
  if (rawStatus === 'archived') {
    return 'archived';
  }

  // If marked as completed or finished, it remains permanently completed
  if (rawStatus === 'completed' || rawStatus === 'finished') {
    return 'completed';
  }

  // If marked as ongoing by admin or system, it remains ongoing
  if (rawStatus === 'ongoing') {
    return 'ongoing';
  }

  const now = Date.now();
  const startTime = project.startingTime ? new Date(project.startingTime).getTime() : NaN;
  const closingTime = project.closingTime
    ? new Date(project.closingTime).getTime()
    : !isNaN(startTime)
    ? startTime + 4 * 3600 * 1000
    : NaN;

  // If already past the closing time, it's completed automatically
  if (!isNaN(closingTime) && now >= closingTime) {
    return 'completed';
  }

  // 24 hours before start date (24 * 60 * 60 * 1000 = 86400000 ms)
  const twentyFourHoursBeforeStart = !isNaN(startTime) ? startTime - 86400000 : NaN;

  if (!isNaN(startTime) && !isNaN(twentyFourHoursBeforeStart) && now >= twentyFourHoursBeforeStart) {
    return 'ongoing';
  }

  return 'upcoming';
};

/**
 * Returns true if a project is completed or archived
 */
export const isProjectFinished = (
  project?: Pick<ProjectMeeting, 'status' | 'startingTime' | 'closingTime'> | null
): boolean => {
  if (!project) return false;
  const rawStatus = (project.status || '').toLowerCase().trim();
  if (rawStatus === 'completed' || rawStatus === 'finished' || rawStatus === 'archived' || (project as any).isCompleted) {
    return true;
  }
  if (rawStatus === 'ongoing') {
    return false;
  }
  const status = getEffectiveProjectStatus(project);
  return status === 'completed' || status === 'archived';
};

/**
 * Formats starting and closing dates for project cards.
 * If project runs for long time (multiple days or >24h), provides both dates clearly.
 */
export const formatProjectDateRange = (
  startingTime?: string,
  closingTime?: string
) => {
  if (!startingTime) {
    return {
      startDate: 'TBA',
      endDate: null,
      isLongTerm: false,
      durationDays: 1,
    };
  }

  const s = new Date(startingTime);
  const startDate = !isNaN(s.getTime())
    ? s.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
    : startingTime.split('T')[0];

  if (!closingTime) {
    return {
      startDate,
      endDate: null,
      isLongTerm: false,
      durationDays: 1,
    };
  }

  const c = new Date(closingTime);
  const endDate = !isNaN(c.getTime())
    ? c.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
    : closingTime.split('T')[0];

  const diffMs = !isNaN(c.getTime()) && !isNaN(s.getTime()) ? c.getTime() - s.getTime() : 0;
  const durationDays = Math.max(1, Math.round(diffMs / (1000 * 60 * 60 * 24)));
  const isLongTerm = durationDays > 1 || startDate !== endDate;

  return {
    startDate,
    endDate,
    isLongTerm,
    durationDays,
  };
};
