import { Volunteer } from '../types';

/**
 * Returns the single, unified public verification URL for a volunteer.
 * When anyone scans this QR code (even without logging in), it opens the
 * public volunteer verification record showing their status, blood group,
 * and all operational records.
 */
export const getVolunteerUnifiedVerificationUrl = (volunteer: Volunteer): string => {
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://yellowarmy.org';
  const path = typeof window !== 'undefined' ? window.location.pathname : '/';
  const code = encodeURIComponent(volunteer.volunteerIdCode || volunteer.id);
  return `${origin}${path}?verify=${code}`;
};

/**
 * Generates the QR Code image URL pointing to the unified public verification page
 */
export const getVolunteerUnifiedQrCodeImage = (volunteer: Volunteer, size: number = 160): string => {
  const url = getVolunteerUnifiedVerificationUrl(volunteer);
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(url)}`;
};
