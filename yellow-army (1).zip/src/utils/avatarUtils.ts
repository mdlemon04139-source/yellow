import { Gender } from '../types';

/**
 * Generates a clean, modern, high-contrast Yellow Army Volunteer Avatar
 * Designed with professional minimalism, rich vector gradients, and official Yellow Army colors.
 */
export const getCartoonYellowAvatar = (gender?: Gender, seed?: string): string => {
  const isFemale = gender === 'Female';
  const cleanSeed = (seed || 'volunteer').toLowerCase();

  // Deterministic seed hash
  let hash = 0;
  for (let i = 0; i < cleanSeed.length; i++) {
    hash = (hash << 5) - hash + cleanSeed.charCodeAt(i);
    hash |= 0;
  }
  const absHash = Math.abs(hash);

  // Natural skin tones
  const skinTones = ['#FAD4C0', '#F7C6A5', '#EBB086', '#D4956B', '#FDE0D0'];
  // Natural hair tones
  const hairTones = ['#1C1917', '#292524', '#3E2723', '#1E293B', '#332015'];
  
  const skin = skinTones[absHash % skinTones.length];
  const hair = hairTones[absHash % hairTones.length];

  let svg = '';

  if (isFemale) {
    svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160" width="160" height="160">
      <defs>
        <linearGradient id="bgGradF" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#07531d"/>
          <stop offset="100%" stop-color="#03260c"/>
        </linearGradient>
        <linearGradient id="hoodieGradF" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#FACC15"/>
          <stop offset="100%" stop-color="#D97706"/>
        </linearGradient>
        <linearGradient id="goldRim" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#FDE047"/>
          <stop offset="100%" stop-color="#B45309"/>
        </linearGradient>
        <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="2" stdDeviation="2.5" flood-opacity="0.2"/>
        </filter>
      </defs>

      <!-- Background Disc -->
      <circle cx="80" cy="80" r="77" fill="url(#bgGradF)"/>
      <circle cx="80" cy="80" r="77" fill="none" stroke="url(#goldRim)" stroke-width="2.5"/>

      <!-- Back Hair -->
      <path d="M46 68 C40 92, 42 120, 52 142 C58 142, 63 118, 65 96 Z" fill="${hair}"/>
      <path d="M114 68 C120 92, 118 120, 108 142 C102 142, 97 118, 95 96 Z" fill="${hair}"/>

      <!-- Shoulders & Uniform -->
      <path d="M28 156 C32 124, 48 112, 80 112 C112 112, 128 124, 132 156 Z" fill="url(#hoodieGradF)" filter="url(#shadow)"/>
      <path d="M66 112 L80 134 L94 112 Z" fill="#07531d"/>
      <path d="M68 112 L80 131 L92 112" stroke="#FACC15" stroke-width="1.5" fill="none"/>

      <!-- Neck -->
      <path d="M71 96 L71 116 C71 120, 89 120, 89 116 L89 96 Z" fill="${skin}"/>

      <!-- Face -->
      <path d="M52 64 C52 98, 62 108, 80 108 C98 108, 108 98, 108 64 C108 40, 96 32, 80 32 C64 32, 52 40, 52 64 Z" fill="${skin}" filter="url(#shadow)"/>

      <!-- Subtle Cheeks -->
      <ellipse cx="62" cy="82" rx="5" ry="3" fill="#F43F5E" opacity="0.2"/>
      <ellipse cx="98" cy="82" rx="5" ry="3" fill="#F43F5E" opacity="0.2"/>

      <!-- Eyes -->
      <ellipse cx="67" cy="70" rx="4" ry="4.5" fill="#1C1917"/>
      <circle cx="65.5" cy="68.5" r="1.5" fill="#FFFFFF"/>
      <ellipse cx="93" cy="70" rx="4" ry="4.5" fill="#1C1917"/>
      <circle cx="91.5" cy="68.5" r="1.5" fill="#FFFFFF"/>

      <!-- Eyebrows -->
      <path d="M61 63 Q67 60 73 63" stroke="${hair}" stroke-width="2" stroke-linecap="round" fill="none"/>
      <path d="M87 63 Q93 60 99 63" stroke="${hair}" stroke-width="2" stroke-linecap="round" fill="none"/>

      <!-- Smile -->
      <path d="M74 88 Q80 93 86 88" stroke="#9F1239" stroke-width="2" stroke-linecap="round" fill="none"/>

      <!-- Front Hair & Bangs -->
      <path d="M49 60 C49 34, 63 22, 80 22 C97 22, 111 34, 111 60 C106 48, 96 42, 86 44 C80 47, 74 38, 68 42 C60 46, 53 44, 49 60 Z" fill="${hair}"/>
    </svg>`;
  } else {
    svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160" width="160" height="160">
      <defs>
        <linearGradient id="bgGradM" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#07531d"/>
          <stop offset="100%" stop-color="#03260c"/>
        </linearGradient>
        <linearGradient id="hoodieGradM" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="#FACC15"/>
          <stop offset="100%" stop-color="#D97706"/>
        </linearGradient>
        <linearGradient id="goldRim" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#FDE047"/>
          <stop offset="100%" stop-color="#B45309"/>
        </linearGradient>
        <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
          <feDropShadow dx="0" dy="2" stdDeviation="2.5" flood-opacity="0.2"/>
        </filter>
      </defs>

      <!-- Background Disc -->
      <circle cx="80" cy="80" r="77" fill="url(#bgGradM)"/>
      <circle cx="80" cy="80" r="77" fill="none" stroke="url(#goldRim)" stroke-width="2.5"/>

      <!-- Shoulders & Uniform -->
      <path d="M26 156 C30 122, 46 110, 80 110 C114 110, 130 122, 134 156 Z" fill="url(#hoodieGradM)" filter="url(#shadow)"/>
      <path d="M64 110 L80 132 L96 110 Z" fill="#07531d"/>
      <path d="M66 110 L80 129 L94 110" stroke="#FACC15" stroke-width="1.5" fill="none"/>

      <!-- Neck -->
      <path d="M70 94 L70 114 C70 118, 90 118, 90 114 L90 94 Z" fill="${skin}"/>

      <!-- Face -->
      <path d="M52 60 C52 94, 62 104, 80 104 C98 104, 108 94, 108 60 C108 36, 96 28, 80 28 C64 28, 52 36, 52 60 Z" fill="${skin}" filter="url(#shadow)"/>

      <!-- Eyes -->
      <ellipse cx="67" cy="66" rx="4" ry="4.5" fill="#1C1917"/>
      <circle cx="65.5" cy="64.5" r="1.5" fill="#FFFFFF"/>
      <ellipse cx="93" cy="66" rx="4" ry="4.5" fill="#1C1917"/>
      <circle cx="91.5" cy="64.5" r="1.5" fill="#FFFFFF"/>

      <!-- Eyebrows -->
      <path d="M60 59 L74 61" stroke="${hair}" stroke-width="2.5" stroke-linecap="round"/>
      <path d="M100 59 L86 61" stroke="${hair}" stroke-width="2.5" stroke-linecap="round"/>

      <!-- Confident Smile -->
      <path d="M73 84 Q80 89 87 84" stroke="#78350F" stroke-width="2" stroke-linecap="round" fill="none"/>

      <!-- Sleek Modern Hair -->
      <path d="M49 52 C49 26, 62 16, 80 16 C98 16, 111 26, 111 52 C108 40, 98 34, 80 34 C64 34, 52 42, 49 52 Z" fill="${hair}"/>
      <!-- Side Trim -->
      <path d="M49 52 L53 68 L57 56 Z" fill="${hair}"/>
      <path d="M111 52 L107 68 L103 56 Z" fill="${hair}"/>
    </svg>`;
  }

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
};
