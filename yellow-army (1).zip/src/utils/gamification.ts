// Gamification logic: XP (Lifetime), DHP (6-Month Seasonal), and Level of Volunteerism

export interface VolunteerLevelInfo {
  levelNum: number;
  levelCode: string;
  levelTitle: string;
  levelTitleBn: string;
  currentThreshold: number;
  nextThreshold: number;
  progressPercent: number;
  badgeColor: string;
}

/**
 * Level of Volunteerism Ranking (Maximum Score: 7500)
 * Max Level: GOAT VOLUNTEER (7500+)
 * 5000 - 7499: Premium "LEGENDARY TITAN" tier
 */
export function calculateVolunteerLevel(xp: number = 0): VolunteerLevelInfo {
  const score = Math.max(0, Math.round(xp || 0));

  // L1: 0 - 499 (Recruit Scout)
  if (score < 500) {
    return {
      levelNum: 1,
      levelCode: 'L1',
      levelTitle: 'Recruit Scout',
      levelTitleBn: 'নবীন ভলান্টিয়ার (L1)',
      currentThreshold: 0,
      nextThreshold: 500,
      progressPercent: Math.min(100, Math.round((score / 500) * 100)),
      badgeColor: 'bg-slate-800 text-amber-300',
    };
  }

  // L2: 500 - 1499 (Active Vanguard)
  if (score < 1500) {
    return {
      levelNum: 2,
      levelCode: 'L2',
      levelTitle: 'Active Vanguard',
      levelTitleBn: 'ফিল্ড স্পেশালিস্ট (L2)',
      currentThreshold: 500,
      nextThreshold: 1500,
      progressPercent: Math.min(100, Math.round(((score - 500) / 1000) * 100)),
      badgeColor: 'bg-emerald-800 text-emerald-100',
    };
  }

  // L3: 1500 - 2999 (Command Sergeant)
  if (score < 3000) {
    return {
      levelNum: 3,
      levelCode: 'L3',
      levelTitle: 'Command Sergeant',
      levelTitleBn: 'কমান্ড সার্জেন্ট (L3)',
      currentThreshold: 1500,
      nextThreshold: 3000,
      progressPercent: Math.min(100, Math.round(((score - 1500) / 1500) * 100)),
      badgeColor: 'bg-blue-800 text-blue-100',
    };
  }

  // L4: 3000 - 4999 (Master Veteran)
  if (score < 5000) {
    return {
      levelNum: 4,
      levelCode: 'L4',
      levelTitle: 'Master Veteran',
      levelTitleBn: 'মাস্টার ভেটেরান (L4)',
      currentThreshold: 3000,
      nextThreshold: 5000,
      progressPercent: Math.min(100, Math.round(((score - 3000) / 2000) * 100)),
      badgeColor: 'bg-amber-600 text-slate-950 font-black',
    };
  }

  // L5: 5000 - 7499 (Premium Legendary Titan Tier)
  if (score < 7500) {
    return {
      levelNum: 5,
      levelCode: 'L5',
      levelTitle: 'Legendary Titan',
      levelTitleBn: 'লিজেন্ডারি টাইটান (L5)',
      currentThreshold: 5000,
      nextThreshold: 7500,
      progressPercent: Math.min(100, Math.round(((score - 5000) / 2500) * 100)),
      badgeColor: 'bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-700 text-slate-950 font-black ring-2 ring-yellow-400',
    };
  }

  // L6: 7500+ (Maximum Score Cap: GOAT VOLUNTEER)
  return {
    levelNum: 6,
    levelCode: 'GOAT',
    levelTitle: 'GOAT VOLUNTEER',
    levelTitleBn: 'গোট ভলান্টিয়ার (সর্বোচ্চ স্তর)',
    currentThreshold: 7500,
    nextThreshold: 7500,
    progressPercent: 100,
    badgeColor: 'bg-black text-yellow-300 font-black ring-2 ring-yellow-400 shadow-lg',
  };
}

/**
 * Visibility rules for Alumni:
 * 1. Alumni profile: LEVEL OF VOLUNTEERISM only shows if score is 5000+.
 * 2. Alumni profile: DISTRICT HEROES POINT (DHP) NEVER shows.
 */
export function shouldShowLevelOfVolunteerism(roleInVBD?: string, status?: string, score: number = 0): boolean {
  const isAlumni = roleInVBD === 'Alumni' || status === 'alumni';
  if (!isAlumni) return true;
  return score >= 5000;
}

export function shouldShowDhp(roleInVBD?: string, status?: string): boolean {
  const isAlumni = roleInVBD === 'Alumni' || status === 'alumni';
  return !isAlumni;
}

export interface DhpSeasonInfo {
  seasonName: string;
  seasonPeriod: string;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  nextResetDateStr: string;
}

export function getDhpSeasonCountdown(): DhpSeasonInfo {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth(); // 0 to 11

  // Season 1: Jan - Jun (Resets July 1, 00:00:00)
  // Season 2: Jul - Dec (Resets Jan 1, 00:00:00 of next year)
  const isSeason1 = month < 6;
  const seasonName = isSeason1 ? `Season 1 • ${year}` : `Season 2 • ${year}`;
  const seasonPeriod = isSeason1 ? `Jan 1 - Jun 30, ${year}` : `Jul 1 - Dec 31, ${year}`;

  const nextResetDate = isSeason1
    ? new Date(year, 6, 1, 0, 0, 0)
    : new Date(year + 1, 0, 1, 0, 0, 0);

  const diffMs = Math.max(0, nextResetDate.getTime() - now.getTime());
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diffMs / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diffMs / (1000 * 60)) % 60);
  const seconds = Math.floor((diffMs / 1000) % 60);

  return {
    seasonName,
    seasonPeriod,
    days,
    hours,
    minutes,
    seconds,
    nextResetDateStr: nextResetDate.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }),
  };
}
