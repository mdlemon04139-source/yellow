import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';

export const firebaseConfig = {
  apiKey: "AIzaSyBT-XGEmMCVcyvXNPOnH1yPjMGVPE_FbIc",
  authDomain: "gen-lang-client-0873869765.firebaseapp.com",
  projectId: "gen-lang-client-0873869765",
  storageBucket: "gen-lang-client-0873869765.firebasestorage.app",
  messagingSenderId: "489181722279",
  appId: "1:489181722279:web:94e63847be0551a3e18d82",
};

// Initialize Firebase App
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Connect to specific Firestore Database instance with standard client (zero background polling)
export const FIRESTORE_DB_ID = "ai-studio-yellowarmy-552658e2-543a-44b0-85b3-f73ed9c2607d";

export const db = getFirestore(app, FIRESTORE_DB_ID);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Analytics placeholder (disabled to prevent 403 config-fetch-failed errors in AI Studio environment)
export const analytics = null;
