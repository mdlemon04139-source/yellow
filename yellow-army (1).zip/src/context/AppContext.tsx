import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Volunteer,
  ProjectMeeting,
  ActivityLog,
  AppNotification,
  RadioBroadcast,
  NeedAssessment,
  BoardPhoto,
  UpazilaName,
  BloodGroup,
  Gender,
  VBDRole,
  BoardType,
  AdminRole,
  AppTab,
} from '../types';
import {
  INITIAL_VOLUNTEERS,
  INITIAL_PROJECTS,
  INITIAL_ACTIVITY_LOGS,
  INITIAL_NOTIFICATIONS,
  INITIAL_BROADCASTS,
  INITIAL_NEED_ASSESSMENTS,
  INITIAL_BOARD_PHOTOS,
} from '../data/mockData';
import { calculateVolunteerLevel } from '../utils/gamification';
import { getCartoonYellowAvatar } from '../utils/avatarUtils';
import { getEffectiveProjectStatus, isProjectFinished } from '../utils/projectStatusUtils';
import { db, auth, googleProvider } from '../lib/firebase';
import {
  collection,
  doc,
  deleteField,
  query,
  limit,
  where,
} from 'firebase/firestore';
import {
  auditGetDoc as getDoc,
  auditGetDocs as getDocs,
  auditSetDoc as setDoc,
  auditUpdateDoc as updateDoc,
  auditDeleteDoc as deleteDoc,
} from '../utils/firestoreAudit';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  updateProfile as updateFirebaseAuthProfile,
  User as FirebaseUser,
} from 'firebase/auth';
import confetti from 'canvas-confetti';
import {
  safeStorage,
  deduplicateById,
  generateUniqueId,
  cleanFirestoreData,
  mergeAndDeduplicateVolunteers,
  normalizeEmail,
  normalizePhoneDigits,
  isUserCustomPhoto,
  isUserCustomCover,
  inMemoryImageStore,
} from '../utils/storageAndImage';

interface AppContextType {
  currentUser: Volunteer | null;
  isAuthenticated: boolean;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'signup' | 'onboarding';
  volunteers: Volunteer[];
  projects: ProjectMeeting[];
  activeProjects: ProjectMeeting[];
  recentCompletedProjects: ProjectMeeting[];
  topProjects: ProjectMeeting[];
  activityLogs: ActivityLog[];
  notifications: AppNotification[];
  unreadNotificationCount: number;
  broadcasts: RadioBroadcast[];
  needAssessments: NeedAssessment[];
  boardPhotos: BoardPhoto[];
  selectedUpazila: UpazilaName | 'District';
  activeTab: AppTab;
  language: 'en' | 'bn';
  setLanguage: (lang: 'en' | 'bn') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  setSelectedUpazila: (upazila: UpazilaName | 'District') => void;
  setActiveTab: (tab: AppTab) => void;
  openAuthModal: (mode?: 'login' | 'signup' | 'onboarding') => void;
  closeAuthModal: () => void;
  loginWithEmail: (identifier: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: () => Promise<{ success: boolean; error?: string }>;
  loginAsVolunteer: (volunteerId: string) => void;
  signUpVolunteer: (data: Omit<Volunteer, 'id' | 'volunteerIdCode' | 'joinDate' | 'totalVolunteerHours' | 'projectsAttendedCount' | 'badges' | 'status' | 'isOnline'> & { password?: string }) => Promise<{ success: boolean; error?: string }>;
  completeOnboarding: (data: Partial<Volunteer>) => Promise<void>;
  logout: () => Promise<void>;
  switchUser: (volunteerId: string) => void;
  updateProfile: (data: Partial<Volunteer>) => Promise<void>;
  deleteVolunteer: (volunteerId: string) => Promise<void>;
  awardOrDeductPoints: (volunteerId: string, xpChange: number, dhpChange: number, reason: string) => Promise<void>;
  adminSetVolunteerPoints: (volunteerId: string, newXp: number, newDhp: number, reason: string) => Promise<void>;
  adminResetVolunteerScore: (volunteerId: string, reason?: string) => Promise<void>;
  launchProjectOrMeeting: (data: Omit<ProjectMeeting, 'id' | 'attendeesCount' | 'registeredVolunteerIds' | 'createdAt' | 'createdBy'> & { status?: 'upcoming' | 'ongoing' | 'completed' | 'archived' }) => Promise<void>;
  updateProjectOrMeeting: (projectId: string, updatedData: Partial<ProjectMeeting>) => Promise<void>;
  toggleTopProject: (projectId: string) => Promise<void>;
  deleteProject: (projectId: string) => Promise<void>;
  joinProject: (projectId: string) => Promise<void>;
  leaveProject: (projectId: string) => Promise<void>;
  markNotificationAsRead: (id: string) => Promise<void>;
  markAllNotificationsAsRead: () => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;
  addRadioBroadcast: (data: Omit<RadioBroadcast, 'id' | 'timestamp' | 'likesCount' | 'likedByCurrentUser'>) => Promise<void>;
  toggleLikeBroadcast: (broadcastId: string) => Promise<void>;
  voteRadioPoll: (broadcastId: string, optionId: string) => Promise<void>;
  reactToRadioBroadcast: (broadcastId: string, emoji: string) => Promise<void>;
  deleteRadioBroadcast: (broadcastId: string) => Promise<void>;
  addNeedAssessment: (data: { title: string; description: string; category?: any; upazila?: UpazilaName | 'District' }) => Promise<void>;
  voteNeedAssessment: (needId: string) => Promise<void>;
  fulfillNeedAssessment: (needId: string, adminNote?: string) => Promise<void>;
  deleteNeedAssessment: (needId: string) => Promise<void>;
  updateBoardPhoto: (scope: UpazilaName | 'District', photoUrl: string, title?: string, caption?: string) => Promise<void>;
  stats: {
    thisYearCount: number;
    thisMonthCount: number;
    ongoingCount: number;
    upcomingCount: number;
    totalVolunteerHours: number;
    totalBeneficiaries: number | string;
  };
  pendingApprovalsCount: number;
  triggerConfetti: () => void;
  isFirebaseSynced: boolean;
  isAdmin: boolean;
  isModerator: boolean;
  canPost: boolean;
  updateVolunteerRole: (volunteerId: string, newRole: AdminRole) => Promise<void>;
  updateVolunteerDetails: (volunteerId: string, data: Partial<Volunteer>) => Promise<void>;
  approveRoleRequest: (volunteerId: string) => Promise<void>;
  declineRoleRequest: (volunteerId: string) => Promise<void>;
  dismissPendingPromotionNotice: () => Promise<void>;
  adminUpdateVolunteerRole: (volunteerId: string, roleInVBD: VBDRole, adminRole?: AdminRole, boardType?: BoardType) => Promise<void>;
  removeVolunteer: (volunteerId: string) => Promise<void>;
  selectedProjectModal: ProjectMeeting | null;
  setSelectedProjectModal: (p: ProjectMeeting | null) => void;
  handleNotificationClick: (notif: AppNotification) => void;
  viewingVolunteer: Volunteer | null;
  setViewingVolunteer: (vol: Volunteer | null) => void;
  openVolunteerProfile: (vol: Volunteer) => void;
  ensureVolunteersLoaded: (forceFresh?: boolean) => Promise<Volunteer[] | null | void>;
  loadVolunteerByIdOrCode: (idOrCode: string) => Promise<Volunteer | null>;
  ensureRadioLoaded: (forceFresh?: boolean) => Promise<RadioBroadcast[] | null | void>;
  ensureNeedAssessmentsLoaded: (forceFresh?: boolean) => Promise<NeedAssessment[] | null | void>;
  ensureBoardPhotosLoaded: (forceFresh?: boolean) => Promise<BoardPhoto[] | null | void>;
  ensureActivityLogsLoaded: (forceFresh?: boolean) => Promise<ActivityLog[] | null | void>;
  refreshData: () => Promise<void>;
  isRefreshing: boolean;
}

export const isPermanentAdminEmail = (email?: string): boolean => {
  if (!email) return false;
  const e = email.toLowerCase().trim();
  return (
    e === 'yellownetwork@gmail.com' ||
    e === 'admin.yellownetwork@gmail.com' ||
    e === 'mdrahat73184@gmail.com'
  );
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const formatNotifTimestamp = () => {
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString([], { month: 'short', day: 'numeric' });
  return `${timeStr} • ${dateStr}`;
};

export const getReadNotificationIds = (): Set<string> => {
  try {
    const raw = safeStorage.getItem<string[]>('yellow_army_read_notif_ids', []);
    return new Set(Array.isArray(raw) ? raw : []);
  } catch {
    return new Set();
  }
};

export const filterAndSortNotifications = (list: AppNotification[]): AppNotification[] => {
  const readIds = getReadNotificationIds();
  return deduplicateById(list)
    .filter((n) => n.id !== 'notif-1' && !n.title?.includes('Welcome to Yellow Army Platform'))
    .map((n) => (readIds.has(n.id) ? { ...n, read: true } : n))
    .sort((a, b) => {
      const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      if (timeA && timeB && timeA !== timeB) return timeB - timeA;
      return (b.id || '').localeCompare(a.id || '');
    });
};

// Module-level cache TTL (60 minutes) to eliminate redundant reads during continuous navigation
const CACHE_TTL_MS = 60 * 60 * 1000;

export const isCacheValid = (key: string): boolean => {
  const ts = safeStorage.getItem<number>(`yellow_army_cache_time_${key}`, 0);
  return typeof ts === 'number' && Date.now() - ts < CACHE_TTL_MS;
};

export const setCacheTimestamp = (key: string): void => {
  safeStorage.setItem(`yellow_army_cache_time_${key}`, Date.now());
};

export const invalidateCache = (key: string): void => {
  safeStorage.removeItem(`yellow_army_cache_time_${key}`);
};

// Module-level in-flight promise to guarantee that authenticated initial fetch runs strictly once across remounts & StrictMode
let globalHomeFetchPromise: Promise<{
  projects: ProjectMeeting[];
  notifications: AppNotification[];
} | null> | null = null;

// Module-level in-memory data store to guarantee ZERO duplicate reads across component remounts & tab switching
export const memoryDataStore = {
  projects: null as ProjectMeeting[] | null,
  notifications: null as AppNotification[] | null,
  volunteers: null as Volunteer[] | null,
  broadcasts: null as RadioBroadcast[] | null,
  needs: null as NeedAssessment[] | null,
  boardPhotos: null as BoardPhoto[] | null,
  activityLogs: null as ActivityLog[] | null,
};

// Module-level persistent cache flags across component remounts, route switches & StrictMode
export const memoryCache = {
  home: false,
  volunteers: false,
  radio: false,
  needs: false,
  boardPhotos: false,
  activityLogs: false,
};

const executeHomeInitialFetch = (forceFresh = false) => {
  // If user is not authenticated in Firebase Auth, strictly 0 reads
  if (!auth.currentUser) {
    return Promise.resolve(null);
  }

  if (forceFresh) {
    globalHomeFetchPromise = null;
    memoryCache.home = false;
    memoryDataStore.projects = null;
    memoryDataStore.notifications = null;
    invalidateCache('home');
  }

  // 1. In-memory data store hit: instant return, 0 reads
  if (!forceFresh && memoryCache.home && memoryDataStore.projects && memoryDataStore.notifications) {
    return Promise.resolve({
      projects: memoryDataStore.projects,
      notifications: memoryDataStore.notifications,
    });
  }

  // 2. In-flight promise reuse: attach to existing fetch, 0 duplicate reads
  if (!forceFresh && globalHomeFetchPromise) {
    return globalHomeFetchPromise;
  }

  // 3. Persistent local storage cache hit within TTL: 0 Firestore reads
  if (!forceFresh && isCacheValid('home')) {
    const savedProjects = safeStorage.getItem<ProjectMeeting[]>('yellow_army_projects', []);
    const savedNotifs = safeStorage.getItem<AppNotification[]>('yellow_army_notifications', []);
    if (Array.isArray(savedProjects) && savedProjects.length > 0) {
      memoryCache.home = true;
      memoryDataStore.projects = savedProjects;
      memoryDataStore.notifications = Array.isArray(savedNotifs) ? savedNotifs : [];
      return Promise.resolve({
        projects: savedProjects,
        notifications: memoryDataStore.notifications,
      });
    }
  }

  // 4. Fresh fetch strictly when required
  globalHomeFetchPromise = (async () => {
    try {
      const [projSnap, notifSnap] = await Promise.all([
        getDocs(query(collection(db, 'projects'), limit(5))),
        getDocs(query(collection(db, 'notifications'), limit(3))),
      ]);

      const projList: ProjectMeeting[] = [];
      if (!projSnap.empty) {
        projSnap.forEach((d) => projList.push(d.data() as ProjectMeeting));
      }

      const notifList: AppNotification[] = [];
      if (!notifSnap.empty) {
        notifSnap.forEach((d) => {
          const data = d.data() as AppNotification;
          if (data.id !== 'notif-1' && !data.title?.includes('Welcome to Yellow Army Platform')) {
            notifList.push(data);
          }
        });
      }

      memoryDataStore.projects = projList;
      memoryDataStore.notifications = notifList;
      memoryCache.home = true;

      if (projList.length > 0) {
        safeStorage.setItem('yellow_army_projects', projList);
      }
      if (notifList.length > 0) {
        safeStorage.setItem('yellow_army_notifications', notifList);
      }
      setCacheTimestamp('home');
      return {
        projects: projList,
        notifications: notifList,
      };
    } catch (err) {
      console.warn('[Home Data Fetch Error]', err);
      globalHomeFetchPromise = null;
      memoryCache.home = false;
      return null;
    }
  })();

  return globalHomeFetchPromise;
};

// Singleton in-flight promises for lazy feature loads
let volunteersFetchPromise: Promise<Volunteer[] | null> | null = null;
let radioFetchPromise: Promise<RadioBroadcast[] | null> | null = null;
let needsFetchPromise: Promise<NeedAssessment[] | null> | null = null;
let boardPhotosFetchPromise: Promise<BoardPhoto[] | null> | null = null;
let activityLogsFetchPromise: Promise<ActivityLog[] | null> | null = null;
let lastLoadedUid: string | null = null;

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language settings: default 'en', stored in safeStorage
  const [language, setLanguageState] = useState<'en' | 'bn'>(() => {
    const saved = safeStorage.getItem<string>('yellow_army_language', 'en');
    return saved === 'bn' ? 'bn' : 'en';
  });

  const setLanguage = (lang: 'en' | 'bn') => {
    setLanguageState(lang);
    safeStorage.setItem('yellow_army_language', lang);
  };

  // State management with safeStorage and automatic deduplication
  const [volunteers, setVolunteers] = useState<Volunteer[]>(() => {
    const saved = safeStorage.getItem<Volunteer[]>('yellow_army_volunteers', INITIAL_VOLUNTEERS);
    const raw = saved && Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_VOLUNTEERS;
    const cleaned = raw.filter(
      (v) =>
        v.id !== 'vol-super-admin-alt' &&
        v.email?.toLowerCase().trim() !== 'admin.yellownetwork@gmail.com'
    );
    safeStorage.setItem('yellow_army_volunteers', cleaned);
    return deduplicateById(cleaned);
  });

  const [projects, setProjects] = useState<ProjectMeeting[]>(() => {
    const saved = safeStorage.getItem<ProjectMeeting[]>('yellow_army_projects', INITIAL_PROJECTS);
    return deduplicateById(saved && Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_PROJECTS);
  });

  const [currentUser, setCurrentUser] = useState<Volunteer | null>(() => {
    const user = safeStorage.getItem<Volunteer | null>('yellow_army_current_user', null);
    if (user && user.id === 'vol-super-admin-alt') {
      safeStorage.removeItem('yellow_army_current_user');
      return null;
    }
    return user;
  });

  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(() => {
    const saved = safeStorage.getItem<ActivityLog[]>('yellow_army_activities', INITIAL_ACTIVITY_LOGS);
    return deduplicateById(saved && Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_ACTIVITY_LOGS);
  });

  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = safeStorage.getItem<AppNotification[]>('yellow_army_notifications', INITIAL_NOTIFICATIONS);
    const raw = saved && Array.isArray(saved) ? saved : INITIAL_NOTIFICATIONS;
    return filterAndSortNotifications(raw);
  });

  const [broadcasts, setBroadcasts] = useState<RadioBroadcast[]>(() => {
    const saved = safeStorage.getItem<RadioBroadcast[]>('yellow_army_broadcasts', INITIAL_BROADCASTS);
    return deduplicateById(saved && Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_BROADCASTS);
  });

  const [needAssessments, setNeedAssessments] = useState<NeedAssessment[]>(() => {
    const saved = safeStorage.getItem<NeedAssessment[]>('yellow_army_needs', INITIAL_NEED_ASSESSMENTS);
    return deduplicateById(saved && Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_NEED_ASSESSMENTS);
  });

  const [boardPhotos, setBoardPhotos] = useState<BoardPhoto[]>(() => {
    const saved = safeStorage.getItem<BoardPhoto[]>('yellow_army_board_photos', INITIAL_BOARD_PHOTOS);
    return deduplicateById(saved && Array.isArray(saved) && saved.length > 0 ? saved : INITIAL_BOARD_PHOTOS);
  });

  const [isFirebaseSynced, setIsFirebaseSynced] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedUpazila, setSelectedUpazila] = useState<UpazilaName | 'District'>('District');
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup' | 'onboarding'>('login');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProjectModal, setSelectedProjectModal] = useState<ProjectMeeting | null>(null);
  const [viewingVolunteer, setViewingVolunteer] = useState<Volunteer | null>(null);

  const openVolunteerProfile = useCallback((vol: Volunteer) => {
    setViewingVolunteer(vol);
    setActiveTab('profile');
  }, []);

  const currentUserRef = useRef<Volunteer | null>(currentUser);
  useEffect(() => {
    currentUserRef.current = currentUser;
  }, [currentUser]);

  const volunteersRef = useRef<Volunteer[]>(volunteers);
  useEffect(() => {
    volunteersRef.current = volunteers;
  }, [volunteers]);

  const broadcastsRef = useRef<RadioBroadcast[]>(broadcasts);
  useEffect(() => {
    broadcastsRef.current = broadcasts;
  }, [broadcasts]);

  const needAssessmentsRef = useRef<NeedAssessment[]>(needAssessments);
  useEffect(() => {
    needAssessmentsRef.current = needAssessments;
  }, [needAssessments]);

  const boardPhotosRef = useRef<BoardPhoto[]>(boardPhotos);
  useEffect(() => {
    boardPhotosRef.current = boardPhotos;
  }, [boardPhotos]);

  const activityLogsRef = useRef<ActivityLog[]>(activityLogs);
  useEffect(() => {
    activityLogsRef.current = activityLogs;
  }, [activityLogs]);

  // Loading flags to guarantee zero duplicate reads once loaded
  const volunteersLoadedRef = useRef<boolean>(false);
  const radioLoadedRef = useRef<boolean>(false);
  const needAssessmentsLoadedRef = useRef<boolean>(false);
  const boardPhotosLoadedRef = useRef<boolean>(false);
  const activityLogsLoadedRef = useRef<boolean>(false);

  // Operational guard refs
  const isAuthActionInProgressRef = useRef<boolean>(false);
  const pendingProjectActionIdsRef = useRef<Set<string>>(new Set());
  const isHomeDataLoadedRef = useRef<boolean>(false);

  // Check if current user is Admin (Permanent Super Admin or Admin role)
  const isAdmin = useMemo(() => {
    if (!currentUser) return false;
    if (isPermanentAdminEmail(currentUser.email)) return true;
    return (
      currentUser.adminRole === 'Super Admin' ||
      currentUser.adminRole === 'District Coordinator'
    );
  }, [currentUser]);

  // Check if current user is Moderator
  const isModerator = useMemo(() => {
    if (!currentUser) return false;
    return currentUser.adminRole === 'Moderator';
  }, [currentUser]);

  // Can create posts/launches: Admins and Moderators
  const canPost = useMemo(() => {
    if (!currentUser) return false;
    return isAdmin || isModerator;
  }, [currentUser, isAdmin, isModerator]);

  // Simple session persistence for authenticated user
  useEffect(() => {
    if (currentUser) {
      safeStorage.setItem('yellow_army_current_user', currentUser);
    } else {
      safeStorage.removeItem('yellow_army_current_user');
    }
  }, [currentUser]);

  // Firebase Authentication State Listener - runs once on mount
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser: FirebaseUser | null) => {
      // Avoid race conditions with active login or registration flows
      if (isAuthActionInProgressRef.current) return;

      if (firebaseUser) {
        const uid = firebaseUser.uid;
        // Avoid redundant document read if user was already loaded during this session or login flow
        if (
          lastLoadedUid === uid ||
          (currentUserRef.current && (currentUserRef.current.firebaseUid === uid || currentUserRef.current.id === uid))
        ) {
          return;
        }

        // Check if safeStorage has cached currentUser matching this uid or email with custom photos
        const cachedUser = safeStorage.getItem<Volunteer | null>('yellow_army_current_user', null);
        const hasCustomPhotos = (user?: Volunteer | null) => {
          if (!user) return false;
          const isCustomAvatar = !!user.avatarUrl && !user.avatarUrl.includes('data:image/svg');
          const isCustomCover = !!user.coverUrl;
          return isCustomAvatar || isCustomCover;
        };

        if (
          cachedUser &&
          (cachedUser.firebaseUid === uid ||
            cachedUser.id === uid ||
            (cachedUser.email && firebaseUser.email && cachedUser.email.toLowerCase() === firebaseUser.email.toLowerCase())) &&
          hasCustomPhotos(cachedUser)
        ) {
          lastLoadedUid = uid;
          currentUserRef.current = cachedUser;
          setCurrentUser(cachedUser);
          return;
        }

        try {
          // Read both volunteers and users documents so custom uploaded photos from either collection are never missed
          const volDocRef = doc(db, 'volunteers', uid);
          const userDocRef = doc(db, 'users', uid);
          const [volSnap, userSnap] = await Promise.all([
            getDoc(volDocRef).catch(() => null),
            getDoc(userDocRef).catch(() => null),
          ]);

          const volData = volSnap && volSnap.exists() ? (volSnap.data() as Volunteer) : null;
          const userData = userSnap && userSnap.exists() ? (userSnap.data() as Volunteer) : null;

          if (volData || userData) {
            const mergedDoc = {
              ...(userData || {}),
              ...(volData || {}),
            };

            // Custom photo prioritization: never overwrite real user photos with default cartoons
            const memoryPhotos =
              inMemoryImageStore.get(uid) ||
              inMemoryImageStore.get((firebaseUser.email || '').toLowerCase());

            const finalAvatar = (() => {
              if (isUserCustomPhoto(volData?.avatarUrl)) return volData!.avatarUrl;
              if (isUserCustomPhoto(userData?.avatarUrl)) return userData!.avatarUrl;
              if (isUserCustomPhoto(cachedUser?.avatarUrl)) return cachedUser!.avatarUrl;
              if (isUserCustomPhoto(memoryPhotos?.avatarUrl)) return memoryPhotos!.avatarUrl;
              if (volData?.avatarUrl && !volData.avatarUrl.includes('data:image/svg') && !volData.avatarUrl.includes('photo-15')) return volData.avatarUrl;
              if (userData?.avatarUrl && !userData.avatarUrl.includes('data:image/svg') && !userData.avatarUrl.includes('photo-15')) return userData.avatarUrl;
              return volData?.avatarUrl || userData?.avatarUrl || cachedUser?.avatarUrl || mergedDoc.avatarUrl || '';
            })();

            const finalCover = (() => {
              if (isUserCustomCover(volData?.coverUrl)) return volData!.coverUrl;
              if (isUserCustomCover(userData?.coverUrl)) return userData!.coverUrl;
              if (isUserCustomCover(cachedUser?.coverUrl)) return cachedUser!.coverUrl;
              if (isUserCustomCover(memoryPhotos?.coverUrl)) return memoryPhotos!.coverUrl;
              return volData?.coverUrl || userData?.coverUrl || cachedUser?.coverUrl;
            })();

            if (isUserCustomPhoto(finalAvatar)) {
              inMemoryImageStore.set(uid, { ...(inMemoryImageStore.get(uid) || {}), avatarUrl: finalAvatar });
              if (firebaseUser.email) inMemoryImageStore.set(firebaseUser.email.toLowerCase(), { ...(inMemoryImageStore.get(firebaseUser.email.toLowerCase()) || {}), avatarUrl: finalAvatar });
            }
            if (isUserCustomCover(finalCover)) {
              inMemoryImageStore.set(uid, { ...(inMemoryImageStore.get(uid) || {}), coverUrl: finalCover });
              if (firebaseUser.email) inMemoryImageStore.set(firebaseUser.email.toLowerCase(), { ...(inMemoryImageStore.get(firebaseUser.email.toLowerCase()) || {}), coverUrl: finalCover });
            }

            const profile: Volunteer = {
              ...(mergedDoc as Volunteer),
              id: mergedDoc.id || uid,
              avatarUrl: finalAvatar || mergedDoc.avatarUrl || '',
              coverUrl: finalCover,
            };

            delete (profile as any).password;
            lastLoadedUid = uid;
            currentUserRef.current = profile;
            setCurrentUser(profile);
            safeStorage.setItem('yellow_army_current_user', profile);

            setVolunteers((prev) => {
              const updated = prev.map((v) =>
                v.id === profile.id ||
                v.firebaseUid === profile.firebaseUid ||
                (v.email && profile.email && v.email.toLowerCase() === profile.email.toLowerCase())
                  ? { ...v, ...profile }
                  : v
              );
              safeStorage.setItem('yellow_army_volunteers', updated);
              return updated;
            });
            return;
          } else {
              // Check if user exists in current volunteers roster by email or UID
              const normEmail = firebaseUser.email ? firebaseUser.email.toLowerCase().trim() : '';
              const matchedVolunteer = volunteersRef.current.find(
                (v) => (v.email && normEmail && v.email.toLowerCase().trim() === normEmail) ||
                       (v.firebaseUid && v.firebaseUid === uid)
              );

              if (matchedVolunteer) {
                const memoryPhotos = inMemoryImageStore.get(uid) || inMemoryImageStore.get(normEmail);
                const bestAvatar = isUserCustomPhoto(matchedVolunteer.avatarUrl)
                  ? matchedVolunteer.avatarUrl
                  : (memoryPhotos?.avatarUrl && isUserCustomPhoto(memoryPhotos.avatarUrl) ? memoryPhotos.avatarUrl : matchedVolunteer.avatarUrl);
                const bestCover = isUserCustomCover(matchedVolunteer.coverUrl)
                  ? matchedVolunteer.coverUrl
                  : (memoryPhotos?.coverUrl && isUserCustomCover(memoryPhotos.coverUrl) ? memoryPhotos.coverUrl : matchedVolunteer.coverUrl);

                const linkedProfile: Volunteer = {
                  ...matchedVolunteer,
                  id: uid,
                  firebaseUid: uid,
                  avatarUrl: bestAvatar,
                  coverUrl: bestCover,
                };
                delete (linkedProfile as any).password;
                lastLoadedUid = uid;
                currentUserRef.current = linkedProfile;
                setCurrentUser(linkedProfile);
                safeStorage.setItem('yellow_army_current_user', linkedProfile);
              } else {
                // User is authenticated in Firebase Auth but has no document yet:
                // Construct clean volunteer profile matching their Firebase credentials
                const memoryPhotos = inMemoryImageStore.get(uid) || inMemoryImageStore.get((firebaseUser.email || '').toLowerCase());
                const initialAvatar = (memoryPhotos?.avatarUrl && isUserCustomPhoto(memoryPhotos.avatarUrl))
                  ? memoryPhotos.avatarUrl
                  : (firebaseUser.photoURL || getCartoonYellowAvatar('Male', firebaseUser.displayName || 'Volunteer'));
                const initialCover = (memoryPhotos?.coverUrl && isUserCustomCover(memoryPhotos.coverUrl))
                  ? memoryPhotos.coverUrl
                  : undefined;

                const isTargetAdmin = isPermanentAdminEmail(firebaseUser.email || '');
                const usedCodes = new Set(volunteersRef.current.map((v) => (v.volunteerIdCode || '').toUpperCase().trim()));
                let nextCode = volunteersRef.current.length + 1;
                while (usedCodes.has(`YA-MYN-${String(nextCode).padStart(3, '0')}`)) {
                  nextCode++;
                }
                const codeNum = String(nextCode).padStart(3, '0');
                const initialPoints = 90;
                const levelInfo = calculateVolunteerLevel(initialPoints);
                const newProfile: Volunteer = {
                  id: uid,
                  firebaseUid: uid,
                  email: firebaseUser.email || '',
                  fullName: firebaseUser.displayName || (firebaseUser.email ? firebaseUser.email.split('@')[0].toUpperCase() : 'VOLUNTEER'),
                  mobileNo: firebaseUser.phoneNumber || '+8801700000000',
                  roleInVBD: isTargetAdmin ? 'Board Member' : 'General Member',
                  boardType: isTargetAdmin ? 'District Board' : undefined,
                  adminRole: isTargetAdmin ? 'Super Admin' : 'General Member',
                  upazila: 'Mymensingh Sadar',
                  bloodGroup: 'B+',
                  isBloodDonor: true,
                  gender: 'Male',
                  dateOfBirth: '2000-01-01',
                  volunteerIdCode: isTargetAdmin ? 'YA-MYN-001' : `YA-MYN-${codeNum}`,
                  joinDate: new Date().toISOString().split('T')[0],
                  totalVolunteerHours: isTargetAdmin ? 350 : 10,
                  projectsAttendedCount: isTargetAdmin ? 48 : 1,
                  xp: isTargetAdmin ? 4200 : initialPoints,
                  volunteeringScore: isTargetAdmin ? 4200 : initialPoints,
                  dhp: isTargetAdmin ? 850 : initialPoints,
                  dhpPoints: isTargetAdmin ? 850 : initialPoints,
                  rankName: levelInfo.levelTitle,
                  level: `${levelInfo.levelTitle} (${levelInfo.levelCode})`,
                  badges: [],
                  status: 'active',
                  isOnline: true,
                  avatarUrl: initialAvatar,
                  coverUrl: initialCover,
                };
                try {
                  await setDoc(doc(db, 'users', uid), cleanFirestoreData(newProfile), { merge: true });
                  await setDoc(doc(db, 'volunteers', uid), cleanFirestoreData(newProfile), { merge: true });
                } catch {}
                lastLoadedUid = uid;
                currentUserRef.current = newProfile;
                setCurrentUser(newProfile);
                safeStorage.setItem('yellow_army_current_user', newProfile);
                setVolunteers((prev) => deduplicateById([newProfile, ...prev]));
              }
            }
          } catch (e) {
          console.warn('[Auth State Sync Error]', e);
        }
      } else {
        lastLoadedUid = null;
        currentUserRef.current = null;
        setCurrentUser(null);
        safeStorage.removeItem('yellow_army_current_user');
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Lazy loaders: fetch collections strictly on demand and memoize results with retry on error
  const ensureVolunteersLoaded = useCallback(async (forceFresh = false) => {
    // 0. If user is logged out, strictly 0 reads
    if (!auth.currentUser && !currentUserRef.current) {
      return memoryDataStore.volunteers || volunteersRef.current;
    }

    // 1. If already loaded in memoryDataStore, return immediately with 0 reads
    if (!forceFresh && (volunteersLoadedRef.current || memoryCache.volunteers)) {
      if (memoryDataStore.volunteers && memoryDataStore.volunteers.length > 0) {
        return memoryDataStore.volunteers;
      }
      return;
    }

    // 2. Persistent local storage cache hit within TTL: 0 Firestore reads
    if (!forceFresh && isCacheValid('volunteers')) {
      const saved = safeStorage.getItem<Volunteer[]>('yellow_army_volunteers', []);
      if (Array.isArray(saved) && saved.length > 0) {
        const cleaned = saved.filter((v) => v.id !== 'vol-super-admin-alt');
        // If photos were stripped from localStorage, don't use stale photo-less cache; fetch fresh!
        const hasCustomPhotos = cleaned.some((v) => isUserCustomPhoto(v.avatarUrl));
        if (hasCustomPhotos) {
          volunteersLoadedRef.current = true;
          memoryCache.volunteers = true;
          memoryDataStore.volunteers = cleaned;
          setVolunteers(cleaned);
          return cleaned;
        }
      }
    }

    if (forceFresh) {
      volunteersFetchPromise = null;
      volunteersLoadedRef.current = false;
      memoryCache.volunteers = false;
      memoryDataStore.volunteers = null;
      invalidateCache('volunteers');
    }

    if (!volunteersFetchPromise) {
      // In-memory cache hit: 0 reads
      if (!forceFresh && memoryCache.volunteers && memoryDataStore.volunteers && memoryDataStore.volunteers.length >= 3) {
        return memoryDataStore.volunteers;
      }

      volunteersFetchPromise = (async () => {
        try {
          // Query both 'volunteers' and 'users' collections so custom uploaded avatars/covers in volunteers are retrieved
          const [volSnap, userSnap] = await Promise.all([
            getDocs(query(collection(db, 'volunteers'), limit(45))).catch(() => null),
            getDocs(query(collection(db, 'users'), limit(45))).catch(() => null),
          ]);

          const rawList: Volunteer[] = [];
          if (volSnap && !volSnap.empty) {
            volSnap.forEach((d) => rawList.push({ ...d.data(), id: d.id } as Volunteer));
          }
          if (userSnap && !userSnap.empty) {
            userSnap.forEach((d) => rawList.push({ ...d.data(), id: d.id } as Volunteer));
          }

          // Ensure current user is included if present
          if (currentUserRef.current) {
            rawList.push(currentUserRef.current);
          }

          // Filter out legacy mock account vol-super-admin-alt
          const cleanedRaw = rawList.filter((v) => v.id !== 'vol-super-admin-alt');

          // Purge legacy doc from Firestore in background if present
          try {
            deleteDoc(doc(db, 'users', 'vol-super-admin-alt')).catch(() => null);
            deleteDoc(doc(db, 'volunteers', 'vol-super-admin-alt')).catch(() => null);
          } catch {}

          const { merged } = mergeAndDeduplicateVolunteers(cleanedRaw);

          // Guarantee strictly unique volunteerIdCode for all users
          const assignedCodeSet = new Set<string>();
          let fallbackCodeNum = 1;
          const finalizedList: Volunteer[] = merged.map((v) => {
            let code = (v.volunteerIdCode || '').trim().toUpperCase();
            if (!code || assignedCodeSet.has(code)) {
              while (assignedCodeSet.has(`YA-MYN-${String(fallbackCodeNum).padStart(3, '0')}`)) {
                fallbackCodeNum++;
              }
              code = `YA-MYN-${String(fallbackCodeNum).padStart(3, '0')}`;
              fallbackCodeNum++;
            }
            assignedCodeSet.add(code);
            return {
              ...v,
              volunteerIdCode: code,
            };
          });

          // Cache all discovered custom photos in inMemoryImageStore
          for (const v of finalizedList) {
            if (isUserCustomPhoto(v.avatarUrl) || isUserCustomCover(v.coverUrl)) {
              if (v.id) {
                inMemoryImageStore.set(v.id, {
                  avatarUrl: v.avatarUrl,
                  coverUrl: v.coverUrl,
                });
              }
              if (v.email) {
                inMemoryImageStore.set(v.email.toLowerCase(), {
                  avatarUrl: v.avatarUrl,
                  coverUrl: v.coverUrl,
                });
              }
            }
          }

          // Sync matching photos to currentUser if they had default photos
          if (currentUserRef.current) {
            const myEmail = (currentUserRef.current.email || '').toLowerCase().trim();
            const myId = currentUserRef.current.id;
            const myUid = currentUserRef.current.firebaseUid;
            const matching = finalizedList.find(
              (v) =>
                (myId && v.id === myId) ||
                (myUid && (v.firebaseUid === myUid || v.id === myUid)) ||
                (myEmail && v.email && v.email.toLowerCase().trim() === myEmail)
            );
            if (matching) {
              const bestAvatar = isUserCustomPhoto(matching.avatarUrl)
                ? matching.avatarUrl
                : currentUserRef.current.avatarUrl;
              const bestCover = isUserCustomCover(matching.coverUrl)
                ? matching.coverUrl
                : currentUserRef.current.coverUrl;

              if (
                bestAvatar !== currentUserRef.current.avatarUrl ||
                bestCover !== currentUserRef.current.coverUrl
              ) {
                const refreshedUser: Volunteer = {
                  ...currentUserRef.current,
                  avatarUrl: bestAvatar,
                  coverUrl: bestCover,
                };
                currentUserRef.current = refreshedUser;
                setCurrentUser(refreshedUser);
                safeStorage.setItem('yellow_army_current_user', refreshedUser);
              }
            }
          }

          volunteersLoadedRef.current = true;
          memoryCache.volunteers = true;
          memoryDataStore.volunteers = finalizedList;
          setVolunteers(finalizedList);
          safeStorage.setItem('yellow_army_volunteers', finalizedList);
          setCacheTimestamp('volunteers');
          return finalizedList;
        } catch (err) {
          console.warn('[Fetch Volunteers Error]', err);
          volunteersFetchPromise = null; // Reset so retry is possible
          volunteersLoadedRef.current = false;
          memoryCache.volunteers = false;
          return null;
        }
      })();
    }
    const res = await volunteersFetchPromise;
    if (res !== null) {
      volunteersLoadedRef.current = true;
      memoryCache.volunteers = true;
      memoryDataStore.volunteers = res;
    }
    return res;
  }, []);

  // Targeted single-volunteer loader for QR / link verification (avoids full collection download)
  const loadVolunteerByIdOrCode = useCallback(async (idOrCode: string): Promise<Volunteer | null> => {
    const cleanQuery = idOrCode.trim();
    if (!cleanQuery) return null;

    // 1. Check local state first (using volunteersRef and memoryDataStore for zero re-triggers)
    const activeList = memoryDataStore.volunteers || volunteersRef.current;
    const localMatch = activeList.find(
      (v) =>
        v.id === cleanQuery ||
        v.id?.toLowerCase() === cleanQuery.toLowerCase() ||
        v.volunteerIdCode?.toLowerCase() === cleanQuery.toLowerCase()
    );
    if (localMatch) return localMatch;

    // If logged out, do not query Firestore
    if (!auth.currentUser && !currentUserRef.current) {
      return null;
    }

    // 2. Targeted direct document read by doc ID (strictly 1 read)
    try {
      const directDocRef = doc(db, 'volunteers', cleanQuery);
      const directSnap = await getDoc(directDocRef).catch(() => null);
      if (directSnap && directSnap.exists()) {
        const found = directSnap.data() as Volunteer;
        setVolunteers((prev) => {
          const next = deduplicateById([found, ...prev]);
          memoryDataStore.volunteers = next;
          safeStorage.setItem('yellow_army_volunteers', next);
          return next;
        });
        return found;
      }
    } catch (e) {
      console.warn('[loadVolunteerByIdOrCode direct check error]', e);
    }

    // 3. Targeted query by volunteerIdCode (strictly 1 read)
    try {
      const codeQuery = query(collection(db, 'volunteers'), where('volunteerIdCode', '==', cleanQuery), limit(1));
      const codeSnap = await getDocs(codeQuery).catch(() => null);
      if (codeSnap && !codeSnap.empty) {
        const found = codeSnap.docs[0].data() as Volunteer;
        setVolunteers((prev) => {
          const next = deduplicateById([found, ...prev]);
          memoryDataStore.volunteers = next;
          safeStorage.setItem('yellow_army_volunteers', next);
          return next;
        });
        return found;
      }
    } catch (e) {
      console.warn('[loadVolunteerByIdOrCode query error]', e);
    }

    return null;
  }, []);

  const ensureRadioLoaded = useCallback(async (forceFresh = false) => {
    // If logged out, strictly 0 reads
    if (!auth.currentUser && !currentUserRef.current) {
      return memoryDataStore.broadcasts || broadcastsRef.current;
    }

    if (!forceFresh && (radioLoadedRef.current || memoryCache.radio)) {
      if (memoryDataStore.broadcasts && memoryDataStore.broadcasts.length > 0) {
        return memoryDataStore.broadcasts;
      }
      return;
    }
    if (forceFresh) {
      radioFetchPromise = null;
      radioLoadedRef.current = false;
      memoryCache.radio = false;
      memoryDataStore.broadcasts = null;
      invalidateCache('radio');
    }

    if (!radioFetchPromise) {
      if (!forceFresh && isCacheValid('radio')) {
        const saved = safeStorage.getItem<RadioBroadcast[]>('yellow_army_broadcasts', []);
        if (Array.isArray(saved) && saved.length > 0) {
          radioLoadedRef.current = true;
          memoryCache.radio = true;
          memoryDataStore.broadcasts = saved;
          radioFetchPromise = Promise.resolve(saved);
          return saved;
        }
      }

      radioFetchPromise = (async () => {
        try {
          const radSnap = await getDocs(query(collection(db, 'radioBroadcasts'), limit(4)));
          const list: RadioBroadcast[] = [];
          if (!radSnap.empty) {
            radSnap.forEach((d) => list.push(d.data() as RadioBroadcast));
          }
          const deduped = deduplicateById(list);
          radioLoadedRef.current = true;
          memoryCache.radio = true;
          memoryDataStore.broadcasts = deduped;
          setBroadcasts(deduped);
          safeStorage.setItem('yellow_army_broadcasts', deduped);
          setCacheTimestamp('radio');
          return deduped;
        } catch (err) {
          console.warn('[Fetch Radio Error]', err);
          radioFetchPromise = null;
          radioLoadedRef.current = false;
          memoryCache.radio = false;
          return null;
        }
      })();
    }
    const res = await radioFetchPromise;
    if (res !== null) {
      radioLoadedRef.current = true;
      memoryCache.radio = true;
      memoryDataStore.broadcasts = res;
    }
    return res;
  }, []);

  const ensureNeedAssessmentsLoaded = useCallback(async (forceFresh = false) => {
    // If logged out, strictly 0 reads
    if (!auth.currentUser && !currentUserRef.current) {
      return memoryDataStore.needs || needAssessmentsRef.current;
    }

    if (!forceFresh && (needAssessmentsLoadedRef.current || memoryCache.needs)) {
      if (memoryDataStore.needs && memoryDataStore.needs.length > 0) {
        return memoryDataStore.needs;
      }
      return;
    }
    if (forceFresh) {
      needsFetchPromise = null;
      needAssessmentsLoadedRef.current = false;
      memoryCache.needs = false;
      memoryDataStore.needs = null;
      invalidateCache('needs');
    }

    if (!needsFetchPromise) {
      if (!forceFresh && isCacheValid('needs')) {
        const saved = safeStorage.getItem<NeedAssessment[]>('yellow_army_needs', []);
        if (Array.isArray(saved) && saved.length > 0) {
          needAssessmentsLoadedRef.current = true;
          memoryCache.needs = true;
          memoryDataStore.needs = saved;
          needsFetchPromise = Promise.resolve(saved);
          return saved;
        }
      }

      needsFetchPromise = (async () => {
        try {
          const needSnap = await getDocs(query(collection(db, 'needAssessments'), limit(4)));
          const list: NeedAssessment[] = [];
          if (!needSnap.empty) {
            needSnap.forEach((d) => list.push(d.data() as NeedAssessment));
          }
          const deduped = deduplicateById(list);
          needAssessmentsLoadedRef.current = true;
          memoryCache.needs = true;
          memoryDataStore.needs = deduped;
          setNeedAssessments(deduped);
          safeStorage.setItem('yellow_army_needs', deduped);
          setCacheTimestamp('needs');
          return deduped;
        } catch (err) {
          console.warn('[Fetch Needs Error]', err);
          needsFetchPromise = null;
          needAssessmentsLoadedRef.current = false;
          memoryCache.needs = false;
          return null;
        }
      })();
    }
    const res = await needsFetchPromise;
    if (res !== null) {
      needAssessmentsLoadedRef.current = true;
      memoryCache.needs = true;
      memoryDataStore.needs = res;
    }
    return res;
  }, []);

  const ensureBoardPhotosLoaded = useCallback(async (forceFresh = false) => {
    // If logged out, strictly 0 reads
    if (!auth.currentUser && !currentUserRef.current) {
      return memoryDataStore.boardPhotos || boardPhotosRef.current;
    }

    if (!forceFresh && (boardPhotosLoadedRef.current || memoryCache.boardPhotos)) {
      if (memoryDataStore.boardPhotos && memoryDataStore.boardPhotos.length > 0) {
        return memoryDataStore.boardPhotos;
      }
      return;
    }
    if (forceFresh) {
      boardPhotosFetchPromise = null;
      boardPhotosLoadedRef.current = false;
      memoryCache.boardPhotos = false;
      memoryDataStore.boardPhotos = null;
      invalidateCache('boardPhotos');
    }

    if (!boardPhotosFetchPromise) {
      if (!forceFresh && isCacheValid('boardPhotos')) {
        const saved = safeStorage.getItem<BoardPhoto[]>('yellow_army_board_photos', []);
        if (Array.isArray(saved) && saved.length > 0) {
          boardPhotosLoadedRef.current = true;
          memoryCache.boardPhotos = true;
          memoryDataStore.boardPhotos = saved;
          boardPhotosFetchPromise = Promise.resolve(saved);
          return saved;
        }
      }

      boardPhotosFetchPromise = (async () => {
        try {
          const photoSnap = await getDocs(query(collection(db, 'boardPhotos'), limit(3)));
          const list: BoardPhoto[] = [];
          if (!photoSnap.empty) {
            photoSnap.forEach((d) => list.push(d.data() as BoardPhoto));
          }
          const deduped = deduplicateById(list);
          boardPhotosLoadedRef.current = true;
          memoryCache.boardPhotos = true;
          memoryDataStore.boardPhotos = deduped;
          setBoardPhotos(deduped);
          safeStorage.setItem('yellow_army_board_photos', deduped);
          setCacheTimestamp('boardPhotos');
          return deduped;
        } catch (err) {
          console.warn('[Fetch Board Photos Error]', err);
          boardPhotosFetchPromise = null;
          boardPhotosLoadedRef.current = false;
          memoryCache.boardPhotos = false;
          return null;
        }
      })();
    }
    const res = await boardPhotosFetchPromise;
    if (res !== null) {
      boardPhotosLoadedRef.current = true;
      memoryCache.boardPhotos = true;
      memoryDataStore.boardPhotos = res;
    }
    return res;
  }, []);

  const ensureActivityLogsLoaded = useCallback(async (forceFresh = false) => {
    // If logged out, strictly 0 reads
    if (!auth.currentUser && !currentUserRef.current) {
      return memoryDataStore.activityLogs || activityLogsRef.current;
    }

    if (!forceFresh && (activityLogsLoadedRef.current || memoryCache.activityLogs)) {
      if (memoryDataStore.activityLogs && memoryDataStore.activityLogs.length > 0) {
        return memoryDataStore.activityLogs;
      }
      return;
    }
    if (forceFresh) {
      activityLogsFetchPromise = null;
      activityLogsLoadedRef.current = false;
      memoryCache.activityLogs = false;
      memoryDataStore.activityLogs = null;
      invalidateCache('activityLogs');
    }

    if (!activityLogsFetchPromise) {
      if (!forceFresh && isCacheValid('activityLogs')) {
        const saved = safeStorage.getItem<ActivityLog[]>('yellow_army_activities', []);
        if (Array.isArray(saved) && saved.length > 0) {
          activityLogsLoadedRef.current = true;
          memoryCache.activityLogs = true;
          memoryDataStore.activityLogs = saved;
          activityLogsFetchPromise = Promise.resolve(saved);
          return saved;
        }
      }

      activityLogsFetchPromise = (async () => {
        try {
          const actSnap = await getDocs(query(collection(db, 'activityLogs'), limit(4)));
          const list: ActivityLog[] = [];
          if (!actSnap.empty) {
            actSnap.forEach((d) => list.push(d.data() as ActivityLog));
          }
          list.sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));
          const deduped = deduplicateById(list);
          activityLogsLoadedRef.current = true;
          memoryCache.activityLogs = true;
          memoryDataStore.activityLogs = deduped;
          setActivityLogs(deduped);
          safeStorage.setItem('yellow_army_activities', deduped);
          setCacheTimestamp('activityLogs');
          return deduped;
        } catch (err) {
          console.warn('[Fetch Activity Logs Error]', err);
          activityLogsFetchPromise = null;
          activityLogsLoadedRef.current = false;
          memoryCache.activityLogs = false;
          return null;
        }
      })();
    }
    const res = await activityLogsFetchPromise;
    if (res !== null) {
      activityLogsLoadedRef.current = true;
      memoryCache.activityLogs = true;
      memoryDataStore.activityLogs = res;
    }
    return res;
  }, []);

  // Manual cloud refresh triggered by user clicking the refresh button in Navbar
  const refreshData = useCallback(async () => {
    setIsRefreshing(true);

    try {
      if (activeTab === 'home' || activeTab === 'calendar') {
        memoryCache.home = false;
        const homeData = await executeHomeInitialFetch(true);
        if (homeData) {
          if (homeData.projects.length > 0) setProjects(deduplicateById(homeData.projects));
          if (homeData.notifications.length > 0) setNotifications(filterAndSortNotifications(homeData.notifications));
          isHomeDataLoadedRef.current = true;
        }
      } else if (activeTab === 'army') {
        memoryCache.volunteers = false;
        await ensureVolunteersLoaded(true);
      } else if (activeTab === 'radio') {
        memoryCache.radio = false;
        await ensureRadioLoaded(true);
      } else if (activeTab === 'admin') {
        memoryCache.volunteers = false;
        await ensureVolunteersLoaded(true);
      } else if (activeTab === 'profile') {
        if (currentUser?.id) {
          lastLoadedUid = null;
          const userDocRef = doc(db, 'users', currentUser.id);
          const snap = await getDoc(userDocRef);
          if (snap.exists()) {
            const profile = snap.data() as Volunteer;
            delete (profile as any).password;
            lastLoadedUid = currentUser.id;
            currentUserRef.current = profile;
            setCurrentUser(profile);
            safeStorage.setItem('yellow_army_current_user', profile);
          }
        }
      }
      setIsFirebaseSynced(true);
    } catch (err) {
      console.warn('[Manual Refresh Error]', err);
    } finally {
      setIsRefreshing(false);
    }
  }, [activeTab, currentUser?.id, ensureVolunteersLoaded, ensureRadioLoaded]);

  // Fetch only minimal Home screen data (projects and notifications) once per session
  useEffect(() => {
    if (!currentUser?.id) return;
    if (isHomeDataLoadedRef.current) return;
    isHomeDataLoadedRef.current = true;
    let isMounted = true;

    executeHomeInitialFetch().then((data) => {
      if (!isMounted) return;
      if (!data) {
        isHomeDataLoadedRef.current = false; // Allow retry on failure
        return;
      }

      // 1. Projects - deduplicate and preserve local modifications
      if (data.projects.length > 0) {
        setProjects((prev) => {
          const merged = deduplicateById([...prev, ...data.projects]);
          safeStorage.setItem('yellow_army_projects', merged);
          return merged;
        });
      }

      // 2. Notifications
      if (data.notifications.length > 0) {
        setNotifications((prev) => {
          const merged = filterAndSortNotifications([...prev, ...data.notifications]);
          safeStorage.setItem('yellow_army_notifications', merged);
          return merged;
        });
      }

      setIsFirebaseSynced(true);
    });

    return () => {
      isMounted = false;
    };
  }, [currentUser?.id]);

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 60,
      origin: { y: 0.6 },
      colors: ['#10b981', '#34d399', '#059669', '#f59e0b'],
    });
  };

  // Filter out expired meetings (meetings older than closingTime or 1 day after start)
  const filteredProjectsByMeetingExpiration = useMemo(() => {
    const now = new Date().getTime();
    return projects.filter((p) => {
      if (p.type === 'Meeting') {
        const meetingEnd = new Date(p.closingTime || p.startingTime).getTime();
        if (now > meetingEnd + 24 * 60 * 60 * 1000) {
          return false;
        }
      }
      return true;
    });
  }, [projects]);

  // Dynamically resolve status using user's rules: 24h before = ongoing, past closingTime = completed
  const effectiveProjects = useMemo(() => {
    return filteredProjectsByMeetingExpiration.map((p) => ({
      ...p,
      status: getEffectiveProjectStatus(p),
    }));
  }, [filteredProjectsByMeetingExpiration]);

  // Active (Ongoing + Upcoming) projects
  const activeProjects = useMemo(() => {
    return effectiveProjects.filter((p) => {
      if (p.status !== 'ongoing' && p.status !== 'upcoming') return false;
      if (selectedUpazila === 'District') return true;
      return p.upazilaScope === 'District' || p.upazilaScope === selectedUpazila;
    });
  }, [effectiveProjects, selectedUpazila]);

  // Recent 3 completed projects sorted by finish date descending
  const recentCompletedProjects = useMemo(() => {
    return effectiveProjects
      .filter((p) => {
        const isCompleted = p.status === 'completed' || p.status === 'archived' || isProjectFinished(p);
        const isProj = !p.type || p.type.toLowerCase() === 'project';
        return isProj && isCompleted;
      })
      .sort((a, b) => {
        const timeA = new Date(a.closingTime || a.startingTime || a.createdAt || 0).getTime();
        const timeB = new Date(b.closingTime || b.startingTime || b.createdAt || 0).getTime();
        return timeB - timeA;
      })
      .slice(0, 3);
  }, [effectiveProjects]);

  // Top projects (managed by admin)
  const topProjects = useMemo(() => {
    return effectiveProjects.filter((p) => p.isTopProject && p.type === 'Project');
  }, [effectiveProjects]);

  // Stats calculation
  const stats = useMemo(() => {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth();

    let thisYearCount = 0;
    let thisMonthCount = 0;
    let ongoingCount = 0;
    let upcomingCount = 0;

    effectiveProjects.forEach((p) => {
      const pDate = new Date(p.startingTime || p.createdAt);
      if (pDate.getFullYear() === currentYear) {
        thisYearCount += 1;
      }
      if (pDate.getFullYear() === currentYear && pDate.getMonth() === currentMonth) {
        thisMonthCount += 1;
      }
      if (p.status === 'ongoing') {
        ongoingCount += 1;
      }
      if (p.status === 'upcoming') {
        upcomingCount += 1;
      }
    });

    const totalVolunteerHours = volunteers.reduce((acc, v) => acc + (v.totalVolunteerHours || 0), 0);
    const totalBeneficiaries = '2.5K+';

    return {
      thisYearCount,
      thisMonthCount,
      ongoingCount,
      upcomingCount,
      totalVolunteerHours,
      totalBeneficiaries,
    };
  }, [effectiveProjects, volunteers]);

  const unreadNotificationCount = useMemo(() => {
    return notifications.filter((n) => !n.read).length;
  }, [notifications]);

  // Pending role approvals count (for Admin red dot notification)
  const pendingApprovalsCount = useMemo(() => {
    return volunteers.filter((v) => {
      if (!v.pendingRole) return false;
      const pr = v.pendingRole.trim().toLowerCase();
      return (pr === 'board member' || pr === 'alumni') && v.roleInVBD !== v.pendingRole;
    }).length;
  }, [volunteers]);

  // Auth Handlers
  const openAuthModal = (mode: 'login' | 'signup' | 'onboarding' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const loginWithEmail = async (identifier: string, pass: string): Promise<{ success: boolean; error?: string }> => {
    const raw = identifier.trim();
    if (!raw) {
      return {
        success: false,
        error: language === 'bn' ? 'অনুগ্রহ করে আপনার ইমেইল বা আইডি লিখুন।' : 'Please enter your Email, Mobile Number, or Volunteer ID.',
      };
    }
    if (!pass) {
      return {
        success: false,
        error: language === 'bn' ? 'অনুগ্রহ করে পাসওয়ার্ড লিখুন।' : 'Please enter your password.',
      };
    }

    let emailToUse = raw;
    const isEmailFormat = raw.includes('@');

    // If identifier is Volunteer ID or phone number, find corresponding email
    if (!isEmailFormat) {
      const normalized = raw.toLowerCase();
      const normCleanCode = normalized.replace(/[^a-z0-9]/g, '');
      const normPhone = normalizePhoneDigits(raw);

      const match = volunteers.find((v) => {
        const vCode = (v.volunteerIdCode || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        const vId = (v.id || '').toLowerCase();
        const vPhone = normalizePhoneDigits(v.mobileNo || '');
        return (
          vCode === normCleanCode ||
          vId === normalized ||
          (normPhone.length >= 6 && vPhone === normPhone)
        );
      });

      if (match && match.email) {
        emailToUse = match.email;
      } else {
        return {
          success: false,
          error: language === 'bn'
            ? 'এই আইডি বা ফোন নম্বরে কোনো ভলান্টিয়ার অ্যাকাউন্ট পাওয়া যায়নি।'
            : 'No volunteer found with this ID or phone number. Please use your registered email address.',
        };
      }
    }

    try {
      isAuthActionInProgressRef.current = true;
      const normEmail = normalizeEmail(emailToUse);
      const isTargetAdmin = isPermanentAdminEmail(normEmail);

      // 1. Authenticate with Firebase Authentication
      let userCredential: any = null;
      let uid: string = '';
      let firebaseUser: FirebaseUser | null = null;

      try {
        userCredential = await signInWithEmailAndPassword(auth, emailToUse, pass);
        firebaseUser = userCredential.user;
        uid = firebaseUser!.uid;
      } catch (authErr: any) {
        if (authErr?.code === 'auth/user-not-found' || authErr?.code === 'auth/invalid-credential') {
          // If volunteer account exists in seed/roster and user signs in for the first time, link their password in Firebase Auth
          const existingVolunteer = volunteers.find((v) => normalizeEmail(v.email) === normEmail) ||
            (isPermanentAdminEmail(normEmail) ? INITIAL_VOLUNTEERS.find((v) => isPermanentAdminEmail(v.email)) : null);

          if (existingVolunteer) {
            try {
              userCredential = await createUserWithEmailAndPassword(auth, emailToUse, pass);
              firebaseUser = userCredential.user;
              uid = firebaseUser!.uid;
            } catch {
              throw authErr;
            }
          } else {
            throw authErr;
          }
        } else {
          throw authErr;
        }
      }

      // 2. Fetch or create Firestore user profile from both collections to preserve custom uploaded photos
      let volunteerProfile: Volunteer;
      let readFailed = false;
      let mergedData: any = null;

      if (uid) {
        try {
          const volDocRef = doc(db, 'volunteers', uid);
          const userDocRef = doc(db, 'users', uid);
          const [volSnap, userSnap] = await Promise.all([
            getDoc(volDocRef).catch(() => null),
            getDoc(userDocRef).catch(() => null),
          ]);
          if ((volSnap && volSnap.exists()) || (userSnap && userSnap.exists())) {
            const vData = volSnap && volSnap.exists() ? (volSnap.data() as Volunteer) : ({} as any);
            const uData = userSnap && userSnap.exists() ? (userSnap.data() as Volunteer) : ({} as any);
            mergedData = { ...uData, ...vData };

            // Prioritize custom non-SVG avatar
            if (isUserCustomPhoto(vData.avatarUrl)) {
              mergedData.avatarUrl = vData.avatarUrl;
            } else if (isUserCustomPhoto(uData.avatarUrl)) {
              mergedData.avatarUrl = uData.avatarUrl;
            } else if (vData.avatarUrl && !vData.avatarUrl.includes('data:image/svg') && !vData.avatarUrl.includes('photo-15')) {
              mergedData.avatarUrl = vData.avatarUrl;
            } else if (uData.avatarUrl && !uData.avatarUrl.includes('data:image/svg') && !uData.avatarUrl.includes('photo-15')) {
              mergedData.avatarUrl = uData.avatarUrl;
            }
            if (isUserCustomCover(vData.coverUrl)) mergedData.coverUrl = vData.coverUrl;
            else if (isUserCustomCover(uData.coverUrl)) mergedData.coverUrl = uData.coverUrl;
          }
        } catch (readErr) {
          console.warn('[loginWithEmail Profile Read Error]', readErr);
          readFailed = true;
        }
      }

      if (readFailed) {
        // Read failed due to network or permissions error; do NOT treat as non-existent!
        const localMatch = volunteers.find((v) => (uid && v.id === uid) || normalizeEmail(v.email) === normEmail);
        if (localMatch) {
          volunteerProfile = localMatch;
        } else {
          return {
            success: false,
            error: language === 'bn' ? 'প্রোফাইল লোড করতে ব্যর্থ হয়েছে। ইন্টারনেট সংযোগ চেক করুন।' : 'Failed to verify profile from database. Please check your network connection.',
          };
        }
      } else if (mergedData) {
        volunteerProfile = mergedData as Volunteer;
        if (isTargetAdmin) {
          volunteerProfile.adminRole = 'Super Admin';
          volunteerProfile.roleInVBD = 'Board Member';
          volunteerProfile.boardType = volunteerProfile.boardType || 'District Board';
        }
      } else {
        const existingVol = volunteers.find((v) => (uid && v.id === uid) || normalizeEmail(v.email) === normEmail) ||
          (isTargetAdmin ? INITIAL_VOLUNTEERS.find((v) => isPermanentAdminEmail(v.email) && normalizeEmail(v.email) === normEmail) : null);
        const usedCodes = new Set(volunteers.map((v) => (v.volunteerIdCode || '').toUpperCase().trim()));
        let nextCode = volunteers.length + 1;
        while (usedCodes.has(`YA-MYN-${String(nextCode).padStart(3, '0')}`)) {
          nextCode++;
        }
        const codeNum = String(nextCode).padStart(3, '0');
        const initialPoints = 90;
        const levelInfo = calculateVolunteerLevel(isTargetAdmin ? 2000 : initialPoints);

        const isRahat = normEmail.includes('mdrahat');
        const isOperations = normEmail === 'admin.yellownetwork@gmail.com';
        const defaultAdminName = isRahat ? 'MD Rahat (Root Admin)' : (isOperations ? 'Yellow Army Operations Admin' : 'Yellow Army Central Admin');
        const defaultAdminCode = isRahat ? 'YA-MYN-000' : (isOperations ? 'YA-MYN-002' : 'YA-MYN-001');

        volunteerProfile = existingVol
          ? {
              ...existingVol,
              id: uid || existingVol.id,
              firebaseUid: uid || existingVol.firebaseUid,
              email: emailToUse,
              adminRole: isTargetAdmin ? 'Super Admin' : (existingVol.adminRole || 'General Member'),
              roleInVBD: isTargetAdmin ? 'Board Member' : (existingVol.roleInVBD || 'General Member'),
              boardType: existingVol.boardType || (isTargetAdmin ? (existingVol.boardType || 'District Board') : undefined),
            }
          : {
              id: uid || (isTargetAdmin ? (isRahat ? 'vol-super-admin-rahat' : 'vol-super-admin-alt') : `vol-${Date.now()}`),
              firebaseUid: uid,
              fullName: isTargetAdmin ? defaultAdminName : (firebaseUser?.displayName || 'Yellow Army Volunteer'),
              email: emailToUse,
              mobileNo: isRahat ? '+8801700000002' : (isOperations ? '+8801700000001' : '+8801700000000'),
              dateOfBirth: '1998-01-01',
              bloodGroup: 'B+',
              gender: 'Male',
              roleInVBD: isTargetAdmin ? 'Board Member' : 'General Member',
              boardType: isTargetAdmin ? 'Upazila Board' : undefined,
              adminRole: isTargetAdmin ? 'Super Admin' : 'General Member',
              upazila: 'Mymensingh Sadar',
              avatarUrl: firebaseUser?.photoURL || getCartoonYellowAvatar('Male', isTargetAdmin ? 'operations-admin' : 'Volunteer'),
              volunteerIdCode: isTargetAdmin ? defaultAdminCode : `YA-MYN-${codeNum}`,
              joinDate: '2023-01-01',
              totalVolunteerHours: isTargetAdmin ? 400 : 10,
              projectsAttendedCount: isTargetAdmin ? 55 : 1,
              xp: isTargetAdmin ? 2000 : initialPoints,
              volunteeringScore: isTargetAdmin ? 2000 : initialPoints,
              dhp: isTargetAdmin ? 500 : initialPoints,
              dhpPoints: isTargetAdmin ? 500 : initialPoints,
              rankName: isTargetAdmin ? 'Master Veteran (L4)' : levelInfo.levelTitle,
              level: isTargetAdmin ? 'Master Veteran (L4)' : `${levelInfo.levelTitle} (${levelInfo.levelCode})`,
              badges: [],
              status: 'active',
              isOnline: true,
            };

        delete (volunteerProfile as any).password;
        if (uid) {
          try {
            await setDoc(doc(db, 'users', uid), cleanFirestoreData(volunteerProfile), { merge: true });
            await setDoc(doc(db, 'volunteers', uid), cleanFirestoreData(volunteerProfile), { merge: true });
          } catch (e) {
            console.warn(e);
          }
        }
      }

      delete (volunteerProfile as any).password;
      if (uid) lastLoadedUid = uid;
      currentUserRef.current = volunteerProfile;
      setCurrentUser(volunteerProfile);
      safeStorage.setItem('yellow_army_current_user', volunteerProfile);

      setVolunteers((prev) => {
        const { merged } = mergeAndDeduplicateVolunteers([volunteerProfile, ...prev]);
        safeStorage.setItem('yellow_army_volunteers', merged);
        return merged;
      });

      setIsAuthModalOpen(false);
      triggerConfetti();

      return { success: true };
    } catch (err: any) {
      console.warn('Firebase login error:', err);
      let message = err?.message || 'Login failed';
      if (err?.code === 'auth/wrong-password' || err?.code === 'auth/invalid-credential') {
        message = language === 'bn' ? 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।' : 'Incorrect password! Please check your credentials.';
      } else if (err?.code === 'auth/user-not-found') {
        message = language === 'bn' ? 'এই ইমেইলে কোনো অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে রেজিস্ট্রেশন করুন।' : 'No account found with this email. Please sign up to register.';
      } else if (err?.code === 'auth/too-many-requests') {
        message = language === 'bn' ? 'অতিরিক্ত চেষ্টার কারণে অ্যাকাউন্ট সাময়িক ব্লক হয়েছে। কিছুক্ষণ পর চেষ্টা করুন।' : 'Too many failed login attempts. Please try again later.';
      }
      return { success: false, error: message };
    } finally {
      isAuthActionInProgressRef.current = false;
    }
  };

  const loginWithGoogle = async (): Promise<{ success: boolean; error?: string }> => {
    try {
      isAuthActionInProgressRef.current = true;
      const result = await signInWithPopup(auth, googleProvider);
      const firebaseUser = result.user;
      const uid = firebaseUser.uid;
      const email = firebaseUser.email || '';
      const displayName = firebaseUser.displayName || 'Yellow Army Volunteer';
      const photoURL = firebaseUser.photoURL || '';

      const userDocRef = doc(db, 'users', uid);
      let userSnap: any = null;
      let volSnap: any = null;
      let readFailed = false;

      try {
        const [uSnap, vSnap] = await Promise.all([
          getDoc(userDocRef).catch(() => null),
          getDoc(doc(db, 'volunteers', uid)).catch(() => null),
        ]);
        userSnap = uSnap;
        volSnap = vSnap;
      } catch (e) {
        console.warn('Google Sign-in profile read error:', e);
        readFailed = true;
      }

      let profileData: Volunteer;

      if (readFailed) {
        const localMatch = volunteers.find((v) => (uid && v.id === uid) || normalizeEmail(v.email) === normalizeEmail(email));
        if (localMatch) {
          profileData = localMatch;
        } else {
          return {
            success: false,
            error: language === 'bn' ? 'প্রোফাইল লোড করতে ব্যর্থ হয়েছে।' : 'Could not fetch your profile. Please check your connection.',
          };
        }
      } else if ((userSnap && userSnap.exists()) || (volSnap && volSnap.exists())) {
        const uData = userSnap && userSnap.exists() ? (userSnap.data() as Volunteer) : ({} as any);
        const vData = volSnap && volSnap.exists() ? (volSnap.data() as Volunteer) : ({} as any);
        profileData = { ...uData, ...vData };
        if (isUserCustomPhoto(vData.avatarUrl)) {
          profileData.avatarUrl = vData.avatarUrl;
        } else if (isUserCustomPhoto(uData.avatarUrl)) {
          profileData.avatarUrl = uData.avatarUrl;
        } else if (vData.avatarUrl && !vData.avatarUrl.includes('data:image/svg') && !vData.avatarUrl.includes('photo-15')) {
          profileData.avatarUrl = vData.avatarUrl;
        } else if (uData.avatarUrl && !uData.avatarUrl.includes('data:image/svg') && !uData.avatarUrl.includes('photo-15')) {
          profileData.avatarUrl = uData.avatarUrl;
        }
        if (isUserCustomCover(vData.coverUrl)) profileData.coverUrl = vData.coverUrl;
        else if (isUserCustomCover(uData.coverUrl)) profileData.coverUrl = uData.coverUrl;
      } else {
        const normEmail = normalizeEmail(email);
        const existingVol = volunteers.find((v) => normalizeEmail(v.email) === normEmail);
        const isTargetAdmin = isPermanentAdminEmail(email);
        const codeNum = String(volunteers.length + 1).padStart(3, '0');
        const initialPoints = 90;
        const levelInfo = calculateVolunteerLevel(initialPoints);

        profileData = existingVol
          ? {
              ...existingVol,
              id: uid,
              firebaseUid: uid,
              email: email || existingVol.email,
              avatarUrl: photoURL || existingVol.avatarUrl,
              adminRole: isTargetAdmin ? 'Super Admin' : (existingVol.adminRole || 'General Member'),
              roleInVBD: isTargetAdmin ? 'Board Member' : (existingVol.roleInVBD || 'General Member'),
            }
          : {
              id: uid,
              firebaseUid: uid,
              fullName: displayName,
              email: email,
              mobileNo: '+8801700000000',
              dateOfBirth: '2001-01-01',
              bloodGroup: 'B+',
              gender: 'Male',
              roleInVBD: isTargetAdmin ? 'Board Member' : 'General Member',
              adminRole: isTargetAdmin ? 'Super Admin' : 'General Member',
              upazila: 'Mymensingh Sadar',
              avatarUrl: photoURL || getCartoonYellowAvatar('Male', displayName),
              volunteerIdCode: isTargetAdmin ? 'YA-MYN-001' : `YA-MYN-${codeNum}`,
              joinDate: new Date().toISOString().split('T')[0],
              totalVolunteerHours: isTargetAdmin ? 350 : 10,
              projectsAttendedCount: isTargetAdmin ? 48 : 1,
              xp: initialPoints,
              volunteeringScore: initialPoints,
              dhp: initialPoints,
              dhpPoints: initialPoints,
              rankName: levelInfo.levelTitle,
              level: `${levelInfo.levelTitle} (${levelInfo.levelCode})`,
              badges: [],
              status: 'active',
              isOnline: true,
            };

        delete (profileData as any).password;
        await setDoc(userDocRef, cleanFirestoreData(profileData), { merge: true });
        await setDoc(doc(db, 'volunteers', uid), cleanFirestoreData(profileData), { merge: true });
      }

      delete (profileData as any).password;
      if (uid) lastLoadedUid = uid;
      currentUserRef.current = profileData;
      setVolunteers((prev) => {
        const { merged } = mergeAndDeduplicateVolunteers([profileData, ...prev]);
        safeStorage.setItem('yellow_army_volunteers', merged);
        return merged;
      });

      setCurrentUser(profileData);
      safeStorage.setItem('yellow_army_current_user', profileData);
      setIsAuthModalOpen(false);
      triggerConfetti();
      return { success: true };
    } catch (err: any) {
      console.warn('Google Sign-In error:', err);
      if (err?.code === 'auth/popup-closed-by-user' || err?.code === 'auth/cancelled-popup-request') {
        return { success: false };
      }
      return {
        success: false,
        error: language === 'bn' ? 'গুগল সাইন-ইন সম্পন্ন করা সম্ভব হয়নি।' : (err?.message || 'Google sign-in failed. Please try again.'),
      };
    } finally {
      isAuthActionInProgressRef.current = false;
    }
  };

  const loginAsVolunteer = (volunteerId: string) => {
    const found = volunteers.find((v) => v.id === volunteerId || v.volunteerIdCode === volunteerId);
    if (!found) return;

    // Security Guard: Prevent demo login into any root admin or administrative account
    if (isPermanentAdminEmail(found.email) || found.adminRole === 'Super Admin' || found.adminRole === 'District Coordinator') {
      console.warn('[Security Guard] Demo login blocked for administrative account:', found.email);
      return;
    }

    delete (found as any).password;
    setCurrentUser(found);
    setIsAuthModalOpen(false);
    triggerConfetti();
  };

  const signUpVolunteer = async (
    data: Omit<Volunteer, 'id' | 'volunteerIdCode' | 'joinDate' | 'totalVolunteerHours' | 'projectsAttendedCount' | 'badges' | 'status' | 'isOnline'> & { password?: string }
  ): Promise<{ success: boolean; error?: string }> => {
    const rawEmail = (data.email || '').trim().toLowerCase();
    const pass = data.password || '';

    if (!rawEmail) {
      return {
        success: false,
        error: language === 'bn' ? 'অনুগ্রহ করে একটি বৈধ ইমেইল এড্রেস দিন।' : 'Please provide a valid email address.',
      };
    }

    if (!pass || pass.length < 6) {
      return {
        success: false,
        error: language === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters long.',
      };
    }

    try {
      // 1. Create account in Firebase Authentication
      let userCredential;
      try {
        userCredential = await createUserWithEmailAndPassword(auth, rawEmail, pass);
      } catch (authErr: any) {
        if (authErr?.code === 'auth/email-already-in-use') {
          // Attempt sign in if credentials match
          try {
            userCredential = await signInWithEmailAndPassword(auth, rawEmail, pass);
          } catch {
            return {
              success: false,
              error: language === 'bn'
                ? 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট রয়েছে। অনুগ্রহ করে লগইন করুন।'
                : 'This email is already registered. Please sign in with your password.',
            };
          }
        } else if (authErr?.code === 'auth/weak-password') {
          return {
            success: false,
            error: language === 'bn' ? 'পাসওয়ার্ডটি অত্যন্ত দুর্বল। অনুগ্রহ করে শক্তিশালী পাসওয়ার্ড দিন।' : 'Password is too weak. Please use a stronger password.',
          };
        } else if (authErr?.code === 'auth/invalid-email') {
          return {
            success: false,
            error: language === 'bn' ? 'ইমেইল ফরম্যাট সঠিক নয়।' : 'Invalid email address format.',
          };
        } else {
          throw authErr;
        }
      }

      const firebaseUser = userCredential.user;
      const uid = firebaseUser.uid;

      if (data.fullName) {
        try {
          await updateFirebaseAuthProfile(firebaseUser, { displayName: data.fullName });
        } catch (e) {
          console.warn('Firebase Auth displayName update error:', e);
        }
      }

      // 2. Build Volunteer Profile using Firebase Auth UID as primary identity
      const isTargetAdmin = isPermanentAdminEmail(rawEmail);
      const isRequestingRestricted = (data.roleInVBD === 'Board Member' || data.roleInVBD === 'Alumni') && !isTargetAdmin;
      const initialRole: VBDRole = isRequestingRestricted ? 'General Member' : (data.roleInVBD || 'General Member');
      const pendingRole: VBDRole | undefined = isRequestingRestricted ? data.roleInVBD : undefined;
      const pendingBoardType: BoardType | undefined = (isRequestingRestricted && data.roleInVBD === 'Board Member') ? data.boardType : undefined;

      const existingCodes = new Set(volunteers.map((v) => (v.volunteerIdCode || '').toUpperCase().trim()));
      let nextNum = volunteers.length + 1;
      while (existingCodes.has(`YA-MYN-${String(nextNum).padStart(3, '0')}`)) {
        nextNum++;
      }
      const codeNum = String(nextNum).padStart(3, '0');
      const cartoonAvatar = getCartoonYellowAvatar(data.gender, data.fullName);
      const initialPoints = 90;
      const levelInfo = calculateVolunteerLevel(initialPoints);

      const newVolunteer: Volunteer = {
        ...data,
        id: uid, // PRIMARY ID IS THE FIREBASE UID
        firebaseUid: uid,
        adminRole: isTargetAdmin ? 'Super Admin' : 'General Member',
        roleInVBD: isTargetAdmin ? (data.roleInVBD || 'Board Member') : initialRole,
        boardType: isTargetAdmin ? (data.boardType || 'District Board') : (!isRequestingRestricted ? data.boardType : undefined),
        pendingRole,
        pendingBoardType,
        volunteerIdCode: isTargetAdmin ? 'YA-MYN-001' : `YA-MYN-${codeNum}`,
        joinDate: new Date().toISOString().split('T')[0],
        totalVolunteerHours: isTargetAdmin ? 350 : 10,
        projectsAttendedCount: isTargetAdmin ? 48 : 1,
        xp: isTargetAdmin ? Math.max(data.xp || 4200, initialPoints) : initialPoints,
        volunteeringScore: isTargetAdmin ? Math.max(data.volunteeringScore || 4200, initialPoints) : initialPoints,
        dhp: isTargetAdmin ? Math.max(data.dhp || 850, initialPoints) : initialPoints,
        dhpPoints: isTargetAdmin ? Math.max(data.dhpPoints || 850, initialPoints) : initialPoints,
        rankName: levelInfo.levelTitle,
        level: `${levelInfo.levelTitle} (${levelInfo.levelCode})`,
        badges: [],
        status: data.roleInVBD === 'Alumni' && !isRequestingRestricted ? 'alumni' : 'active',
        isOnline: true,
        avatarUrl: data.avatarUrl || cartoonAvatar,
      };

      // Ensure no plaintext password in Firestore
      delete (newVolunteer as any).password;

      // 3. Save to Firestore in users/{firebaseUid} and volunteers/{firebaseUid}
      try {
        await setDoc(doc(db, 'users', uid), cleanFirestoreData(newVolunteer));
        await setDoc(doc(db, 'volunteers', uid), cleanFirestoreData(newVolunteer));
      } catch (err) {
        console.warn('Firestore write volunteer profile error:', err);
      }

      setVolunteers((prev) => {
        const { merged } = mergeAndDeduplicateVolunteers([newVolunteer, ...prev]);
        safeStorage.setItem('yellow_army_volunteers', merged);
        return merged;
      });

      setCurrentUser(newVolunteer);
      safeStorage.setItem('yellow_army_current_user', newVolunteer);
      setIsAuthModalOpen(false);
      triggerConfetti();

      // Notifications and Activity Log
      if (isRequestingRestricted && pendingRole) {
        const reqNotif: AppNotification = {
          id: generateUniqueId('notif'),
          title: `[Role Request] ${pendingRole} Application: ${newVolunteer.fullName}`,
          message: `${newVolunteer.fullName} (${newVolunteer.upazila}) selected ${pendingRole} role during registration and is awaiting admin approval.`,
          type: 'role_approval_request',
          timestamp: formatNotifTimestamp(),
          createdAt: new Date().toISOString(),
          read: false,
          upazila: newVolunteer.upazila,
          volunteerId: newVolunteer.id,
          targetTab: 'admin',
        };
        try {
          await setDoc(doc(db, 'notifications', reqNotif.id), cleanFirestoreData(reqNotif));
        } catch (e) {}
        setNotifications((prev) => filterAndSortNotifications([reqNotif, ...prev]));
      }

      const welcomeNotif: AppNotification = {
        id: generateUniqueId('notif'),
        title: `[New Volunteer] Welcome ${newVolunteer.fullName} (${newVolunteer.upazila})`,
        message: `${newVolunteer.fullName} has enlisted in Yellow Army (+90 XP Welcome Bonus). Volunteer ID: ${newVolunteer.volunteerIdCode}.`,
        type: 'announcement',
        timestamp: formatNotifTimestamp(),
        createdAt: new Date().toISOString(),
        read: false,
        upazila: newVolunteer.upazila,
        volunteerId: newVolunteer.id,
        targetTab: 'army',
      };
      try {
        await setDoc(doc(db, 'notifications', welcomeNotif.id), cleanFirestoreData(welcomeNotif));
      } catch (e) {}
      setNotifications((prev) => filterAndSortNotifications([welcomeNotif, ...prev]));

      const newAct: ActivityLog = {
        id: generateUniqueId('act'),
        volunteerId: newVolunteer.id,
        volunteerName: newVolunteer.fullName,
        volunteerAvatar: newVolunteer.avatarUrl,
        action: 'Joined Yellow Army',
        details: `Registered profile as ${newVolunteer.roleInVBD} from ${newVolunteer.upazila}.`,
        timestamp: 'Just now',
        upazila: newVolunteer.upazila,
        type: 'announcement',
      };
      try {
        await setDoc(doc(db, 'activityLogs', newAct.id), cleanFirestoreData(newAct));
      } catch (e) {}
      setActivityLogs((prev) => deduplicateById([newAct, ...prev]));

      return { success: true };
    } catch (err: any) {
      console.warn('Signup error:', err);
      return {
        success: false,
        error: err?.message || 'Failed to create volunteer account. Please check your credentials.',
      };
    }
  };

  const completeOnboarding = async (data: Partial<Volunteer>) => {
    const userEmail = data.email || currentUser?.email || '';
    const isTargetAdmin = isPermanentAdminEmail(userEmail);
    const isRequestingRestricted = (data.roleInVBD === 'Board Member' || data.roleInVBD === 'Alumni') && !isTargetAdmin;
    const initialRole: VBDRole = isRequestingRestricted ? 'General Member' : (data.roleInVBD || 'General Member');
    const pendingRole: VBDRole | undefined = isRequestingRestricted ? data.roleInVBD : undefined;

    if (pendingRole) {
      const notif: AppNotification = {
        id: generateUniqueId('notif'),
        title: `${pendingRole} Approval Request 🛡️`,
        message: `${data.fullName || currentUser?.fullName || 'Volunteer'} has requested role ${pendingRole} during onboarding.`,
        type: 'role_approval_request',
        timestamp: formatNotifTimestamp(),
        createdAt: new Date().toISOString(),
        read: false,
        upazila: data.upazila || currentUser?.upazila || 'Mymensingh Sadar',
      };
      try {
        await setDoc(doc(db, 'notifications', notif.id), cleanFirestoreData(notif));
      } catch (err) {
        console.warn(err);
      }
      setNotifications((prev) => filterAndSortNotifications([notif, ...prev]));
    }

    const targetEmail = normalizeEmail(userEmail);
    const targetPhone = normalizePhoneDigits(data.mobileNo);

    // Look for existing volunteer by currentUser, email, or phone
    const existing = volunteers.find(
      (v) =>
        (currentUser && v.id === currentUser.id) ||
        (targetEmail && !targetEmail.includes('volunteer_') && normalizeEmail(v.email) === targetEmail) ||
        (targetPhone && targetPhone.length >= 10 && normalizePhoneDigits(v.mobileNo) === targetPhone)
    );

    if (existing) {
      const updated: Volunteer = {
        ...existing,
        ...data,
        id: existing.id,
        roleInVBD: initialRole,
        pendingRole,
        avatarUrl: data.avatarUrl || existing.avatarUrl || getCartoonYellowAvatar(data.gender, data.fullName),
      };
      try {
        await setDoc(doc(db, 'volunteers', updated.id), cleanFirestoreData(updated), { merge: true });
      } catch (err) {
        console.warn('Firestore update onboarding error:', err);
      }
      setCurrentUser(updated);
      safeStorage.setItem('yellow_army_current_user', updated);
      setVolunteers((prev) => {
        const { merged } = mergeAndDeduplicateVolunteers([updated, ...prev]);
        safeStorage.setItem('yellow_army_volunteers', merged);
        return merged;
      });
    } else {
      const newId = isTargetAdmin ? 'vol-super-admin' : generateUniqueId('vol');
      const codeNum = String(volunteers.length + 1).padStart(3, '0');
      const newUser: Volunteer = {
        ...data,
        id: newId,
        fullName: data.fullName || 'Yellow Army Volunteer',
        email: data.email || `volunteer_${Date.now()}@yellowarmy.org`,
        mobileNo: data.mobileNo || '+8801700000000',
        dateOfBirth: data.dateOfBirth || '2001-01-01',
        bloodGroup: data.bloodGroup || 'B+',
        gender: data.gender || 'Male',
        roleInVBD: initialRole,
        pendingRole,
        adminRole: isTargetAdmin ? 'Super Admin' : 'General Member',
        upazila: data.upazila || 'Mymensingh Sadar',
        avatarUrl: data.avatarUrl || getCartoonYellowAvatar(data.gender, data.fullName),
        volunteerIdCode: isTargetAdmin ? 'YA-MYN-001' : `YA-MYN-${codeNum}`,
        joinDate: new Date().toISOString().split('T')[0],
        totalVolunteerHours: 12,
        projectsAttendedCount: 1,
        badges: [],
        status: 'active',
        isOnline: true,
      };
      try {
        await setDoc(doc(db, 'volunteers', newUser.id), cleanFirestoreData(newUser));
        await setDoc(doc(db, 'users', newUser.id), cleanFirestoreData(newUser));
      } catch (err) {
        console.warn('Firestore create volunteer in onboarding error:', err);
      }
      setCurrentUser(newUser);
      safeStorage.setItem('yellow_army_current_user', newUser);
      setVolunteers((prev) => {
        const { merged } = mergeAndDeduplicateVolunteers([newUser, ...prev]);
        safeStorage.setItem('yellow_army_volunteers', merged);
        return merged;
      });
    }
    setIsAuthModalOpen(false);
    triggerConfetti();
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('Firebase signOut error:', e);
    }
    lastLoadedUid = null;
    currentUserRef.current = null;
    setCurrentUser(null);
    safeStorage.removeItem('yellow_army_current_user');
  };

  const switchUser = (volunteerId: string) => {
    const found = volunteers.find((v) => v.id === volunteerId);
    if (found) {
      setCurrentUser(found);
    }
  };

  const updateProfile = async (data: Partial<Volunteer>) => {
    if (!currentUser) return;

    // Check role approval workflow:
    // If user changes their role to 'Board Member' or 'Alumni' and they are not already that role or Admin
    const isTargetAdmin =
      isAdmin ||
      isPermanentAdminEmail(currentUser.email) ||
      currentUser.adminRole === 'Super Admin' ||
      currentUser.adminRole === 'District Coordinator';
    const isRequestingRestricted = (data.roleInVBD === 'Board Member' || data.roleInVBD === 'Alumni') && currentUser.roleInVBD !== data.roleInVBD && !isTargetAdmin;

    let finalRoleInVBD = currentUser.roleInVBD;
    let pendingRole: VBDRole | undefined = currentUser.pendingRole;
    let pendingBoardType: BoardType | undefined = currentUser.pendingBoardType;
    let finalBoardType = data.boardType !== undefined ? data.boardType : currentUser.boardType;

    if (isRequestingRestricted && data.roleInVBD) {
      finalRoleInVBD = currentUser.roleInVBD || 'General Member';
      pendingRole = data.roleInVBD;
      if (data.roleInVBD === 'Board Member') {
        pendingBoardType = data.boardType || 'Upazila Board';
      }

      // Send admin notification
      const notif: AppNotification = {
        id: generateUniqueId('notif'),
        title: `${pendingRole} Approval Request 🛡️`,
        message: `${currentUser.fullName} (${currentUser.upazila}) has requested promotion to ${pendingRole}${pendingBoardType ? ` (${pendingBoardType})` : ''}.`,
        type: 'role_approval_request',
        timestamp: formatNotifTimestamp(),
        createdAt: new Date().toISOString(),
        read: false,
        upazila: currentUser.upazila,
        volunteerId: currentUser.id,
        targetTab: 'admin',
      };
      try {
        await setDoc(doc(db, 'notifications', notif.id), cleanFirestoreData(notif));
      } catch (err) {
        console.warn(err);
      }
      setNotifications((prev) => filterAndSortNotifications([notif, ...prev]));
    } else {
      if (data.roleInVBD) {
        finalRoleInVBD = data.roleInVBD;
        pendingRole = undefined;
        pendingBoardType = undefined;
      }
      if (data.boardType) {
        finalBoardType = data.boardType;
      } else if (finalRoleInVBD === 'Board Member') {
        finalBoardType = finalBoardType || currentUser.boardType || 'District Board';
      }
    }

    const nextBoardType = finalRoleInVBD === 'Board Member' ? (data.boardType || finalBoardType || 'District Board') : undefined;

    const updated: Volunteer = {
      ...currentUser,
      ...data,
      roleInVBD: finalRoleInVBD,
      boardType: nextBoardType,
      pendingRole,
      pendingBoardType,
    };

    const primaryVolId = updated.id || currentUser.id;
    const primaryUserId = updated.firebaseUid || currentUser.firebaseUid;
    const cleanData = cleanFirestoreData(updated);

    try {
      const firestorePayload = {
        ...cleanData,
        boardType: nextBoardType || deleteField(),
        pendingRole: pendingRole || deleteField(),
        pendingBoardType: pendingBoardType || deleteField(),
      };
      if (primaryVolId) {
        await setDoc(doc(db, 'volunteers', primaryVolId), firestorePayload, { merge: true });
        await setDoc(doc(db, 'users', primaryVolId), firestorePayload, { merge: true });
      }
      if (primaryUserId && primaryUserId !== primaryVolId) {
        await setDoc(doc(db, 'users', primaryUserId), firestorePayload, { merge: true });
        await setDoc(doc(db, 'volunteers', primaryUserId), firestorePayload, { merge: true });
      }
    } catch (err) {
      console.warn('Firestore updateProfile error:', err);
    }
    if (updated.avatarUrl || updated.coverUrl) {
      if (primaryVolId) {
        inMemoryImageStore.set(primaryVolId, {
          avatarUrl: updated.avatarUrl || inMemoryImageStore.get(primaryVolId)?.avatarUrl,
          coverUrl: updated.coverUrl || inMemoryImageStore.get(primaryVolId)?.coverUrl,
        });
      }
      if (updated.email) {
        inMemoryImageStore.set(updated.email.toLowerCase(), {
          avatarUrl: updated.avatarUrl || inMemoryImageStore.get(updated.email.toLowerCase())?.avatarUrl,
          coverUrl: updated.coverUrl || inMemoryImageStore.get(updated.email.toLowerCase())?.coverUrl,
        });
      }
    }
    setCurrentUser(updated);
    safeStorage.setItem('yellow_army_current_user', updated);
    if (viewingVolunteer?.id === updated.id) {
      setViewingVolunteer(updated);
    }
    setVolunteers((prev) => {
      const next = prev.map((v) =>
        v.id === updated.id ||
        (v.firebaseUid && updated.firebaseUid && v.firebaseUid === updated.firebaseUid) ||
        (v.email && updated.email && v.email.toLowerCase() === updated.email.toLowerCase())
          ? { ...v, ...updated }
          : v
      );
      const exists = next.some((v) => v.id === updated.id || (v.email && updated.email && v.email.toLowerCase() === updated.email.toLowerCase()));
      const finalList = exists ? next : [updated, ...next];
      safeStorage.setItem('yellow_army_volunteers', finalList);
      return finalList;
    });
  };

  const approveRoleRequest = async (volunteerId: string) => {
    const target = volunteers.find((v) => v.id === volunteerId);
    if (!target) return;

    const approvedRole = target.pendingRole || 'Board Member';
    const approvedBoardType = target.pendingBoardType || target.boardType || 'Upazila Board';
    const isAlumni = approvedRole === 'Alumni';
    const targetEmail = normalizeEmail(target.email);
    const targetPhone = normalizePhoneDigits(target.mobileNo);

    const updated: Volunteer = {
      ...target,
      roleInVBD: approvedRole,
      boardType: approvedRole === 'Board Member' ? approvedBoardType : undefined,
      status: isAlumni ? 'alumni' : (target.status === 'alumni' ? 'active' : target.status),
      pendingRole: undefined,
      pendingBoardType: undefined,
    };

    try {
      // Explicitly delete pendingRole from Firestore document using deleteField()
      await updateDoc(doc(db, 'volunteers', volunteerId), {
        roleInVBD: approvedRole,
        boardType: approvedRole === 'Board Member' ? approvedBoardType : deleteField(),
        status: isAlumni ? 'alumni' : (target.status === 'alumni' ? 'active' : target.status),
        pendingRole: deleteField(),
        pendingBoardType: deleteField(),
      });
    } catch (err) {
      console.warn('Firestore approveRoleRequest updateDoc error, trying setDoc:', err);
      try {
        await setDoc(doc(db, 'volunteers', volunteerId), cleanFirestoreData(updated));
      } catch (e2) {
        console.warn('Firestore setDoc fallback error:', e2);
      }
    }

    // Identify and purge any duplicate cloned documents from Firestore for this volunteer
    const duplicates = volunteers.filter(
      (v) =>
        v.id !== volunteerId &&
        ((targetEmail && normalizeEmail(v.email) === targetEmail) ||
          (targetPhone && targetPhone.length >= 10 && normalizePhoneDigits(v.mobileNo) === targetPhone))
    );
    for (const dup of duplicates) {
      try {
        await deleteDoc(doc(db, 'volunteers', dup.id));
      } catch (e) {
        console.warn('Error purging duplicate volunteer doc in Firestore during approval:', dup.id, e);
      }
    }

    // Update state and purge duplicates from memory and safeStorage
    setVolunteers((prev) => {
      const filtered = prev.filter((v) => !duplicates.some((d) => d.id === v.id));
      const mapped = filtered.map((v) => (v.id === volunteerId ? updated : v));
      const { merged } = mergeAndDeduplicateVolunteers(mapped);
      safeStorage.setItem('yellow_army_volunteers', merged);
      return merged;
    });

    // If currentUser is this volunteer or matches by email/phone, update currentUser immediately!
    const curr = currentUser;
    if (
      curr &&
      (curr.id === volunteerId ||
        duplicates.some((d) => d.id === curr.id) ||
        (targetEmail && normalizeEmail(curr.email) === targetEmail) ||
        (targetPhone && targetPhone.length >= 10 && normalizePhoneDigits(curr.mobileNo) === targetPhone))
    ) {
      const updatedCurrent: Volunteer = {
        ...curr,
        ...updated,
        id: updated.id,
        roleInVBD: approvedRole,
        status: isAlumni ? 'alumni' : curr.status,
        pendingRole: undefined,
      };
      setCurrentUser(updatedCurrent);
      safeStorage.setItem('yellow_army_current_user', updatedCurrent);
    }

    const notif: AppNotification = {
      id: generateUniqueId('notif'),
      title: `[Role Approved] ${target.fullName} is now official ${approvedRole}`,
      message: `${target.fullName} has been officially approved and appointed as ${approvedRole}. Congratulations!`,
      type: 'announcement',
      timestamp: formatNotifTimestamp(),
      createdAt: new Date().toISOString(),
      read: false,
      upazila: target.upazila,
      volunteerId: target.id,
      targetTab: 'profile',
    };
    try {
      await setDoc(doc(db, 'notifications', notif.id), cleanFirestoreData(notif));
    } catch (e) {
      console.warn(e);
    }
    setNotifications((prev) => filterAndSortNotifications([notif, ...prev]));
    triggerConfetti();
  };

  const declineRoleRequest = async (volunteerId: string) => {
    const target = volunteers.find((v) => v.id === volunteerId);
    if (!target) return;

    const updated: Volunteer = {
      ...target,
      pendingRole: undefined,
      pendingBoardType: undefined,
    };

    try {
      await updateDoc(doc(db, 'volunteers', volunteerId), {
        pendingRole: deleteField(),
        pendingBoardType: deleteField(),
      });
    } catch (err) {
      console.warn('Firestore declineRoleRequest error:', err);
    }

    setVolunteers((prev) => {
      const mapped = prev.map((v) => (v.id === volunteerId ? updated : v));
      safeStorage.setItem('yellow_army_volunteers', mapped);
      return mapped;
    });
    if (currentUser?.id === volunteerId) {
      const updatedCurrent: Volunteer = {
        ...currentUser,
        pendingRole: undefined,
        pendingBoardType: undefined,
      };
      setCurrentUser(updatedCurrent);
      safeStorage.setItem('yellow_army_current_user', updatedCurrent);
    }
  };

  const dismissPendingPromotionNotice = async () => {
    if (!currentUser) return;
    const updated: Volunteer = {
      ...currentUser,
      pendingRole: undefined,
      pendingBoardType: undefined,
    };
    setCurrentUser(updated);
    safeStorage.setItem('yellow_army_current_user', updated);

    setVolunteers((prev) => {
      const mapped = prev.map((v) => (v.id === currentUser.id ? updated : v));
      safeStorage.setItem('yellow_army_volunteers', mapped);
      return mapped;
    });

    try {
      await updateDoc(doc(db, 'volunteers', currentUser.id), {
        pendingRole: deleteField(),
        pendingBoardType: deleteField(),
      });
    } catch (err) {
      console.warn('Firestore dismissPendingPromotionNotice error:', err);
    }
  };

  const adminUpdateVolunteerRole = async (volunteerId: string, roleInVBD: VBDRole, adminRole?: AdminRole, boardType?: BoardType) => {
    const target = volunteers.find((v) => v.id === volunteerId);
    if (!target) return;

    const finalBoardType = roleInVBD === 'Board Member' ? (boardType || target.boardType || 'Upazila Board') : undefined;

    const updated: Volunteer = {
      ...target,
      roleInVBD,
      boardType: finalBoardType,
      pendingRole: undefined,
      pendingBoardType: undefined,
      ...(adminRole ? { adminRole } : {}),
    };

    try {
      await updateDoc(doc(db, 'volunteers', volunteerId), {
        roleInVBD,
        boardType: roleInVBD === 'Board Member' ? finalBoardType : deleteField(),
        pendingRole: deleteField(),
        pendingBoardType: deleteField(),
        ...(adminRole ? { adminRole } : {}),
      });
    } catch (err) {
      console.warn('Firestore adminUpdateVolunteerRole error:', err);
      try {
        await setDoc(doc(db, 'volunteers', volunteerId), cleanFirestoreData(updated));
      } catch (e2) {
        console.warn('Firestore setDoc fallback error:', e2);
      }
    }

    setVolunteers((prev) => {
      const mapped = prev.map((v) => (v.id === volunteerId ? updated : v));
      safeStorage.setItem('yellow_army_volunteers', mapped);
      return mapped;
    });
    if (currentUser?.id === volunteerId) {
      setCurrentUser(updated);
      safeStorage.setItem('yellow_army_current_user', updated);
    }
  };

  const deleteVolunteer = async (volunteerId: string) => {
    const target = volunteers.find((v) => v.id === volunteerId);
    if (target && isPermanentAdminEmail(target.email)) {
      alert(`${target.email} is a permanent root administrator and cannot be removed.`);
      return;
    }
    try {
      // 1. Permanently delete primary volunteer document in Firestore
      await deleteDoc(doc(db, 'volunteers', volunteerId)).catch(() => {});

      // 2. Also delete any matching duplicate volunteer documents using IDs known in React state
      // (Avoids expensive full collection getDocs scan)
      if (target) {
        const targetEmail = normalizeEmail(target.email);
        const targetPhone = normalizePhoneDigits(target.mobileNo);
        const dupVolunteers = volunteers.filter(
          (v) =>
            v.id !== volunteerId &&
            ((targetEmail && !targetEmail.includes('volunteer_') && normalizeEmail(v.email) === targetEmail) ||
              (targetPhone && targetPhone.length >= 10 && normalizePhoneDigits(v.mobileNo) === targetPhone) ||
              (target.volunteerIdCode && v.volunteerIdCode === target.volunteerIdCode))
        );
        for (const dup of dupVolunteers) {
          await deleteDoc(doc(db, 'volunteers', dup.id)).catch(() => {});
        }
      }
    } catch (err) {
      console.warn('Firestore deleteVolunteer error:', err);
    }

    setVolunteers((prev) => {
      const filtered = prev.filter((v) => v.id !== volunteerId);
      safeStorage.setItem('yellow_army_volunteers', filtered);
      return filtered;
    });

    if (currentUser?.id === volunteerId) {
      logout();
    }
  };

  const updateVolunteerRole = async (volunteerId: string, newRole: AdminRole) => {
    const target = volunteers.find((v) => v.id === volunteerId);
    if (!target) return;

    if (isPermanentAdminEmail(target.email)) {
      alert(`${target.email} is a permanent root administrator and cannot be removed or demoted.`);
      return;
    }

    const updated: Volunteer = {
      ...target,
      adminRole: newRole,
    };

    try {
      await updateDoc(doc(db, 'volunteers', volunteerId), { adminRole: newRole });
    } catch (err) {
      console.warn('Firestore updateVolunteerRole error:', err);
    }

    setVolunteers((prev) => prev.map((v) => (v.id === volunteerId ? updated : v)));
    if (currentUser?.id === volunteerId) {
      setCurrentUser(updated);
    }
  };

  const updateVolunteerDetails = async (volunteerId: string, data: Partial<Volunteer>) => {
    const target = volunteers.find((v) => v.id === volunteerId);
    if (!target) return;

    let safeAdminRole = data.adminRole ?? target.adminRole;
    if (isPermanentAdminEmail(target.email)) {
      safeAdminRole = 'Super Admin';
    }

    const nextRoleInVBD = data.roleInVBD ?? target.roleInVBD;
    const nextBoardType = nextRoleInVBD === 'Board Member' ? (data.boardType ?? target.boardType ?? 'Upazila Board') : undefined;

    const updated: Volunteer = {
      ...target,
      ...data,
      roleInVBD: nextRoleInVBD,
      boardType: nextBoardType,
      adminRole: safeAdminRole,
      pendingRole: data.roleInVBD ? undefined : target.pendingRole,
      pendingBoardType: data.roleInVBD ? undefined : target.pendingBoardType,
    };

    const cleaned = cleanFirestoreData(updated);
    try {
      const firestorePayload = {
        ...cleaned,
        boardType: nextBoardType || deleteField(),
        pendingRole: updated.pendingRole || deleteField(),
        pendingBoardType: updated.pendingBoardType || deleteField(),
      };
      await setDoc(doc(db, 'volunteers', volunteerId), firestorePayload, { merge: true });
      if (target.firebaseUid || volunteerId === currentUser?.id) {
        await setDoc(doc(db, 'users', volunteerId), firestorePayload, { merge: true }).catch(() => {});
      }
    } catch (err) {
      console.warn('Firestore updateVolunteerDetails error:', err);
    }

    setVolunteers((prev) => {
      const mapped = prev.map((v) => (v.id === volunteerId ? updated : v));
      safeStorage.setItem('yellow_army_volunteers', mapped);
      return mapped;
    });
    if (currentUser?.id === volunteerId) {
      setCurrentUser(updated);
      safeStorage.setItem('yellow_army_current_user', updated);
    }
    if (viewingVolunteer?.id === volunteerId) {
      setViewingVolunteer(updated);
    }
  };

  const awardOrDeductPoints = async (
    volunteerId: string,
    xpChange: number,
    dhpChange: number,
    reason: string,
    skipNotification = false
  ) => {
    const target = volunteers.find((v) => v.id === volunteerId) || (currentUser?.id === volunteerId ? currentUser : null);
    if (!target) return;

    const currentXp = typeof target.xp === 'number'
      ? target.xp
      : typeof target.volunteeringScore === 'number'
      ? target.volunteeringScore
      : 0;
    const currentDhp = typeof target.dhp === 'number'
      ? target.dhp
      : typeof target.dhpPoints === 'number'
      ? target.dhpPoints
      : 0;

    const newXp = Math.max(0, currentXp + xpChange);
    const newDhp = Math.max(0, currentDhp + dhpChange);
    const levelInfo = calculateVolunteerLevel(newXp);

    const updated: Volunteer = {
      ...target,
      xp: newXp,
      dhp: newDhp,
      volunteeringScore: newXp,
      dhpPoints: newDhp,
      level: `${levelInfo.levelTitle} (${levelInfo.levelCode})`,
    };

    // Update state and safe storage immediately so the UI responds in real time
    setVolunteers((prev) => {
      const exists = prev.some((v) => v.id === target.id);
      const next = exists ? prev.map((v) => (v.id === target.id ? updated : v)) : [updated, ...prev];
      safeStorage.setItem('yellow_army_volunteers', next);
      return next;
    });

    if (currentUser?.id === target.id) {
      setCurrentUser(updated);
      safeStorage.setItem('yellow_army_current_user', updated);
    }

    try {
      await setDoc(doc(db, 'volunteers', target.id), cleanFirestoreData(updated), { merge: true });
    } catch (err) {
      console.warn('Firestore awardOrDeductPoints error:', err);
    }

    // Trigger cheerful confetti effect if volunteer gained XP
    if (xpChange > 0) {
      triggerConfetti();
    }

    if (!skipNotification) {
      const isAward = xpChange >= 0;
      const absXp = Math.abs(xpChange);
      const sign = isAward ? '+' : '-';
      const notif: AppNotification = {
        id: generateUniqueId('notif'),
        title: `${target.fullName} gets ${sign}${absXp} XP`,
        message: `${target.fullName} gets ${sign}${absXp} XP (${reason})`,
        type: 'xp_change',
        timestamp: formatNotifTimestamp(),
        createdAt: new Date().toISOString(),
        read: false,
        upazila: target.upazila,
        volunteerId: target.id,
        targetTab: 'army',
      };
      try {
        await setDoc(doc(db, 'notifications', notif.id), cleanFirestoreData(notif));
      } catch (err) {
        console.warn(err);
      }
      setNotifications((prev) => filterAndSortNotifications([notif, ...prev]));
    }
  };

  const adminSetVolunteerPoints = async (
    volunteerId: string,
    newXp: number,
    newDhp: number,
    reason: string
  ) => {
    const target = volunteers.find((v) => v.id === volunteerId);
    if (!target) return;

    const clampedXp = Math.max(0, Number(newXp) || 0);
    const clampedDhp = Math.max(0, Number(newDhp) || 0);
    const levelInfo = calculateVolunteerLevel(clampedXp);

    // Cheerful confetti if score increased
    if (clampedXp > (target.xp ?? 0)) {
      triggerConfetti();
    }

    const updated: Volunteer = {
      ...target,
      xp: clampedXp,
      dhp: clampedDhp,
      volunteeringScore: clampedXp,
      dhpPoints: clampedDhp,
      level: `${levelInfo.levelTitle} (${levelInfo.levelCode})`,
    };

    try {
      await setDoc(doc(db, 'volunteers', target.id), cleanFirestoreData(updated), { merge: true });
    } catch (err) {
      console.warn('Firestore adminSetVolunteerPoints error:', err);
    }

    setVolunteers((prev) => {
      const next = prev.map((v) => (v.id === target.id ? updated : v));
      safeStorage.setItem('yellow_army_volunteers', next);
      return next;
    });

    if (currentUser?.id === target.id) {
      setCurrentUser(updated);
      safeStorage.setItem('yellow_army_current_user', updated);
    }

    const notif: AppNotification = {
      id: generateUniqueId('notif'),
      title: 'Volunteer Score Updated by Admin',
      message: `Admin set ${target.fullName}'s score to ${clampedXp} XP & ${clampedDhp} DHP (${reason}).`,
      type: 'announcement',
      timestamp: formatNotifTimestamp(),
      createdAt: new Date().toISOString(),
      read: false,
      upazila: target.upazila,
    };
    try {
      await setDoc(doc(db, 'notifications', notif.id), cleanFirestoreData(notif));
    } catch (e) {}
    setNotifications((prev) => filterAndSortNotifications([notif, ...prev]));
  };

  const adminResetVolunteerScore = async (volunteerId: string, reason?: string) => {
    await adminSetVolunteerPoints(volunteerId, 0, 0, reason || 'Reset by Admin');
  };

  const launchProjectOrMeeting = async (
    data: Omit<ProjectMeeting, 'id' | 'attendeesCount' | 'registeredVolunteerIds' | 'createdAt' | 'createdBy'> & { status?: 'upcoming' | 'ongoing' | 'completed' | 'archived' }
  ) => {
    const newId = generateUniqueId(data.type.toLowerCase());
    const projectStatus = data.status || (data.startingTime && new Date(data.startingTime).getTime() <= Date.now() ? 'ongoing' : 'upcoming');
    const newProject: ProjectMeeting = {
      ...data,
      id: newId,
      status: projectStatus,
      attendeesCount: 0,
      registeredVolunteerIds: [], // New initiatives start with clean participant list (only explicitly joined members appear)
      createdAt: new Date().toISOString(),
      createdBy: {
        id: currentUser?.id || 'admin-1',
        name: currentUser?.fullName || 'Yellow Army Coordinator',
        role: currentUser?.roleInVBD || 'District Coordinator',
      },
    };

    try {
      await setDoc(doc(db, 'projects', newProject.id), cleanFirestoreData(newProject));
    } catch (err) {
      console.warn('Firestore write project error:', err);
    }
    setProjects((prev) => {
      const merged = deduplicateById([newProject, ...prev]);
      safeStorage.setItem('yellow_army_projects', merged);
      return merged;
    });

    // Award Leader: +125 XP & +125 DHP
    if (data.leader?.id) {
      await awardOrDeductPoints(
        data.leader.id,
        125,
        125,
        `Project Leader for "${data.title}"`
      );
    }

    // Award Co-Leader: +100 XP & +100 DHP
    if (data.coLeader?.id) {
      await awardOrDeductPoints(
        data.coLeader.id,
        100,
        100,
        `Project Co - Leader for "${data.title}"`
      );
    }

    // If viewing a specific upazila that doesn't match, set to District or the project upazila
    if (data.upazilaScope && selectedUpazila !== 'District' && selectedUpazila !== data.upazilaScope) {
      setSelectedUpazila(data.upazilaScope);
    }

    const newNotif: AppNotification = {
      id: generateUniqueId('notif'),
      title: `New ${data.type} Launched: ${data.title} 🚀`,
      message: `${data.leader.name} launched a ${data.type} for ${data.upazilaScope}. Starting on ${new Date(data.startingTime).toLocaleDateString()}.`,
      type: data.type === 'Meeting' ? 'meeting' : 'project_launch',
      timestamp: formatNotifTimestamp(),
      createdAt: new Date().toISOString(),
      read: false,
      upazila: data.upazilaScope,
      projectId: newId,
    };
    try {
      await setDoc(doc(db, 'notifications', newNotif.id), cleanFirestoreData(newNotif));
    } catch (err) {
      console.warn('Firestore write notification error:', err);
    }
    setNotifications((prev) => filterAndSortNotifications([newNotif, ...prev]));

    const newAct: ActivityLog = {
      id: generateUniqueId('act'),
      volunteerId: currentUser?.id || data.leader?.id || 'sys-1',
      volunteerName: currentUser?.fullName || data.leader?.name || 'Yellow Army Coordinator',
      volunteerAvatar: currentUser?.avatarUrl || data.leader?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      action: `Launched ${data.type}`,
      details: `${data.title} scheduled for ${data.upazilaScope}. Leader: ${data.leader.name}.`,
      timestamp: 'Just now',
      upazila: data.upazilaScope,
      type: data.type === 'Meeting' ? 'meeting' : 'project',
    };
    try {
      await setDoc(doc(db, 'activityLogs', newAct.id), cleanFirestoreData(newAct));
    } catch (err) {
      console.warn('Firestore write activity log error:', err);
    }
    setActivityLogs((prev) => deduplicateById([newAct, ...prev]));

    triggerConfetti();
  };

  const updateProjectOrMeeting = async (
    projectId: string,
    updatedData: Partial<ProjectMeeting>
  ) => {
    const target = projects.find((p) => p.id === projectId);
    if (!target) return;

    // 1. Dynamic XP/DHP Adjustment for Leader Changes (125 XP/DHP)
    if (updatedData.leader && updatedData.leader.id !== target.leader?.id) {
      // Deduct from old leader
      if (target.leader?.id) {
        await awardOrDeductPoints(
          target.leader.id,
          -125,
          -125,
          `Removed as Leader from "${target.title}"`
        ).catch((err) => console.warn('Deduct old leader error:', err));
      }
      // Award to new leader
      if (updatedData.leader.id) {
        await awardOrDeductPoints(
          updatedData.leader.id,
          125,
          125,
          `Appointed as Project Leader for "${updatedData.title || target.title}"`
        ).catch((err) => console.warn('Award new leader error:', err));
      }
    }

    // 2. Dynamic XP/DHP Adjustment for Co-Leader Changes (100 XP/DHP)
    const prevCoId = target.coLeader?.id;
    const newCoId = updatedData.coLeader !== undefined ? updatedData.coLeader?.id : target.coLeader?.id;
    if (prevCoId !== newCoId) {
      // Deduct from previous co-leader
      if (prevCoId) {
        await awardOrDeductPoints(
          prevCoId,
          -100,
          -100,
          `Removed as Co-Leader from "${target.title}"`
        ).catch((err) => console.warn('Deduct old co-leader error:', err));
      }
      // Award to new co-leader
      if (newCoId) {
        await awardOrDeductPoints(
          newCoId,
          100,
          100,
          `Appointed as Project Co - Leader for "${updatedData.title || target.title}"`
        ).catch((err) => console.warn('Award new co-leader error:', err));
      }
    }

    // 3. Dynamic XP/DHP Adjustment for Participants (90 for Project, 50 for Meeting)
    if (updatedData.registeredVolunteerIds) {
      const prevIds = target.registeredVolunteerIds || [];
      const newIds = updatedData.registeredVolunteerIds;
      const partDelta = (updatedData.type || target.type) === 'Meeting' ? 50 : 90;

      // Removed participants:
      const removedIds = prevIds.filter((id) => !newIds.includes(id));
      for (const rId of removedIds) {
        await awardOrDeductPoints(
          rId,
          -partDelta,
          -partDelta,
          `Removed from "${target.title}" participation`,
          true
        ).catch((err) => console.warn('Deduct removed participant error:', err));
      }

      // Added participants:
      const addedIds = newIds.filter((id) => !prevIds.includes(id));
      for (const aId of addedIds) {
        await awardOrDeductPoints(
          aId,
          partDelta,
          partDelta,
          `Added to "${target.title}" participation`,
          true
        ).catch((err) => console.warn('Award added participant error:', err));
      }
    }

    const updated: ProjectMeeting = {
      ...target,
      ...updatedData,
      id: projectId,
    };

    try {
      await setDoc(doc(db, 'projects', projectId), cleanFirestoreData(updated), { merge: true });
    } catch (err) {
      console.warn('Firestore update project error:', err);
    }

    setProjects((prev) => {
      const next = deduplicateById(prev.map((p) => (p.id === projectId ? updated : p)));
      safeStorage.setItem('yellow_army_projects', next);
      return next;
    });

    if (selectedProjectModal && selectedProjectModal.id === projectId) {
      setSelectedProjectModal(updated);
    }

    triggerConfetti();
  };

  const toggleTopProject = async (projectId: string) => {
    const target = projects.find((p) => p.id === projectId);
    if (!target) return;
    const newIsTop = !target.isTopProject;

    try {
      await updateDoc(doc(db, 'projects', projectId), { isTopProject: newIsTop });
    } catch (err) {
      console.warn(err);
    }

    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === projectId) {
          if (newIsTop) {
            const notif: AppNotification = {
              id: generateUniqueId('notif'),
              title: `Project Pinned to Top Spotlight! ⭐`,
              message: `"${p.title}" was featured on the Yellow Army Top Projects showcase.`,
              type: 'top_project',
              timestamp: formatNotifTimestamp(),
              createdAt: new Date().toISOString(),
              read: false,
              projectId: p.id,
            };
            setNotifications((n) => filterAndSortNotifications([notif, ...n]));
          }
          return { ...p, isTopProject: newIsTop };
        }
        return p;
      })
    );
  };

  const deleteProject = async (projectId: string) => {
    const targetProject = projects.find((p) => p.id === projectId);
    if (!targetProject) return;

    // Strict XP/DHP Revocation: When a project is deleted, Leader (125), Co-Leader (100), and all Participants lose points!
    // 1. Leader deduction
    if (targetProject.leader?.id) {
      await awardOrDeductPoints(
        targetProject.leader.id,
        -125,
        -125,
        `Revoked: Leader XP/DHP for deleted "${targetProject.title}"`
      ).catch((err) => console.warn('Revoke leader points error:', err));
    }

    // 2. Co-Leader deduction
    if (targetProject.coLeader?.id) {
      await awardOrDeductPoints(
        targetProject.coLeader.id,
        -100,
        -100,
        `Revoked: Co-Leader XP/DHP for deleted "${targetProject.title}"`
      ).catch((err) => console.warn('Revoke co-leader points error:', err));
    }

    // 3. Participants deduction (90 for project, 50 for meeting)
    const partScoreDelta = targetProject.type === 'Meeting' ? -50 : -90;
    const registeredIds = targetProject.registeredVolunteerIds || [];
    for (const partId of registeredIds) {
      // Avoid double deduction if leader or co-leader was also registered
      if (partId !== targetProject.leader?.id && partId !== targetProject.coLeader?.id) {
        await awardOrDeductPoints(
          partId,
          partScoreDelta,
          partScoreDelta,
          `Revoked: Participant XP/DHP for deleted "${targetProject.title}"`,
          true
        ).catch((err) => console.warn('Revoke participant points error:', err));
      }
    }

    try {
      // 1. Delete project document from Firestore
      await deleteDoc(doc(db, 'projects', projectId)).catch(() => {});

      // 2. Also delete notifications associated with this project from Firestore
      // Use local state IDs if available, avoiding an unindexed full collection scan
      const projectNotifs = notifications.filter((n) => n.projectId === projectId);
      for (const n of projectNotifs) {
        await deleteDoc(doc(db, 'notifications', n.id)).catch(() => {});
      }
    } catch (err) {
      console.warn('Firestore deleteProject error:', err);
    }

    setProjects((prev) => {
      const filtered = prev.filter((p) => p.id !== projectId);
      safeStorage.setItem('yellow_army_projects', filtered);
      return filtered;
    });

    setNotifications((prev) => {
      const filtered = prev.filter((n) => n.projectId !== projectId);
      safeStorage.setItem('yellow_army_notifications', filtered);
      return filtered;
    });

    if (selectedProjectModal?.id === projectId) {
      setSelectedProjectModal(null);
    }
  };

  const joinProject = async (projectId: string) => {
    if (!currentUser) {
      openAuthModal('login');
      return;
    }
    // Double-submit protection
    if (pendingProjectActionIdsRef.current.has(projectId)) return;
    pendingProjectActionIdsRef.current.add(projectId);

    try {
      const targetProject = projects.find((p) => p.id === projectId);
      if (!targetProject) return;

      // Do not allow joining if initiative is completed or archived
      const isFinished = isProjectFinished(targetProject) || targetProject.status === 'completed' || targetProject.status === 'archived';
      if (isFinished) {
        console.warn('Initiative is already completed. Registration is closed.');
        return;
      }

      const currentRegistered = targetProject.registeredVolunteerIds || [];
      const userIdentifiers = [
        currentUser.id,
        currentUser.firebaseUid,
        currentUser.email?.toLowerCase(),
        currentUser.volunteerIdCode,
      ].filter(Boolean) as string[];

      const alreadyJoined = currentRegistered.some((id) => userIdentifiers.includes(id));
      if (alreadyJoined) return;

      const newIds = Array.from(new Set([...currentRegistered, currentUser.id, ...(currentUser.firebaseUid ? [currentUser.firebaseUid] : [])]));
      const updatedCount = (targetProject.attendeesCount || 0) + 1;
      const updatedProject: ProjectMeeting = {
        ...targetProject,
        attendeesCount: updatedCount,
        registeredVolunteerIds: newIds,
      };

      // Update local state and safeStorage immediately
      setProjects((prev) => {
        const next = prev.map((p) => (p.id === projectId ? updatedProject : p));
        safeStorage.setItem('yellow_army_projects', next);
        return next;
      });

      if (selectedProjectModal?.id === projectId) {
        setSelectedProjectModal(updatedProject);
      }

      // Persist to Firestore with setDoc merge
      try {
        await setDoc(doc(db, 'projects', projectId), cleanFirestoreData(updatedProject), { merge: true });
      } catch (err) {
        console.warn('Firestore joinProject setDoc error:', err);
      }

      // Scoring logic in background: +90 XP & +90 DHP for Project participants, +50 XP & +50 DHP for Meeting attendees
      const xpDelta = targetProject.type === 'Meeting' ? 50 : 90;
      const dhpDelta = targetProject.type === 'Meeting' ? 50 : 90;
      awardOrDeductPoints(
        currentUser.id,
        xpDelta,
        dhpDelta,
        `Joined ${targetProject.type}: "${targetProject.title}"`,
        true // skipNotification: true -> prevents writing redundant global notification document
      ).catch((err) => console.warn('awardOrDeductPoints error:', err));

      const newAct: ActivityLog = {
        id: generateUniqueId('act'),
        volunteerId: currentUser.id,
        volunteerName: currentUser.fullName,
        volunteerAvatar: currentUser.avatarUrl,
        action: 'Signed Up for Initiative',
        details: `Enrolled as active volunteer for "${targetProject.title}".`,
        timestamp: 'Just now',
        upazila: targetProject.upazilaScope,
        type: 'project',
      };
      setActivityLogs((prev) => {
        const next = deduplicateById([newAct, ...prev]);
        safeStorage.setItem('yellow_army_activities', next);
        return next;
      });
    } finally {
      pendingProjectActionIdsRef.current.delete(projectId);
    }
  };

  const leaveProject = async (projectId: string) => {
    if (!currentUser) return;
    // Double-submit protection
    if (pendingProjectActionIdsRef.current.has(projectId)) return;
    pendingProjectActionIdsRef.current.add(projectId);

    try {
      const targetProject = projects.find((p) => p.id === projectId);
      if (!targetProject) return;

      const userIdentifiers = [
        currentUser.id,
        currentUser.firebaseUid,
        currentUser.email?.toLowerCase(),
        currentUser.volunteerIdCode,
      ].filter(Boolean) as string[];

      const currentRegistered = targetProject.registeredVolunteerIds || [];
      const isJoined = currentRegistered.some((id) => userIdentifiers.includes(id));
      if (!isJoined) return;

      const updatedVolunteers = currentRegistered.filter((id) => !userIdentifiers.includes(id));
      const updatedCount = Math.max(0, targetProject.attendeesCount - 1);
      const updatedProject: ProjectMeeting = {
        ...targetProject,
        attendeesCount: updatedCount,
        registeredVolunteerIds: updatedVolunteers,
      };

      setProjects((prev) => {
        const next = prev.map((p) => (p.id === projectId ? updatedProject : p));
        safeStorage.setItem('yellow_army_projects', next);
        return next;
      });

      if (selectedProjectModal?.id === projectId) {
        setSelectedProjectModal(updatedProject);
      }

      try {
        await setDoc(doc(db, 'projects', projectId), cleanFirestoreData(updatedProject), { merge: true });
      } catch (err) {
        console.warn('Firestore leaveProject error:', err);
      }

      // Deduct exact points on leave to maintain score stability and prevent exploits
      const xpDelta = targetProject.type === 'Meeting' ? -50 : -90;
      const dhpDelta = targetProject.type === 'Meeting' ? -50 : -90;
      awardOrDeductPoints(
        currentUser.id,
        xpDelta,
        dhpDelta,
        `Withdrew from ${targetProject.type}: "${targetProject.title}"`,
        true // skipNotification: true -> prevents writing redundant global notification document
      ).catch((err) => console.warn('awardOrDeductPoints error:', err));
    } finally {
      pendingProjectActionIdsRef.current.delete(projectId);
    }
  };

  const markNotificationAsRead = async (id: string) => {
    try {
      const currentReadIds = getReadNotificationIds();
      currentReadIds.add(id);
      safeStorage.setItem('yellow_army_read_notif_ids', Array.from(currentReadIds));
    } catch (e) {
      console.warn(e);
    }

    setNotifications((prev) => {
      const next = prev.map((n) => (n.id === id ? { ...n, read: true } : n));
      safeStorage.setItem('yellow_army_notifications', next);
      return next;
    });
  };

  const markAllNotificationsAsRead = async () => {
    const unread = notifications.filter((n) => !n.read);
    if (unread.length === 0) return;

    try {
      const currentReadIds = getReadNotificationIds();
      unread.forEach((n) => currentReadIds.add(n.id));
      safeStorage.setItem('yellow_army_read_notif_ids', Array.from(currentReadIds));
    } catch (e) {
      console.warn(e);
    }

    setNotifications((prev) => {
      const next = prev.map((n) => ({ ...n, read: true }));
      safeStorage.setItem('yellow_army_notifications', next);
      return next;
    });
  };

  const deleteNotification = async (id: string) => {
    setNotifications((prev) => {
      const next = prev.filter((n) => n.id !== id);
      safeStorage.setItem('yellow_army_notifications', next);
      return next;
    });
    try {
      await deleteDoc(doc(db, 'notifications', id));
    } catch (err) {
      console.warn('deleteNotification error:', err);
    }
  };

  const addRadioBroadcast = async (
    data: Omit<RadioBroadcast, 'id' | 'timestamp' | 'likesCount' | 'likedByCurrentUser'>
  ) => {
    const newBroadcast: RadioBroadcast = {
      ...data,
      id: generateUniqueId('rad'),
      timestamp: 'Just now',
      likesCount: 1,
      likedByCurrentUser: true,
    };

    try {
      await setDoc(doc(db, 'radioBroadcasts', newBroadcast.id), cleanFirestoreData(newBroadcast));
    } catch (err) {
      console.warn(err);
    }
    setBroadcasts((prev) => deduplicateById([newBroadcast, ...prev]));

    const notif: AppNotification = {
      id: generateUniqueId('notif'),
      title: `Yellow Army Radio: ${data.category} 📻`,
      message: `${data.speakerName} (${data.speakerRole}) broadcasted: "${data.title}"`,
      type: data.priority === 'urgent' ? 'emergency_blood' : 'announcement',
      timestamp: formatNotifTimestamp(),
      createdAt: new Date().toISOString(),
      read: false,
    };
    try {
      await setDoc(doc(db, 'notifications', notif.id), cleanFirestoreData(notif));
    } catch (err) {
      console.warn(err);
    }
    setNotifications((prev) => filterAndSortNotifications([notif, ...prev]));
  };

  const toggleLikeBroadcast = async (broadcastId: string) => {
    const target = broadcasts.find((b) => b.id === broadcastId);
    if (!target) return;
    const isLiked = target.likedByCurrentUser;
    const newCount = isLiked ? target.likesCount - 1 : target.likesCount + 1;

    try {
      await updateDoc(doc(db, 'radioBroadcasts', broadcastId), {
        likesCount: newCount,
      });
    } catch (err) {
      console.warn(err);
    }

    setBroadcasts((prev) =>
      prev.map((b) => (b.id === broadcastId ? { ...b, likedByCurrentUser: !isLiked, likesCount: newCount } : b))
    );
  };

  const voteRadioPoll = async (broadcastId: string, optionId: string) => {
    if (!currentUser) return;
    const target = broadcasts.find((b) => b.id === broadcastId);
    if (!target || !target.pollOptions) return;

    const prevOptionId = target.pollVoters?.[currentUser.id];
    if (prevOptionId === optionId) return; // already voted for this option

    const updatedOptions = target.pollOptions.map((opt) => {
      let v = opt.votes;
      if (opt.id === prevOptionId) v = Math.max(0, v - 1);
      if (opt.id === optionId) v += 1;
      return { ...opt, votes: v };
    });

    const updatedVoters = {
      ...(target.pollVoters || {}),
      [currentUser.id]: optionId,
    };

    try {
      await updateDoc(doc(db, 'radioBroadcasts', broadcastId), {
        pollOptions: updatedOptions,
        pollVoters: updatedVoters,
      });
    } catch (err) {
      console.warn(err);
    }

    setBroadcasts((prev) =>
      prev.map((b) =>
        b.id === broadcastId
          ? { ...b, pollOptions: updatedOptions, pollVoters: updatedVoters }
          : b
      )
    );
  };

  const reactToRadioBroadcast = async (broadcastId: string, emoji: string) => {
    if (!currentUser) return;
    const target = broadcasts.find((b) => b.id === broadcastId);
    if (!target) return;

    const currentReaction = target.userReactions?.[currentUser.id];
    const reactions = { ...(target.reactions || {}) };
    const userReactions = { ...(target.userReactions || {}) };

    if (currentReaction === emoji) {
      // Toggle off
      reactions[emoji] = Math.max(0, (reactions[emoji] || 1) - 1);
      if (reactions[emoji] === 0) delete reactions[emoji];
      delete userReactions[currentUser.id];
    } else {
      // If switching from another reaction
      if (currentReaction && reactions[currentReaction]) {
        reactions[currentReaction] = Math.max(0, reactions[currentReaction] - 1);
        if (reactions[currentReaction] === 0) delete reactions[currentReaction];
      }
      reactions[emoji] = (reactions[emoji] || 0) + 1;
      userReactions[currentUser.id] = emoji;
    }

    try {
      await updateDoc(doc(db, 'radioBroadcasts', broadcastId), {
        reactions,
        userReactions,
      });
    } catch (err) {
      console.warn(err);
    }

    setBroadcasts((prev) =>
      prev.map((b) =>
        b.id === broadcastId ? { ...b, reactions, userReactions } : b
      )
    );
  };

  const deleteRadioBroadcast = async (broadcastId: string) => {
    try {
      await deleteDoc(doc(db, 'radioBroadcasts', broadcastId));
      await deleteDoc(doc(db, 'broadcasts', broadcastId)).catch(() => {});
    } catch (err) {
      console.warn('Firestore deleteRadioBroadcast error:', err);
    }
    setBroadcasts((prev) => {
      const next = prev.filter((b) => b.id !== broadcastId);
      safeStorage.setItem('yellow_army_broadcasts', next);
      return next;
    });
  };

  // Need Assessment Actions
  const addNeedAssessment = async (data: {
    title: string;
    description: string;
    category?: any;
    upazila?: UpazilaName | 'District';
  }) => {
    if (!currentUser) {
      openAuthModal('login');
      return;
    }
    const newNeed: NeedAssessment = {
      id: generateUniqueId('need'),
      title: data.title.trim(),
      description: data.description.trim(),
      category: data.category || 'General',
      upazila: data.upazila || (selectedUpazila !== 'District' ? selectedUpazila : currentUser.upazila),
      createdBy: {
        id: currentUser.id,
        name: currentUser.fullName,
        role: currentUser.roleInVBD,
        upazila: currentUser.upazila,
      },
      createdAt: new Date().toISOString(),
      voters: [currentUser.id],
      votesCount: 1,
      status: 'open',
    };

    try {
      await setDoc(doc(db, 'needAssessments', newNeed.id), cleanFirestoreData(newNeed));
    } catch (err) {
      console.warn('Firestore write need error:', err);
    }

    setNeedAssessments((prev) => deduplicateById([newNeed, ...prev]));

    const notif: AppNotification = {
      id: generateUniqueId('notif'),
      title: 'New Need Assessment Posted 📋',
      message: `${currentUser.fullName} submitted community need: "${newNeed.title}" for ${newNeed.upazila}.`,
      type: 'announcement',
      timestamp: formatNotifTimestamp(),
      createdAt: new Date().toISOString(),
      read: false,
      upazila: newNeed.upazila,
    };
    try {
      await setDoc(doc(db, 'notifications', notif.id), cleanFirestoreData(notif));
    } catch (e) {}
    setNotifications((prev) => filterAndSortNotifications([notif, ...prev]));

    triggerConfetti();
  };

  const voteNeedAssessment = async (needId: string) => {
    if (!currentUser) {
      openAuthModal('login');
      return;
    }
    const target = needAssessments.find((n) => n.id === needId);
    if (!target) return;

    const hasVoted = target.voters?.includes(currentUser.id);
    const updatedVoters = hasVoted
      ? (target.voters || []).filter((id) => id !== currentUser.id)
      : [...(target.voters || []), currentUser.id];
    const updatedCount = updatedVoters.length;

    try {
      await updateDoc(doc(db, 'needAssessments', needId), {
        voters: updatedVoters,
        votesCount: updatedCount,
      });
    } catch (err) {
      console.warn('Firestore vote need error:', err);
    }

    setNeedAssessments((prev) =>
      prev.map((n) =>
        n.id === needId ? { ...n, voters: updatedVoters, votesCount: updatedCount } : n
      )
    );
  };

  const fulfillNeedAssessment = async (needId: string, adminNote?: string) => {
    if (!currentUser) return;
    const target = needAssessments.find((n) => n.id === needId);
    if (!target) return;

    const isFulfilling = target.status !== 'fulfilled';
    const updatedStatus = isFulfilling ? 'fulfilled' : 'open';
    const nowIso = new Date().toISOString();

    const firestoreUpdates: any = isFulfilling
      ? {
          status: 'fulfilled',
          fulfilledAt: nowIso,
          fulfilledBy: { id: currentUser.id, name: currentUser.fullName },
          adminNote: adminNote || 'Assessment completed and action taken.',
        }
      : {
          status: 'open',
          fulfilledAt: deleteField(),
          fulfilledBy: deleteField(),
          adminNote: deleteField(),
        };

    const localUpdates: Partial<NeedAssessment> = isFulfilling
      ? {
          status: 'fulfilled',
          fulfilledAt: nowIso,
          fulfilledBy: { id: currentUser.id, name: currentUser.fullName },
          adminNote: adminNote || 'Assessment completed and action taken.',
        }
      : {
          status: 'open',
          fulfilledAt: undefined,
          fulfilledBy: undefined,
          adminNote: undefined,
        };

    try {
      await updateDoc(doc(db, 'needAssessments', needId), firestoreUpdates);
    } catch (err) {
      console.warn('Firestore fulfill need error:', err);
    }

    setNeedAssessments((prev) =>
      prev.map((n) => (n.id === needId ? { ...n, ...localUpdates } : n))
    );

    if (updatedStatus === 'fulfilled') {
      triggerConfetti();
    }
  };

  const deleteNeedAssessment = async (needId: string) => {
    try {
      await deleteDoc(doc(db, 'needAssessments', needId));
    } catch (err) {
      console.warn('Firestore deleteNeedAssessment error:', err);
    }
    setNeedAssessments((prev) => {
      const next = prev.filter((n) => n.id !== needId);
      safeStorage.setItem('yellow_army_needs', next);
      return next;
    });
  };

  // Board Photo Actions
  const updateBoardPhoto = async (
    scope: UpazilaName | 'District',
    photoUrl: string,
    title?: string,
    caption?: string
  ) => {
    const photoId = `photo-${scope.toLowerCase().replace(/\s+/g, '-')}`;
    const newPhoto: BoardPhoto = {
      id: photoId,
      scope,
      photoUrl,
      title: title || `${scope} Board Leadership`,
      caption: caption || `Official leadership committee for ${scope} sector.`,
      updatedAt: new Date().toISOString(),
      updatedBy: currentUser?.fullName || 'Admin',
    };

    try {
      await setDoc(doc(db, 'boardPhotos', photoId), newPhoto);
    } catch (err) {
      console.warn('Firestore boardPhoto save error:', err);
    }

    setBoardPhotos((prev) => {
      const filtered = prev.filter((p) => p.scope !== scope);
      return [newPhoto, ...filtered];
    });

    triggerConfetti();
  };

  const handleNotificationClick = useCallback((notif: AppNotification) => {
    // Immediately mark as read so badge vanishes
    markNotificationAsRead(notif.id);

    // 1. Role approval request -> Admin view
    if (notif.type === 'role_approval_request' || notif.targetTab === 'admin') {
      if (isAdmin) {
        setActiveTab('admin');
        setTimeout(() => {
          const el = document.getElementById('admin-role-approvals');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }, 150);
      } else {
        setActiveTab('profile');
      }
      return;
    }

    // 2. Project ID link -> Directly open project/meeting post modal
    if (notif.projectId) {
      const found = projects.find((p) => p.id === notif.projectId);
      if (found) {
        setSelectedProjectModal(found);
        setActiveTab(found.type?.toLowerCase() === 'meeting' ? 'calendar' : 'home');
        return;
      }
    }

    // 3. Project launch or meeting announcement -> Open post and navigate to post section
    if (
      notif.type === 'project_launch' ||
      notif.type === 'meeting' ||
      notif.type === 'top_project' ||
      notif.title.toLowerCase().includes('project') ||
      notif.title.toLowerCase().includes('mission') ||
      notif.title.toLowerCase().includes('meeting') ||
      notif.message.toLowerCase().includes('project') ||
      notif.message.toLowerCase().includes('meeting')
    ) {
      const found = projects.find(
        (p) =>
          (notif.projectId && p.id === notif.projectId) ||
          notif.title.toLowerCase().includes(p.title.toLowerCase()) ||
          p.title.toLowerCase().includes(notif.title.toLowerCase()) ||
          (notif.message && notif.message.toLowerCase().includes(p.title.toLowerCase()))
      );
      if (found) {
        setSelectedProjectModal(found);
        setActiveTab(found.type?.toLowerCase() === 'meeting' ? 'calendar' : 'home');
        return;
      }
      setActiveTab(notif.type === 'meeting' ? 'calendar' : 'home');
      return;
    }

    // 4. XP Change or Volunteer update -> open volunteer card/profile
    if (notif.type === 'xp_change' || notif.volunteerId) {
      const foundVol = volunteers.find(
        (v) =>
          v.id === notif.volunteerId ||
          (notif.title && notif.title.includes(v.fullName)) ||
          (notif.message && notif.message.includes(v.fullName))
      );
      if (foundVol) {
        openVolunteerProfile(foundVol);
        return;
      }
      setActiveTab('army');
      return;
    }

    // 5. Emergency Blood or Volunteer notification -> Yellow Army Directory
    const notifTypeStr = notif.type as string;
    if (
      notifTypeStr === 'emergency_blood' ||
      notifTypeStr === 'blood_request' ||
      notif.title.toLowerCase().includes('blood') ||
      notif.title.includes('[New Volunteer]') ||
      notifTypeStr === 'volunteer' ||
      notif.targetTab === 'army'
    ) {
      setActiveTab('army');
      return;
    }

    // 6. Radio or Broadcast -> Radio
    if (
      notifTypeStr === 'radio' ||
      notifTypeStr === 'broadcast' ||
      notif.targetTab === 'radio' ||
      notif.title.toLowerCase().includes('broadcast') ||
      notif.title.toLowerCase().includes('radio')
    ) {
      setActiveTab('radio');
      return;
    }

    // 7. Explicit targetTab fallback
    if (notif.targetTab) {
      setActiveTab(notif.targetTab);
      return;
    }

    // 8. General fallback -> Project Centre
    setActiveTab('home');
  }, [markNotificationAsRead, projects, volunteers, isAdmin, openVolunteerProfile]);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        isAuthModalOpen,
        authModalMode,
        volunteers,
        projects,
        activeProjects,
        recentCompletedProjects,
        topProjects,
        activityLogs,
        notifications,
        unreadNotificationCount,
        broadcasts,
        needAssessments,
        boardPhotos,
        selectedUpazila,
        activeTab,
        language,
        setLanguage,
        searchQuery,
        setSearchQuery,
        setSelectedUpazila,
        setActiveTab,
        openAuthModal,
        closeAuthModal,
        loginWithEmail,
        loginWithGoogle,
        loginAsVolunteer,
        signUpVolunteer,
        completeOnboarding,
        logout,
        switchUser,
        updateProfile,
        deleteVolunteer,
        awardOrDeductPoints,
        adminSetVolunteerPoints,
        adminResetVolunteerScore,
        launchProjectOrMeeting,
        updateProjectOrMeeting,
        toggleTopProject,
        deleteProject,
        joinProject,
        leaveProject,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        deleteNotification,
        addRadioBroadcast,
        toggleLikeBroadcast,
        voteRadioPoll,
        reactToRadioBroadcast,
        deleteRadioBroadcast,
        addNeedAssessment,
        voteNeedAssessment,
        fulfillNeedAssessment,
        deleteNeedAssessment,
        updateBoardPhoto,
        stats,
        pendingApprovalsCount,
        triggerConfetti,
        isFirebaseSynced,
        isAdmin,
        isModerator,
        canPost,
        updateVolunteerRole,
        updateVolunteerDetails,
        approveRoleRequest,
        declineRoleRequest,
        dismissPendingPromotionNotice,
        adminUpdateVolunteerRole,
        removeVolunteer: deleteVolunteer,
        selectedProjectModal,
        setSelectedProjectModal,
        handleNotificationClick,
        viewingVolunteer,
        setViewingVolunteer,
        openVolunteerProfile,
        ensureVolunteersLoaded,
        loadVolunteerByIdOrCode,
        ensureRadioLoaded,
        ensureNeedAssessmentsLoaded,
        ensureBoardPhotosLoaded,
        ensureActivityLogsLoaded,
        refreshData,
        isRefreshing,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
