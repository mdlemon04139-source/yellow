import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Activity,
  Zap,
  Droplet,
  Award,
  Calendar,
  MapPin,
} from 'lucide-react';
import { translations } from '../../utils/translations';

export const ActivityStream: React.FC = () => {
  const { activityLogs, language } = useApp();
  const t = translations[language];

  const getIcon = (type: string) => {
    switch (type) {
      case 'blood':
        return <Droplet className="w-3.5 h-3.5 text-rose-500" />;
      case 'project':
        return <Zap className="w-3.5 h-3.5 text-emerald-600" />;
      case 'meeting':
        return <Calendar className="w-3.5 h-3.5 text-purple-500" />;
      case 'announcement':
        return <Award className="w-3.5 h-3.5 text-amber-500" />;
      default:
        return <Activity className="w-3.5 h-3.5 text-emerald-500" />;
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-3xl p-4 sm:p-6 shadow-2xs">
      <div className="flex items-center justify-between gap-2 mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700">
            <Activity className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm sm:text-base text-slate-900">
              {t.activityFeed}
            </h3>
            <p className="text-[11px] text-slate-500">
              {language === 'bn' ? '১৩টি উপজেলার ভলান্টিয়ারদের রিয়েল-টাইম কার্যক্রম' : 'Real-time progress and actions from volunteers across 13 Upazilas'}
            </p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded-full">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          Live Feed
        </span>
      </div>

      <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
        {activityLogs.map((act, idx) => (
          <div
            key={act.id ? `${act.id}-${idx}` : `act-${idx}`}
            className="flex items-start gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-400 transition shadow-2xs"
          >
            <div className="relative">
              <img
                src={act.volunteerAvatar}
                alt={act.volunteerName}
                className="w-9 h-9 rounded-full object-cover border border-emerald-500 shrink-0"
              />
              <div className="absolute -bottom-1 -right-1 p-0.5 rounded-full bg-white border border-slate-200">
                {getIcon(act.type)}
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <p className="font-bold text-xs text-slate-900 truncate">
                  {act.volunteerName}
                </p>
                <span className="text-[10px] text-slate-400 whitespace-nowrap">
                  {act.timestamp}
                </span>
              </div>
              <p className="text-[11px] text-emerald-700 font-bold mt-0.5">
                {act.action}
              </p>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                {act.details}
              </p>
              <div className="mt-1 flex items-center gap-1 text-[10px] text-slate-500">
                <MapPin className="w-3 h-3 text-emerald-600" />
                <span>{act.upazila}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
