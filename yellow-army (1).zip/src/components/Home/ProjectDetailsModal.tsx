import React, { useState, useMemo } from 'react';
import { ProjectMeeting, EventType, UpazilaName, MYMENSINGH_UPAZILAS, UPAZILA_BENGALI_NAMES, Volunteer } from '../../types';
import { useApp } from '../../context/AppContext';
import { formatProjectDateRange, isProjectFinished } from '../../utils/projectStatusUtils';
import {
  X,
  Calendar,
  Clock,
  MapPin,
  CheckCircle,
  Users,
  Award,
  Share2,
  Sparkles,
  ChevronRight,
  Shield,
  Star,
  Edit3,
  Save,
  RotateCcw,
  Trash2,
  Search,
  UserPlus,
  UserMinus,
  ChevronDown,
} from 'lucide-react';

interface ProjectDetailsModalProps {
  project: ProjectMeeting | null;
  onClose: () => void;
}

export const ProjectDetailsModal: React.FC<ProjectDetailsModalProps> = ({
  project,
  onClose,
}) => {
  const {
    currentUser,
    joinProject,
    leaveProject,
    isAdmin,
    toggleTopProject,
    updateProjectOrMeeting,
    deleteProject,
    volunteers,
    language,
  } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editType, setEditType] = useState<EventType>('Project');
  const [editStatus, setEditStatus] = useState<'upcoming' | 'ongoing' | 'completed' | 'archived'>('upcoming');
  const [editUpazila, setEditUpazila] = useState<'District' | UpazilaName>('District');
  const [editVenue, setEditVenue] = useState('');
  const [editStartingTime, setEditStartingTime] = useState('');
  const [editClosingTime, setEditClosingTime] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editBannerUrl, setEditBannerUrl] = useState('');

  // Leader, Co-Leader, and Participants management in Edit mode
  const [editLeader, setEditLeader] = useState<ProjectMeeting['leader'] | null>(null);
  const [editCoLeader, setEditCoLeader] = useState<ProjectMeeting['coLeader'] | null>(null);
  const [editRegisteredVolunteerIds, setEditRegisteredVolunteerIds] = useState<string[]>([]);
  const [isLeaderDropdownOpen, setIsLeaderDropdownOpen] = useState(false);
  const [isCoLeaderDropdownOpen, setIsCoLeaderDropdownOpen] = useState(false);
  const [isAddParticipantDropdownOpen, setIsAddParticipantDropdownOpen] = useState(false);
  const [leaderSearch, setLeaderSearch] = useState('');
  const [coLeaderSearch, setCoLeaderSearch] = useState('');
  const [participantSearch, setParticipantSearch] = useState('');

  const [isSaving, setIsSaving] = useState(false);

  // Sync state whenever project changes or edit mode is opened
  React.useEffect(() => {
    if (project) {
      setEditTitle(project.title || '');
      setEditType(project.type || 'Project');
      setEditStatus(project.status || 'upcoming');
      setEditUpazila(project.upazilaScope || 'District');
      setEditVenue(project.venue || '');
      setEditStartingTime(project.startingTime ? project.startingTime.slice(0, 16) : '');
      setEditClosingTime(project.closingTime ? project.closingTime.slice(0, 16) : '');
      setEditDescription(project.description || '');
      setEditBannerUrl(project.bannerUrl || '');
      setEditLeader(project.leader || null);
      setEditCoLeader(project.coLeader || null);
      setEditRegisteredVolunteerIds(project.registeredVolunteerIds || []);
      setIsEditing(false);
      setShowDeleteConfirm(false);
    }
  }, [project]);

  const filteredLeaders = useMemo(() => {
    if (!leaderSearch.trim()) return volunteers.slice(0, 15);
    return volunteers.filter(
      (v) =>
        v.fullName.toLowerCase().includes(leaderSearch.toLowerCase()) ||
        v.upazila.toLowerCase().includes(leaderSearch.toLowerCase()) ||
        v.roleInVBD.toLowerCase().includes(leaderSearch.toLowerCase())
    );
  }, [volunteers, leaderSearch]);

  const filteredCoLeaders = useMemo(() => {
    if (!coLeaderSearch.trim()) return volunteers.slice(0, 15);
    return volunteers.filter(
      (v) =>
        v.fullName.toLowerCase().includes(coLeaderSearch.toLowerCase()) ||
        v.upazila.toLowerCase().includes(coLeaderSearch.toLowerCase()) ||
        v.roleInVBD.toLowerCase().includes(coLeaderSearch.toLowerCase())
    );
  }, [volunteers, coLeaderSearch]);

  const filteredCandidateParticipants = useMemo(() => {
    const notEnrolled = volunteers.filter((v) => !editRegisteredVolunteerIds.includes(v.id));
    if (!participantSearch.trim()) return notEnrolled.slice(0, 15);
    return notEnrolled.filter(
      (v) =>
        v.fullName.toLowerCase().includes(participantSearch.toLowerCase()) ||
        v.upazila.toLowerCase().includes(participantSearch.toLowerCase()) ||
        v.roleInVBD.toLowerCase().includes(participantSearch.toLowerCase())
    );
  }, [volunteers, editRegisteredVolunteerIds, participantSearch]);

  if (!project) return null;

  const canEdit =
    isAdmin ||
    (currentUser &&
      (currentUser.id === project.createdBy?.id ||
        currentUser.id === project.leader?.id ||
        currentUser.id === project.coLeader?.id));

  const isFinished = isProjectFinished(project) || project.status === 'completed' || project.status === 'archived';

  // Strict check: only joined if explicitly in registeredVolunteerIds
  const isJoined = Boolean(
    currentUser &&
    project.registeredVolunteerIds &&
    (project.registeredVolunteerIds.includes(currentUser.id) ||
      (currentUser.firebaseUid && project.registeredVolunteerIds.includes(currentUser.firebaseUid)))
  );
  const startDate = project.startingTime ? new Date(project.startingTime) : null;
  const closeDate = project.closingTime ? new Date(project.closingTime) : null;

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateProjectOrMeeting) return;
    setIsSaving(true);
    try {
      await updateProjectOrMeeting(project.id, {
        title: editTitle.trim() || project.title,
        type: editType,
        status: editStatus,
        upazilaScope: editUpazila,
        venue: editVenue.trim() || project.venue,
        startingTime: editStartingTime ? new Date(editStartingTime).toISOString() : project.startingTime,
        closingTime: editClosingTime ? new Date(editClosingTime).toISOString() : project.closingTime,
        description: editDescription.trim() || project.description,
        bannerUrl: editBannerUrl.trim() || project.bannerUrl,
        leader: editLeader || project.leader,
        coLeader: editCoLeader || undefined,
        registeredVolunteerIds: editRegisteredVolunteerIds,
        attendeesCount: editRegisteredVolunteerIds.length,
      });
      setIsEditing(false);
    } catch (err) {
      console.warn('Failed to update project:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn overflow-y-auto"
      style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-white border-2 border-emerald-500 rounded-[32px] sm:rounded-[36px] shadow-2xl p-5 sm:p-6 text-slate-900 space-y-4 my-6 max-h-[92vh] overflow-y-auto"
      >
        {/* Header with Title and Close Button */}
        <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="space-y-1 min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className={`text-[10px] font-army font-black uppercase px-2.5 py-0.5 rounded-full ${
                  isFinished
                    ? 'bg-emerald-600 text-white'
                    : project.status === 'ongoing'
                    ? 'bg-yellow-400 text-slate-950 border border-yellow-500'
                    : 'bg-red-600 text-white'
                }`}
              >
                {isFinished
                  ? 'COMPLETED'
                  : project.status === 'ongoing'
                  ? 'ON GOING'
                  : 'UPCOMING'}
              </span>
              <span className="text-[10px] font-army font-black uppercase px-2.5 py-0.5 rounded-full bg-yellow-100 text-yellow-900 border border-yellow-300 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-yellow-700" />
                <span>{project.type.toUpperCase()}</span>
              </span>
              <span className="text-[10px] font-army font-black uppercase px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-emerald-700" />
                <span>{project.upazilaScope.toUpperCase()}</span>
              </span>
            </div>
            <h3 className="font-army italic font-black text-lg sm:text-xl text-slate-900 uppercase tracking-wide leading-snug pt-1">
              {project.title}
            </h3>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {canEdit && (
              <>
                <button
                  type="button"
                  onClick={() => setIsEditing(!isEditing)}
                  className={`p-2 rounded-full transition cursor-pointer flex items-center gap-1 text-xs font-army font-bold ${
                    isEditing
                      ? 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                      : 'bg-slate-100 text-slate-700 hover:bg-emerald-100 hover:text-emerald-800'
                  }`}
                  title={isEditing ? 'Cancel Edit' : 'Edit Project/Meeting'}
                >
                  <Edit3 className="w-4 h-4" />
                  <span className="hidden sm:inline">{isEditing ? 'Cancel' : 'Edit'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(!showDeleteConfirm)}
                  className="p-2 rounded-full bg-rose-50 text-rose-600 hover:bg-rose-100 hover:text-rose-700 transition cursor-pointer flex items-center gap-1 text-xs font-army font-bold"
                  title="Delete Initiative"
                >
                  <Trash2 className="w-4 h-4 text-rose-600" />
                  <span className="hidden sm:inline">Delete</span>
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700 transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* DELETE CONFIRMATION BANNER */}
        {showDeleteConfirm && (
          <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-4 text-center space-y-2.5 animate-fadeIn">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-5 h-5" />
            </div>
            <h4 className="font-army italic font-black text-sm text-rose-950 uppercase">
              {language === 'bn' ? 'প্রজেক্ট / মিটিং নিশ্চিতভাবে মুছে ফেলতে চান?' : 'Permanently Delete This Initiative?'}
            </h4>
            <p className="text-xs text-rose-700 max-w-md mx-auto leading-relaxed">
              {language === 'bn'
                ? 'সতর্কতা: এটি মুছে ফেললে প্রজেক্ট লিডার (১২৫ এক্সপি/ডিএইচপি), কো-লিডার (১০০ এক্সপি/ডিএইচপি) এবং অংশগ্রহণকারী সকল ভলান্টিয়ারের এই প্রজেক্ট থেকে অর্জিত পয়েন্ট স্বয়ংক্রিয়ভাবে বাতিল হয়ে যাবে।'
                : 'Warning: Deleting this initiative will revoke XP/DHP from the Project Leader (125), Co-Leader (100), and all enrolled participants.'}
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold rounded-xl text-xs cursor-pointer transition"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={async () => {
                  await deleteProject(project.id);
                  onClose();
                }}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-army italic font-black rounded-xl text-xs uppercase tracking-wider cursor-pointer shadow-xs transition"
              >
                {language === 'bn' ? 'হ্যাঁ, ডিলিট করুন' : 'Confirm & Delete'}
              </button>
            </div>
          </div>
        )}

        {/* EDIT MODE FORM */}
        {isEditing ? (
          <form onSubmit={handleSaveEdit} className="space-y-4 text-xs font-medium">
            <div className="bg-amber-50 border border-amber-200 p-3 rounded-2xl flex items-center gap-2 text-amber-900 font-bold">
              <Edit3 className="w-4 h-4 text-amber-700" />
              <span>
                {language === 'bn'
                  ? 'প্রজেক্ট / মিটিং সম্পাদনা মোড (Edit Mode)'
                  : 'Editing Project / Meeting Details'}
              </span>
            </div>

            {/* Title */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">Title</label>
              <input
                type="text"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 font-bold"
              />
            </div>

            {/* Type & Status */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Initiative Type</label>
                <select
                  value={editType}
                  onChange={(e) => setEditType(e.target.value as EventType)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                >
                  <option value="Project">Project</option>
                  <option value="Meeting">Meeting</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Status</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold"
                >
                  <option value="upcoming">⏳ Upcoming</option>
                  <option value="ongoing">🟢 Ongoing (Live)</option>
                  <option value="completed">🏁 Completed</option>
                </select>
              </div>
            </div>

            {/* Project Leader & Co-Leader Selectors in Edit Form */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-2xl">
              {/* Project Leader */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-slate-800">
                    Project Leader
                  </label>
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full font-army">
                    125 XP/DHP
                  </span>
                </div>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => {
                      setIsLeaderDropdownOpen(!isLeaderDropdownOpen);
                      setIsCoLeaderDropdownOpen(false);
                      setIsAddParticipantDropdownOpen(false);
                    }}
                    className="w-full bg-white border border-slate-300 rounded-xl p-2.5 flex items-center justify-between text-left cursor-pointer hover:border-emerald-400"
                  >
                    {editLeader ? (
                      <div className="flex items-center gap-2 truncate">
                        <img
                          src={editLeader.avatarUrl}
                          alt={editLeader.name}
                          className="w-6 h-6 rounded-full object-cover border border-emerald-500"
                        />
                        <div className="truncate">
                          <span className="font-bold text-slate-900 text-xs block truncate">{editLeader.name}</span>
                          <span className="text-[10px] text-slate-500 block truncate">{editLeader.role} • {editLeader.upazila}</span>
                        </div>
                      </div>
                    ) : (
                      <span className="text-slate-400 text-xs">Select Project Leader</span>
                    )}
                    <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                  </button>

                  {isLeaderDropdownOpen && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2 space-y-2">
                      <div className="relative">
                        <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
                        <input
                          type="text"
                          placeholder="Search volunteer..."
                          value={leaderSearch}
                          onChange={(e) => setLeaderSearch(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-2 py-1 text-xs"
                        />
                      </div>
                      <div className="max-h-40 overflow-y-auto space-y-1">
                        {filteredLeaders.map((vol) => (
                          <div
                            key={vol.id}
                            onClick={() => {
                              setEditLeader({
                                id: vol.id,
                                name: vol.fullName,
                                avatarUrl: vol.avatarUrl,
                                role: vol.roleInVBD,
                                upazila: vol.upazila,
                              });
                              setIsLeaderDropdownOpen(false);
                            }}
                            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-emerald-50 cursor-pointer transition"
                          >
                            <img src={vol.avatarUrl} alt={vol.fullName} className="w-6 h-6 rounded-full object-cover" />
                            <div className="truncate">
                              <p className="font-bold text-slate-800 text-xs truncate">{vol.fullName}</p>
                              <p className="text-[9px] text-slate-500">{vol.roleInVBD} • {vol.upazila}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Project Co - Leader */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-bold text-slate-800">
                    Project Co - Leader
                  </label>
                  <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2 py-0.5 rounded-full font-army">
                    100 XP/DHP
                  </span>
                </div>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => {
                      setIsCoLeaderDropdownOpen(!isCoLeaderDropdownOpen);
                      setIsLeaderDropdownOpen(false);
                      setIsAddParticipantDropdownOpen(false);
                    }}
                    className="w-full bg-white border border-slate-300 rounded-xl p-2.5 flex items-center justify-between text-left cursor-pointer hover:border-amber-400"
                  >
                    {editCoLeader ? (
                      <div className="flex items-center gap-2 truncate">
                        <img
                          src={editCoLeader.avatarUrl}
                          alt={editCoLeader.name}
                          className="w-6 h-6 rounded-full object-cover border border-amber-500"
                        />
                        <div className="truncate">
                          <span className="font-bold text-slate-900 text-xs block truncate">{editCoLeader.name}</span>
                          <span className="text-[10px] text-slate-500 block truncate">{editCoLeader.role} • {editCoLeader.upazila}</span>
                        </div>
                      </div>
                    ) : (
                      <span className="text-slate-400 text-xs">Select Co - Leader (Optional)</span>
                    )}
                    <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                  </button>

                  {isCoLeaderDropdownOpen && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2 space-y-2">
                      <div className="relative">
                        <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
                        <input
                          type="text"
                          placeholder="Search volunteer..."
                          value={coLeaderSearch}
                          onChange={(e) => setCoLeaderSearch(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-2 py-1 text-xs"
                        />
                      </div>
                      <div className="max-h-40 overflow-y-auto space-y-1">
                        <div
                          onClick={() => {
                            setEditCoLeader(null);
                            setIsCoLeaderDropdownOpen(false);
                          }}
                          className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 font-bold text-xs cursor-pointer"
                        >
                          (None / Remove Co - Leader)
                        </div>
                        {filteredCoLeaders.map((vol) => (
                          <div
                            key={vol.id}
                            onClick={() => {
                              setEditCoLeader({
                                id: vol.id,
                                name: vol.fullName,
                                avatarUrl: vol.avatarUrl,
                                role: vol.roleInVBD,
                                upazila: vol.upazila,
                              });
                              setIsCoLeaderDropdownOpen(false);
                            }}
                            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-amber-50 cursor-pointer transition"
                          >
                            <img src={vol.avatarUrl} alt={vol.fullName} className="w-6 h-6 rounded-full object-cover" />
                            <div className="truncate">
                              <p className="font-bold text-slate-800 text-xs truncate">{vol.fullName}</p>
                              <p className="text-[9px] text-slate-500">{vol.roleInVBD} • {vol.upazila}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Participants Management in Edit Mode */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-800 text-xs">
                    Enrolled Participants ({editRegisteredVolunteerIds.length})
                  </h4>
                  <p className="text-[10px] text-slate-500">
                    Removing a participant automatically deducts points; adding a participant awards points.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsAddParticipantDropdownOpen(!isAddParticipantDropdownOpen)}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Add Participant</span>
                </button>
              </div>

              {isAddParticipantDropdownOpen && (
                <div className="p-2 bg-white border border-slate-200 rounded-xl space-y-1.5 shadow-md animate-fadeIn">
                  <div className="relative">
                    <Search className="absolute left-2 top-2 w-3.5 h-3.5 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search volunteer to add..."
                      value={participantSearch}
                      onChange={(e) => setParticipantSearch(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-7 pr-2 py-1 text-xs"
                    />
                  </div>
                  <div className="max-h-36 overflow-y-auto space-y-1">
                    {filteredCandidateParticipants.map((v) => (
                      <div
                        key={v.id}
                        onClick={() => {
                          setEditRegisteredVolunteerIds((prev) => Array.from(new Set([...prev, v.id])));
                          setParticipantSearch('');
                          setIsAddParticipantDropdownOpen(false);
                        }}
                        className="flex items-center justify-between p-1.5 rounded-lg hover:bg-emerald-50 cursor-pointer"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <img src={v.avatarUrl} alt={v.fullName} className="w-5 h-5 rounded-full object-cover" />
                          <span className="font-bold text-xs truncate">{v.fullName}</span>
                          <span className="text-[9px] text-slate-400">({v.upazila})</span>
                        </div>
                        <span className="text-[10px] font-bold text-emerald-700">+ Add</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* List of currently enrolled participants */}
              <div className="max-h-40 overflow-y-auto space-y-1 pr-1">
                {editRegisteredVolunteerIds.length === 0 ? (
                  <p className="text-[11px] text-slate-400 italic py-1">No participants currently enrolled.</p>
                ) : (
                  editRegisteredVolunteerIds.map((pId) => {
                    const pVol = volunteers.find((v) => v.id === pId || v.firebaseUid === pId);
                    const pName = pVol?.fullName || `Volunteer (${pId})`;
                    const pAvatar = pVol?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80';
                    return (
                      <div
                        key={pId}
                        className="flex items-center justify-between p-1.5 bg-white border border-slate-200 rounded-xl"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <img src={pAvatar} alt={pName} className="w-5 h-5 rounded-full object-cover" />
                          <span className="font-bold text-slate-800 text-xs truncate">{pName}</span>
                          {pVol && (
                            <span className="text-[9px] text-slate-400">({pVol.roleInVBD} • {pVol.upazila})</span>
                          )}
                        </div>
                        <button
                          type="button"
                          onClick={() => setEditRegisteredVolunteerIds((prev) => prev.filter((id) => id !== pId))}
                          className="text-rose-500 hover:text-rose-700 p-1 hover:bg-rose-50 rounded-md transition cursor-pointer"
                          title="Remove Participant"
                        >
                          <UserMinus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Upazila Scope & Venue */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Upazila Scope</label>
                <select
                  value={editUpazila}
                  onChange={(e) => setEditUpazila(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                >
                  <option value="District">{language === 'bn' ? 'ময়মনসিংহ জেলা সমগ্র' : 'Mymensingh District Wide'}</option>
                  {MYMENSINGH_UPAZILAS.map((upz) => (
                    <option key={upz} value={upz}>
                      {language === 'bn' ? UPAZILA_BENGALI_NAMES[upz] : upz}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Venue / Location</label>
                <input
                  type="text"
                  value={editVenue}
                  onChange={(e) => setEditVenue(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                />
              </div>
            </div>

            {/* Starting & Closing Times */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Starting Date & Time</label>
                <input
                  type="datetime-local"
                  value={editStartingTime}
                  onChange={(e) => setEditStartingTime(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 mb-1">Closing Date & Time</label>
                <input
                  type="datetime-local"
                  value={editClosingTime}
                  onChange={(e) => setEditClosingTime(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
                />
              </div>
            </div>

            {/* Banner URL */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">Banner Image URL</label>
              <input
                type="url"
                value={editBannerUrl}
                onChange={(e) => setEditBannerUrl(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block font-bold text-slate-700 mb-1">Description</label>
              <textarea
                rows={3}
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs"
              />
            </div>

            {/* Save & Cancel buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="px-5 py-2 bg-[#07531d] hover:bg-[#0a6625] text-yellow-400 font-army font-black rounded-xl uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 shadow-sm disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
              </button>
            </div>
          </form>
        ) : (
          /* NORMAL VIEW */
          <>
            {/* Project Banner */}
            <div className="relative h-44 sm:h-56 w-full rounded-2xl overflow-hidden border border-slate-200">
              <img
                src={project.bannerUrl}
                alt={project.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent"></div>
              <div className="absolute bottom-3 left-3 text-white">
                <span className="text-xs font-mono font-bold bg-black/50 px-2 py-0.5 rounded-md backdrop-blur-xs">
                  {project.attendeesCount} Volunteers Joined
                </span>
              </div>
            </div>

            {/* Key Information Tiles */}
            {(() => {
              const dateInfo = formatProjectDateRange(project.startingTime, project.closingTime);
              return (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  {/* Starting Time */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                      <Calendar className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase block">Starting Time</span>
                      <span className="font-army font-black text-slate-900">
                        {startDate
                          ? startDate.toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })
                          : 'Date TBA'}
                        {startDate &&
                          ` • ${startDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                      </span>
                    </div>
                  </div>

                  {/* Ending / Closing Time */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold text-slate-400 uppercase block">Ending / Closing</span>
                        {dateInfo.isLongTerm && (
                          <span className="bg-amber-100 text-amber-900 border border-amber-300 text-[8px] font-black uppercase px-1.5 py-0.2 rounded-md">
                            {dateInfo.durationDays} Days
                          </span>
                        )}
                      </div>
                      <span className="font-army font-black text-slate-900">
                        {closeDate
                          ? closeDate.toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                            })
                          : dateInfo.endDate || 'Same day wrap-up'}
                        {closeDate &&
                          ` • ${closeDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                      </span>
                    </div>
                  </div>

                  {/* Venue */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center shrink-0">
                      <MapPin className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-[10px] font-bold text-slate-400 uppercase block">Venue / Location</span>
                      <span className="font-army font-black text-slate-900 truncate block">
                        {project.venue || 'Mymensingh Central HQ'}
                      </span>
                    </div>
                  </div>

                  {/* Upazila Scope */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                      <Users className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <span className="text-[10px] font-bold text-slate-400 uppercase block">Territory Scope</span>
                      <span className="font-army font-black text-slate-900 truncate block uppercase">
                        {project.upazilaScope === 'District' ? 'Mymensingh District Wide' : `${project.upazilaScope} Upazila`}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Leader & Co-Leader Info Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              {/* Project Leader Card */}
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-3 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <img
                    src={project.leader.avatarUrl}
                    alt={project.leader.name}
                    className="w-10 h-10 rounded-xl object-cover border-2 border-emerald-600 shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9px] font-black uppercase text-emerald-800 tracking-wider">
                        PROJECT LEADER
                      </span>
                      <span className="bg-emerald-200/80 text-emerald-900 text-[8px] font-black px-1.5 py-0.2 rounded font-army">
                        125 XP/DHP
                      </span>
                    </div>
                    <h4 className="font-army font-black text-slate-900 uppercase truncate">
                      {project.leader.name}
                    </h4>
                    <p className="text-[10px] text-slate-500 font-bold uppercase truncate">
                      {project.leader.role} • {project.leader.upazila}
                    </p>
                  </div>
                </div>
              </div>

              {/* Project Co - Leader Card (if appointed) */}
              {project.coLeader ? (
                <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={project.coLeader.avatarUrl}
                      alt={project.coLeader.name}
                      className="w-10 h-10 rounded-xl object-cover border-2 border-amber-500 shrink-0"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] font-black uppercase text-amber-900 tracking-wider">
                          PROJECT CO - LEADER
                        </span>
                        <span className="bg-amber-200/80 text-amber-950 text-[8px] font-black px-1.5 py-0.2 rounded font-army">
                          100 XP/DHP
                        </span>
                      </div>
                      <h4 className="font-army font-black text-slate-900 uppercase truncate">
                        {project.coLeader.name}
                      </h4>
                      <p className="text-[10px] text-slate-500 font-bold uppercase truncate">
                        {project.coLeader.role} • {project.coLeader.upazila}
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-slate-50 border border-dashed border-slate-200 rounded-2xl p-3 flex items-center justify-center text-slate-400 text-xs italic">
                  No Project Co - Leader Appointed
                </div>
              )}
            </div>

            {/* Enrolled Participants Preview */}
            {project.registeredVolunteerIds && project.registeredVolunteerIds.length > 0 && (
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-army font-black text-slate-700 uppercase tracking-wider">
                    ENROLLED VOLUNTEERS ({project.registeredVolunteerIds.length})
                  </span>
                  <span className="text-[10px] font-bold text-emerald-700">
                    +90 XP/DHP Per Participant
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-1.5">
                  {project.registeredVolunteerIds.slice(0, 12).map((volId) => {
                    const v = volunteers.find((vol) => vol.id === volId || vol.firebaseUid === volId);
                    return (
                      <div
                        key={volId}
                        title={v ? `${v.fullName} (${v.upazila})` : volId}
                        className="flex items-center gap-1 bg-white border border-slate-200 rounded-full px-2 py-0.5 shadow-2xs"
                      >
                        <img
                          src={v?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80'}
                          alt={v?.fullName || 'Volunteer'}
                          className="w-4 h-4 rounded-full object-cover"
                        />
                        <span className="text-[10px] font-bold text-slate-800 max-w-[80px] truncate">
                          {v?.fullName || 'Volunteer'}
                        </span>
                      </div>
                    );
                  })}
                  {project.registeredVolunteerIds.length > 12 && (
                    <span className="text-[10px] font-bold text-slate-500 bg-white border border-slate-200 rounded-full px-2 py-0.5">
                      +{project.registeredVolunteerIds.length - 12} more
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Project Description */}
            <div className="space-y-1.5">
              <h4 className="font-army font-black text-xs uppercase tracking-wider text-slate-700">
                OPERATION BRIEFING & OBJECTIVES
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed font-medium bg-slate-50 border border-slate-200 rounded-2xl p-3.5">
                {project.description}
              </p>
            </div>

            {/* Impact Summary (if completed) */}
            {project.impactSummary && (
              <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-3.5 text-xs space-y-2">
                <span className="text-[10px] font-black uppercase text-amber-900 tracking-wider block flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-amber-700" />
                  <span>MISSION IMPACT SUMMARY</span>
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-center">
                  {project.impactSummary.beneficiaries && (
                    <div className="bg-white rounded-xl p-2 border border-amber-200">
                      <span className="text-base font-army font-black text-emerald-700 block">
                        {project.impactSummary.beneficiaries}
                      </span>
                      <span className="text-[9px] font-bold text-slate-500 uppercase">Beneficiaries</span>
                    </div>
                  )}
                  {project.impactSummary.bloodBagsCollected && (
                    <div className="bg-white rounded-xl p-2 border border-amber-200">
                      <span className="text-base font-army font-black text-rose-600 block">
                        {project.impactSummary.bloodBagsCollected}
                      </span>
                      <span className="text-[9px] font-bold text-slate-500 uppercase">Blood Bags</span>
                    </div>
                  )}
                  {project.impactSummary.treesPlanted && (
                    <div className="bg-white rounded-xl p-2 border border-amber-200">
                      <span className="text-base font-army font-black text-emerald-800 block">
                        {project.impactSummary.treesPlanted}
                      </span>
                      <span className="text-[9px] font-bold text-slate-500 uppercase">Trees Planted</span>
                    </div>
                  )}
                </div>
                {project.impactSummary.keyHighlight && (
                  <p className="text-[11px] text-amber-900 font-medium italic">
                    "{project.impactSummary.keyHighlight}"
                  </p>
                )}
              </div>
            )}

            {/* Footer Actions */}
            <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2.5">
              <div className="flex items-center gap-2">
                {isAdmin && (
                  <button
                    onClick={() => toggleTopProject(project.id)}
                    className={`px-3 py-2 rounded-xl border text-xs font-army font-black uppercase transition flex items-center gap-1.5 cursor-pointer ${
                      project.isTopProject
                        ? 'bg-amber-400 text-slate-950 border-amber-500 shadow-xs'
                        : 'bg-slate-100 hover:bg-amber-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    <Star className={`w-3.5 h-3.5 ${project.isTopProject ? 'fill-slate-950' : ''}`} />
                    <span>{project.isTopProject ? 'Featured Top' : 'Feature Top'}</span>
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                {isFinished ? (
                  <div className="bg-slate-100 text-slate-600 font-army italic font-black uppercase px-4 py-2 rounded-xl text-xs border border-slate-200">
                    COMPLETED • ENROLLMENT CLOSED
                  </div>
                ) : isJoined ? (
                  <button
                    onClick={() => leaveProject(project.id)}
                    className="bg-emerald-50 hover:bg-rose-50 text-emerald-800 hover:text-rose-700 font-army font-black uppercase px-4 py-2 rounded-xl text-xs border border-emerald-200 hover:border-rose-300 transition flex items-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Joined • Click to Leave</span>
                  </button>
                ) : (
                  <button
                    onClick={() => joinProject(project.id)}
                    className="bg-[#07531d] hover:bg-[#0a6625] text-yellow-400 font-army font-black uppercase px-5 py-2 rounded-xl text-xs shadow-sm transition flex items-center gap-1.5 border border-emerald-700 cursor-pointer"
                  >
                    <span>Join Operation</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                )}

                <button
                  onClick={onClose}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-army font-black text-xs px-4 py-2 rounded-xl cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
