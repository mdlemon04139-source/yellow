import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { MapPin, ChevronRight, ChevronDown, Check, Search, X } from 'lucide-react';
import { MYMENSINGH_UPAZILAS, UPAZILA_BENGALI_NAMES, UpazilaName } from '../../types';
import { translations } from '../../utils/translations';

export const UpazilaSelector: React.FC = () => {
  const { selectedUpazila, setSelectedUpazila, volunteers, language } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const t = translations[language];

  const getVolunteerCount = (upz: UpazilaName | 'District') => {
    if (upz === 'District') return volunteers.length;
    return volunteers.filter((v) => v.upazila === upz).length;
  };

  const filteredUpazilas = MYMENSINGH_UPAZILAS.filter((upz) => {
    const q = searchTerm.toLowerCase();
    const bengali = UPAZILA_BENGALI_NAMES[upz] || '';
    return upz.toLowerCase().includes(q) || bengali.includes(q);
  });

  const displayScopeName =
    selectedUpazila === 'District'
      ? (language === 'bn' ? 'প্রজেক্ট সেন্টার' : 'PROJECT CENTER')
      : (language === 'bn' ? (UPAZILA_BENGALI_NAMES[selectedUpazila] || selectedUpazila) : selectedUpazila.toUpperCase());

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Project Sector Card (Narrower & Sleek) */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-white border border-slate-200 hover:border-emerald-500/70 rounded-2xl p-3 sm:p-3.5 shadow-xs hover:shadow-sm transition-all duration-200 flex items-center justify-between gap-3 text-left group cursor-pointer"
      >
        <div className="flex items-center gap-3 min-w-0">
          {/* Green Squircle Pin Icon */}
          <div className="w-9 h-9 rounded-xl bg-[#07531d] border border-emerald-500/40 flex items-center justify-center text-yellow-400 shadow-xs shrink-0 group-hover:scale-105 transition-transform">
            <MapPin className="w-4 h-4 fill-yellow-400" />
          </div>

          {/* Sector Text */}
          <div className="min-w-0">
            <span className="text-[9px] font-black italic uppercase tracking-widest text-slate-400 block leading-none">
              PROJECT SECTOR
            </span>
            <h2 className="text-sm sm:text-base font-black italic uppercase tracking-wider text-slate-900 truncate mt-0.5">
              {displayScopeName}
            </h2>
          </div>
        </div>

        {/* Right Arrow Chevron */}
        <div className="p-1.5 rounded-full bg-slate-100 group-hover:bg-amber-100 text-slate-400 group-hover:text-amber-700 transition shrink-0">
          {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </div>
      </button>

      {/* Expanded Upazila Selector Grid Dropdown */}
      {isOpen && (
        <div className="mt-2 bg-white border-2 border-emerald-500/40 rounded-2xl p-3.5 sm:p-4 shadow-xl animate-fadeIn">
          <div className="flex items-center justify-between mb-2.5">
            <h3 className="font-black italic uppercase text-xs text-slate-900 tracking-wider">
              SELECT ACTIVE SECTOR / UPAZILA
            </h3>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="relative mb-3">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search Sector / Upazila name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition"
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-64 overflow-y-auto pr-1">
            <button
              onClick={() => {
                setSelectedUpazila('District');
                setIsOpen(false);
              }}
              className={`p-3 rounded-2xl text-left text-xs font-black transition flex items-center justify-between border cursor-pointer ${
                selectedUpazila === 'District'
                  ? 'bg-[#07531d] text-yellow-400 border-emerald-600 shadow-xs'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
              }`}
            >
              <div>
                <span className="block italic uppercase">⭐ {language === 'bn' ? 'প্রজেক্ট সেন্টার' : 'PROJECT CENTER'}</span>
                <span className={`text-[9px] block font-bold ${selectedUpazila === 'District' ? 'text-emerald-200' : 'text-slate-500'}`}>
                  {language === 'bn' ? 'সকল ১৩টি উপজেলা' : 'All 13 Upazilas'}
                </span>
              </div>
              <span className={`text-[10px] px-1.5 py-0.5 rounded font-black ${selectedUpazila === 'District' ? 'bg-[#043311] text-yellow-400' : 'bg-slate-200 text-slate-800'}`}>
                {volunteers.length}
              </span>
            </button>

            {filteredUpazilas.map((upz) => {
              const isSelected = selectedUpazila === upz;
              const vCount = getVolunteerCount(upz);
              const displayName = language === 'bn' ? (UPAZILA_BENGALI_NAMES[upz] || upz) : upz;

              return (
                <button
                  key={upz}
                  onClick={() => {
                    setSelectedUpazila(upz);
                    setIsOpen(false);
                  }}
                  className={`p-3 rounded-2xl text-left text-xs transition flex flex-col justify-between border cursor-pointer ${
                    isSelected
                      ? 'bg-[#07531d] text-yellow-400 border-emerald-600 font-black shadow-xs'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-800 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="font-black italic uppercase truncate">{displayName}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-yellow-400 shrink-0" />}
                  </div>
                  <div className={`flex items-center justify-between text-[10px] ${isSelected ? 'text-emerald-200' : 'text-slate-500'}`}>
                    <span className="font-medium text-[9px]">{language === 'bn' ? 'সেক্টর' : 'Sector'}</span>
                    <span className="font-black">{vCount} {language === 'bn' ? 'জন' : 'vols'}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
