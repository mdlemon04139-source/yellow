import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  X,
  Rocket,
  Image,
  Calendar,
  Clock,
  MapPin,
  Users,
  Search,
  CheckCircle2,
  Layers,
  FileText,
  Building,
  UploadCloud,
  Check,
  ChevronDown,
} from 'lucide-react';
import {
  EventType,
  UpazilaName,
  MYMENSINGH_UPAZILAS,
  UPAZILA_BENGALI_NAMES,
  Volunteer,
} from '../../types';
import { translations } from '../../utils/translations';
import { compressImage } from '../../utils/storageAndImage';

interface ProjectLaunchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Default Yellow Army brand banner when no image is uploaded
const DEFAULT_BANNER = 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=1000&auto=format&fit=crop&q=80';

export const ProjectLaunchModal: React.FC<ProjectLaunchModalProps> = ({ isOpen, onClose }) => {
  const { volunteers, currentUser, launchProjectOrMeeting, language } = useApp();
  const t = translations[language];

  // Form Fields
  const [title, setTitle] = useState('');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [customBannerUrl, setCustomBannerUrl] = useState('');
  // User mandate: exactly two initiative types: 'Project' and 'Meeting'
  const [type, setType] = useState<EventType>('Project');
  // User mandate: exactly two status choices: 'upcoming' and 'completed' (default: 'upcoming')
  const [status, setStatus] = useState<'upcoming' | 'completed'>('upcoming');
  const [upazilaScope, setUpazilaScope] = useState<'District' | UpazilaName>('District');
  const [description, setDescription] = useState('');
  const [venue, setVenue] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Default dates: today to 7 days later
  const now = new Date();
  const nextWeek = new Date();
  nextWeek.setDate(nextWeek.getDate() + 7);
  const formattedToday = now.toISOString().split('T')[0];
  const formattedNextWeek = nextWeek.toISOString().split('T')[0];
  const [startingTime, setStartingTime] = useState(`${formattedToday}T09:00`);
  const [closingTime, setClosingTime] = useState(`${formattedNextWeek}T18:00`);

  // Leader Search & Selection
  const [selectedLeader, setSelectedLeader] = useState<Volunteer | null>(null);
  const [isLeaderDropdownOpen, setIsLeaderDropdownOpen] = useState(false);
  const [leaderSearch, setLeaderSearch] = useState('');

  // Co-Leader Search & Selection
  const [selectedCoLeader, setSelectedCoLeader] = useState<Volunteer | null>(null);
  const [isCoLeaderDropdownOpen, setIsCoLeaderDropdownOpen] = useState(false);
  const [coLeaderSearch, setCoLeaderSearch] = useState('');

  useEffect(() => {
    if (!selectedLeader) {
      if (currentUser) {
        setSelectedLeader(currentUser);
      } else if (volunteers.length > 0) {
        setSelectedLeader(volunteers[0]);
      }
    }
  }, [currentUser, volunteers, selectedLeader]);

  // Handle direct file upload from device gallery with compression
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const compressed = await compressImage(file, 960, 540, 0.75);
      if (compressed) {
        setUploadedImage(compressed);
        setCustomBannerUrl('');
      }
    }
  };

  const filteredLeaders = useMemo(() => {
    if (!leaderSearch.trim()) return volunteers.slice(0, 8);
    return volunteers.filter(
      (v) =>
        v.fullName.toLowerCase().includes(leaderSearch.toLowerCase()) ||
        v.upazila.toLowerCase().includes(leaderSearch.toLowerCase()) ||
        v.roleInVBD.toLowerCase().includes(leaderSearch.toLowerCase())
    );
  }, [volunteers, leaderSearch]);

  const filteredCoLeaders = useMemo(() => {
    if (!coLeaderSearch.trim()) return volunteers.slice(0, 8);
    return volunteers.filter(
      (v) =>
        v.fullName.toLowerCase().includes(coLeaderSearch.toLowerCase()) ||
        v.upazila.toLowerCase().includes(coLeaderSearch.toLowerCase()) ||
        v.roleInVBD.toLowerCase().includes(coLeaderSearch.toLowerCase())
    );
  }, [volunteers, coLeaderSearch]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const finalLeader = selectedLeader || currentUser || (volunteers.length > 0 ? volunteers[0] : {
      id: 'vol-super-admin',
      fullName: 'Yellow Army Central Admin',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      roleInVBD: 'Board Member',
      upazila: 'Mymensingh Sadar',
    });

    const finalBanner = customBannerUrl.trim() || uploadedImage || DEFAULT_BANNER;

    launchProjectOrMeeting({
      title: title.trim(),
      bannerUrl: finalBanner,
      type,
      status, // 'upcoming' or 'completed'
      upazilaScope,
      description: description.trim() || 'A flagship Yellow Army initiative for Mymensingh community development and social welfare.',
      venue: venue.trim() || (upazilaScope === 'District' ? 'Mymensingh District Central Hub' : `${upazilaScope} Community Center`),
      startingTime,
      closingTime,
      leader: {
        id: finalLeader.id,
        name: finalLeader.fullName,
        avatarUrl: finalLeader.avatarUrl,
        role: finalLeader.roleInVBD || 'Board Member',
        upazila: finalLeader.upazila || 'Mymensingh Sadar',
      },
      coLeader: selectedCoLeader
        ? {
            id: selectedCoLeader.id,
            name: selectedCoLeader.fullName,
            avatarUrl: selectedCoLeader.avatarUrl,
            role: selectedCoLeader.roleInVBD,
            upazila: selectedCoLeader.upazila,
          }
        : undefined,
      isTopProject: false,
    });

    // Reset & close
    setTitle('');
    setDescription('');
    setVenue('');
    setUploadedImage(null);
    setCustomBannerUrl('');
    onClose();
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn"
      style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-xl bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh]"
      >
        {/* Header */}
        <div className="bg-[#07531d] p-4 text-white flex items-center justify-between border-b border-emerald-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-950 flex items-center justify-center text-yellow-400 font-extrabold shadow-2xs">
              <Rocket className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base leading-tight text-white">
                {type === 'Project' ? 'Launch Project' : 'Schedule Meeting'}
              </h2>
              <p className="text-[11px] text-emerald-200 font-medium">
                Mymensingh District • Yellow Army
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-black/20 hover:bg-black/40 text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Content */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-5 overflow-y-auto space-y-4 text-slate-900 text-xs">
          {/* Title */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              Title <span className="text-emerald-600">*</span>
            </label>
            <input
              type="text"
              required
              placeholder={type === 'Project' ? 'e.g., Clean Mymensingh Brahmaputra Drive' : 'e.g., Monthly Executive Coordination Meeting'}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 placeholder-slate-400 transition font-medium"
            />
          </div>

          {/* Initiative Type & Status (Only 2 options each as mandated) */}
          <div className="grid grid-cols-2 gap-3">
            {/* Initiative Type */}
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Initiative Type <span className="text-emerald-600">*</span>
              </label>
              <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setType('Project')}
                  className={`py-2 text-center rounded-lg font-bold text-xs transition cursor-pointer ${
                    type === 'Project'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  Project
                </button>
                <button
                  type="button"
                  onClick={() => setType('Meeting')}
                  className={`py-2 text-center rounded-lg font-bold text-xs transition cursor-pointer ${
                    type === 'Meeting'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  Meeting
                </button>
              </div>
            </div>

            {/* Status (Upcoming / Completed only) */}
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Status <span className="text-emerald-600">*</span>
              </label>
              <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setStatus('upcoming')}
                  className={`py-2 text-center rounded-lg font-bold text-xs transition cursor-pointer ${
                    status === 'upcoming'
                      ? 'bg-amber-500 text-slate-950 shadow-xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  Upcoming
                </button>
                <button
                  type="button"
                  onClick={() => setStatus('completed')}
                  className={`py-2 text-center rounded-lg font-bold text-xs transition cursor-pointer ${
                    status === 'completed'
                      ? 'bg-slate-800 text-white shadow-xs'
                      : 'text-slate-700 hover:text-slate-900'
                  }`}
                >
                  Completed
                </button>
              </div>
            </div>
          </div>

          <p className="text-[10px] text-slate-500 bg-amber-50 border border-amber-200/80 rounded-xl p-2 font-medium">
            ℹ️ <strong>Auto-Status Note:</strong> Once launched as Upcoming, it automatically transitions to <strong>Ongoing</strong> 24 hours before the start date, and switches to <strong>Completed</strong> when the event concludes.
          </p>

          {/* Upazila Scope */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              Sector / Scope <span className="text-emerald-600">*</span>
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-emerald-600" />
              <select
                value={upazilaScope}
                onChange={(e) => setUpazilaScope(e.target.value as 'District' | UpazilaName)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-900 font-medium transition"
              >
                <option value="District" className="font-bold">
                  {language === 'bn' ? '⭐ সমগ্র জেলা (১৩টি উপজেলা)' : '⭐ Entire District (All 13 Upazilas)'}
                </option>
                {MYMENSINGH_UPAZILAS.map((upz) => (
                  <option key={upz} value={upz}>
                    {language === 'bn' ? UPAZILA_BENGALI_NAMES[upz] : upz}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Banner Photo Upload (Demo banners removed as requested) */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              Banner Photo
            </label>
            <div className="flex items-center gap-3">
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold border border-emerald-300 px-3.5 py-2 rounded-xl text-xs transition cursor-pointer"
              >
                <UploadCloud className="w-4 h-4" />
                <span>Upload from Device</span>
              </button>

              <span className="text-slate-400 font-medium text-[11px]">or</span>

              <input
                type="url"
                placeholder="Paste Image URL"
                value={customBannerUrl}
                onChange={(e) => {
                  setCustomBannerUrl(e.target.value);
                  setUploadedImage(null);
                }}
                className="flex-1 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-800 placeholder-slate-400 font-medium"
              />
            </div>

            {/* Banner Preview if uploaded or URL provided */}
            {(uploadedImage || customBannerUrl) && (
              <div className="mt-2 relative h-28 w-full rounded-xl overflow-hidden border border-slate-200 shadow-2xs">
                <img
                  src={uploadedImage || customBannerUrl}
                  alt="Banner preview"
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => {
                    setUploadedImage(null);
                    setCustomBannerUrl('');
                  }}
                  className="absolute top-1.5 right-1.5 p-1 bg-black/60 hover:bg-black text-white rounded-full transition"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>

          {/* Starting Time & Closing Time */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Start Date & Time <span className="text-emerald-600">*</span>
              </label>
              <input
                type="datetime-local"
                required
                value={startingTime}
                onChange={(e) => setStartingTime(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Closing Date & Time <span className="text-emerald-600">*</span>
              </label>
              <input
                type="datetime-local"
                required
                value={closingTime}
                onChange={(e) => setClosingTime(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
              />
            </div>
          </div>

          {/* Venue & Location */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              Venue / Location Details
            </label>
            <div className="relative">
              <Building className="absolute left-3 top-2.5 w-4 h-4 text-emerald-600" />
              <input
                type="text"
                placeholder="e.g., Town Hall Grounds, Circuit House, or Zoom Link"
                value={venue}
                onChange={(e) => setVenue(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 font-medium"
              />
            </div>
          </div>

          {/* Project Leader & Project Co-Leader Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Project Leader Selection */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block font-bold text-slate-800">
                  Project Leader <span className="text-emerald-600">*</span>
                </label>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full font-army">
                  +125 XP/DHP
                </span>
              </div>
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsLeaderDropdownOpen(!isLeaderDropdownOpen)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 flex items-center justify-between text-left cursor-pointer hover:border-emerald-400"
                >
                  {selectedLeader ? (
                    <div className="flex items-center gap-2.5 truncate">
                      <img
                        src={selectedLeader.avatarUrl}
                        alt={selectedLeader.fullName}
                        className="w-6 h-6 rounded-full object-cover border border-emerald-500"
                      />
                      <div className="truncate">
                        <span className="font-bold text-slate-900 text-xs">{selectedLeader.fullName}</span>
                        <span className="text-[10px] text-slate-500 ml-1.5 font-medium">({selectedLeader.roleInVBD})</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-slate-400 font-medium text-xs">Select Project Leader</span>
                  )}
                  <ChevronDown className="w-4 h-4 text-slate-500" />
                </button>

                {isLeaderDropdownOpen && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2 space-y-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Search leader..."
                        value={leaderSearch}
                        onChange={(e) => setLeaderSearch(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-2 py-1.5 text-[11px]"
                      />
                    </div>
                    <div className="max-h-40 overflow-y-auto space-y-1">
                      {filteredLeaders.map((vol) => (
                        <div
                          key={vol.id}
                          onClick={() => {
                            setSelectedLeader(vol);
                            setIsLeaderDropdownOpen(false);
                          }}
                          className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-emerald-50 cursor-pointer transition"
                        >
                          <img src={vol.avatarUrl} alt={vol.fullName} className="w-6 h-6 rounded-full object-cover" />
                          <div className="truncate">
                            <p className="font-bold text-slate-800 text-[11px] truncate">{vol.fullName}</p>
                            <p className="text-[9px] text-slate-500">{vol.roleInVBD} • {vol.upazila}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Project Co - Leader Selection */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block font-bold text-slate-800">
                  Project Co - Leader
                </label>
                <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2 py-0.5 rounded-full font-army">
                  +100 XP/DHP
                </span>
              </div>
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsCoLeaderDropdownOpen(!isCoLeaderDropdownOpen)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 flex items-center justify-between text-left cursor-pointer hover:border-amber-400"
                >
                  {selectedCoLeader ? (
                    <div className="flex items-center gap-2.5 truncate">
                      <img
                        src={selectedCoLeader.avatarUrl}
                        alt={selectedCoLeader.fullName}
                        className="w-6 h-6 rounded-full object-cover border border-amber-500"
                      />
                      <div className="truncate">
                        <span className="font-bold text-slate-900 text-xs">{selectedCoLeader.fullName}</span>
                        <span className="text-[10px] text-slate-500 ml-1.5 font-medium">({selectedCoLeader.roleInVBD})</span>
                      </div>
                    </div>
                  ) : (
                    <span className="text-slate-400 font-medium text-xs">Select Co - Leader (Optional)</span>
                  )}
                  <ChevronDown className="w-4 h-4 text-slate-500" />
                </button>

                {isCoLeaderDropdownOpen && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2 space-y-2">
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Search co-leader..."
                        value={coLeaderSearch}
                        onChange={(e) => setCoLeaderSearch(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-2 py-1.5 text-[11px]"
                      />
                    </div>
                    {selectedCoLeader && (
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedCoLeader(null);
                          setIsCoLeaderDropdownOpen(false);
                        }}
                        className="w-full text-left p-1.5 text-rose-600 font-bold text-[10px] hover:bg-rose-50 rounded-lg transition"
                      >
                        ✕ Remove Co - Leader
                      </button>
                    )}
                    <div className="max-h-40 overflow-y-auto space-y-1">
                      {filteredCoLeaders.map((vol) => (
                        <div
                          key={vol.id}
                          onClick={() => {
                            setSelectedCoLeader(vol);
                            setIsCoLeaderDropdownOpen(false);
                          }}
                          className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-amber-50 cursor-pointer transition"
                        >
                          <img src={vol.avatarUrl} alt={vol.fullName} className="w-6 h-6 rounded-full object-cover" />
                          <div className="truncate">
                            <p className="font-bold text-slate-800 text-[11px] truncate">{vol.fullName}</p>
                            <p className="text-[9px] text-slate-500">{vol.roleInVBD} • {vol.upazila}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block font-bold text-slate-800 mb-1">
              Description & Objectives
            </label>
            <textarea
              rows={2}
              placeholder="Brief description of the initiative..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl p-3 text-xs text-slate-900 font-medium"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:text-slate-900 font-bold text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="bg-[#07531d] hover:bg-[#0b6e27] text-yellow-400 font-black px-6 py-2 rounded-xl text-xs shadow-md transition cursor-pointer"
            >
              {type === 'Project' ? 'Launch Project' : 'Schedule Meeting'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
