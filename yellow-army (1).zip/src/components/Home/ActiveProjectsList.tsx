import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  PlusCircle,
  Trophy,
  MapPin,
  Calendar,
  Trash2,
  Star,
  CheckCircle,
  ChevronRight,
  Sparkles,
  X,
  Filter,
} from 'lucide-react';
import { ProjectMeeting } from '../../types';
import { HomeStatCategory } from '../../App';
import { formatProjectDateRange, isProjectFinished } from '../../utils/projectStatusUtils';

interface ActiveProjectsListProps {
  onOpenLaunchModal: () => void;
  categoryFilter?: HomeStatCategory;
  onClearFilter?: () => void;
}

export const ActiveProjectsList: React.FC<ActiveProjectsListProps> = ({
  onOpenLaunchModal,
  categoryFilter = 'all',
  onClearFilter,
}) => {
  const {
    projects,
    activeProjects,
    currentUser,
    joinProject,
    leaveProject,
    toggleTopProject,
    deleteProject,
    isAdmin,
    canPost,
    openAuthModal,
    selectedUpazila,
    setSelectedUpazila,
    language,
    setSelectedProjectModal,
  } = useApp();

  const [filterType, setFilterType] = useState<'All' | 'Project' | 'Meeting'>('All');

  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth();

  // Determine base projects pool based on categoryFilter
  const basePool = (() => {
    if (categoryFilter === 'this_year') {
      return projects.filter((p) => {
        const d = new Date(p.startingTime || p.createdAt);
        return d.getFullYear() === currentYear;
      });
    }
    if (categoryFilter === 'this_month') {
      return projects.filter((p) => {
        const d = new Date(p.startingTime || p.createdAt);
        return d.getFullYear() === currentYear && d.getMonth() === currentMonth;
      });
    }
    if (categoryFilter === 'ongoing') {
      return projects.filter((p) => p.status === 'ongoing');
    }
    if (categoryFilter === 'upcoming') {
      return projects.filter((p) => p.status === 'upcoming');
    }
    // Default: active projects (ongoing + upcoming)
    return activeProjects;
  })();

  // Filter by Upazila Scope and Type (Project/Meeting)
  const filtered = basePool.filter((p) => {
    if (selectedUpazila !== 'District' && p.upazilaScope !== 'District' && p.upazilaScope !== selectedUpazila) {
      return false;
    }
    if (filterType !== 'All' && p.type !== filterType) {
      return false;
    }
    return true;
  });

  const getCategoryTitle = () => {
    switch (categoryFilter) {
      case 'this_year':
        return language === 'bn' ? `চলতি বছরের প্রজেক্ট (${filtered.length})` : `THIS YEAR'S OPERATIONS (${filtered.length})`;
      case 'this_month':
        return language === 'bn' ? `চলতি মাসের প্রজেক্ট (${filtered.length})` : `THIS MONTH'S OPERATIONS (${filtered.length})`;
      case 'ongoing':
        return language === 'bn' ? `চলমান প্রজেক্ট (${filtered.length})` : `ONGOING OPERATIONS (${filtered.length})`;
      case 'upcoming':
        return language === 'bn' ? `আসন্ন প্রজেক্ট (${filtered.length})` : `UPCOMING OPERATIONS (${filtered.length})`;
      default:
        return language === 'bn' ? `সক্রিয় প্রজেক্ট (${filtered.length})` : `ACTIVE OPERATIONS (${filtered.length})`;
    }
  };

  return (
    <div className="space-y-4">
      {/* Initialize New Project Button - Only for Admins/Moderators */}
      {canPost && (
        <button
          onClick={onOpenLaunchModal}
          className="w-full bg-[#065018] hover:bg-[#086320] border-2 border-emerald-500 text-yellow-400 py-3.5 px-6 rounded-full shadow-md flex items-center justify-center gap-2 font-army italic font-black uppercase tracking-wider text-xs sm:text-sm cursor-pointer transition transform active:scale-98"
        >
          <PlusCircle className="w-4 h-4 fill-yellow-400 text-[#065018]" />
          <span>+ INITIALIZE NEW PROJECT</span>
        </button>
      )}

      {/* Top Section Header with Left Vertical Pill Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="w-1.5 h-6 rounded-full bg-emerald-500"></div>
          <div className="bg-[#065018] border border-emerald-500/60 px-5 py-1.5 rounded-full shadow-xs flex items-center gap-2">
            <span className="font-army italic font-black text-xs sm:text-sm tracking-widest text-yellow-400 uppercase">
              {getCategoryTitle()}
            </span>
          </div>

          {/* Active Filter Pill & Clear Button */}
          {categoryFilter !== 'all' && onClearFilter && (
            <button
              onClick={onClearFilter}
              className="bg-yellow-100 hover:bg-yellow-200 text-slate-900 border border-yellow-400 px-3 py-1 rounded-full text-[11px] font-army italic font-black uppercase flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
            >
              <span>FILTER: {categoryFilter.replace('_', ' ')}</span>
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Pills: All, Projects, Meetings */}
        <div className="flex items-center gap-1.5 bg-white p-1 rounded-full border border-slate-200 shadow-2xs">
          {(['All', 'Project', 'Meeting'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1 text-[11px] font-army italic font-black uppercase rounded-full transition cursor-pointer ${
                filterType === type
                  ? 'bg-[#065018] text-yellow-400 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {type === 'All' ? 'ALL' : type === 'Project' ? 'PROJECTS' : 'MEETINGS'}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Active Projects */}
      {filtered.length === 0 ? (
        <div className="text-center py-10 bg-white rounded-[32px] border-2 border-dashed border-slate-200 p-6">
          <p className="font-army italic font-black text-xs text-slate-500 tracking-wider uppercase">
            {language === 'bn' ? 'এই ফিল্টারে বর্তমানে কোনো প্রজেক্ট নেই' : 'NO OPERATIONS FOUND IN THIS CATEGORY'}
          </p>
          <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
            {categoryFilter !== 'all' && onClearFilter && (
              <button
                onClick={onClearFilter}
                className="bg-yellow-400 text-slate-950 font-army italic font-black uppercase px-4 py-2 rounded-full text-xs transition cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
              >
                <span>SHOW ALL OPERATIONS</span>
              </button>
            )}
            <button
              onClick={onOpenLaunchModal}
              className="bg-[#065018] hover:bg-[#086320] text-yellow-400 font-army italic font-black uppercase px-4 py-2 rounded-full text-xs transition cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{language === 'bn' ? '+ নতুন প্রজেক্ট শুরু করুন' : 'LAUNCH INITIATIVE'}</span>
            </button>
            {selectedUpazila !== 'District' && (
              <button
                onClick={() => setSelectedUpazila('District')}
                className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-army italic font-black uppercase px-4 py-2 rounded-full text-xs transition cursor-pointer inline-flex items-center gap-1.5"
              >
                <span>{language === 'bn' ? 'জেলা ভিত্তিক সব প্রজেক্ট দেখুন' : 'VIEW ALL DISTRICT INITIATIVES'}</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5 sm:gap-5">
          {filtered.map((project, idx) => {
            const isFinished = isProjectFinished(project) || project.status === 'completed' || project.status === 'archived';
            const userIds = [
              currentUser?.id,
              currentUser?.firebaseUid,
              currentUser?.email?.toLowerCase(),
              currentUser?.volunteerIdCode,
            ].filter(Boolean) as string[];
            const isJoined = Boolean(
              currentUser &&
              project.registeredVolunteerIds &&
              project.registeredVolunteerIds.some((id) => userIds.includes(id))
            );
            const dateInfo = formatProjectDateRange(project.startingTime, project.closingTime);

            return (
              <div
                key={project.id ? `${project.id}-${idx}` : `active-proj-${idx}`}
                className="bg-white border-2 border-emerald-300/80 rounded-[32px] sm:rounded-[36px] p-3.5 sm:p-4 shadow-sm hover:shadow-md transition-all duration-200 relative overflow-hidden flex flex-col justify-between group"
              >
                <div onClick={() => setSelectedProjectModal(project)} className="cursor-pointer">
                  {/* Banner */}
                  <div className="relative h-52 sm:h-56 w-full rounded-[24px] overflow-hidden">
                    <img
                      src={project.bannerUrl}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent"></div>

                    {/* Status Badge: Upcoming (red), On Going (yellow), Completed (green) */}
                    <div
                      className={`absolute top-3 left-3 font-army italic font-black uppercase text-[10px] px-3 py-1 rounded-xl shadow-xs tracking-wider ${
                        isFinished
                          ? 'bg-emerald-600 text-white'
                          : project.status === 'ongoing'
                          ? 'bg-yellow-400 text-slate-950 border border-yellow-500'
                          : 'bg-red-600 text-white'
                      }`}
                    >
                      {isFinished
                        ? 'COMPLETED'
                        : project.status === 'ongoing'
                        ? 'ON GOING'
                        : 'UPCOMING'}
                    </div>

                    {/* Scope Badge */}
                    <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-xs text-slate-900 border border-slate-200 text-[10px] font-army italic font-black uppercase px-2.5 py-1 rounded-xl flex items-center gap-1 shadow-xs">
                      <MapPin className="w-3 h-3 text-[#0c7028]" />
                      <span>{project.upazilaScope.toUpperCase()}</span>
                    </div>

                    {dateInfo.isLongTerm && (
                      <div className="absolute bottom-3 left-3 bg-amber-400 text-slate-950 text-[9px] font-army font-black uppercase px-2.5 py-0.5 rounded-lg shadow-sm border border-amber-500">
                        🗓️ LONG-TERM MISSION ({dateInfo.durationDays} DAYS)
                      </div>
                    )}
                  </div>

                  {/* Ribbon Tag */}
                  <div className="mt-3.5 flex items-center justify-between">
                    <span className="bg-[#eef9f2] border border-[#bbf7d0] text-[#15803d] font-army italic font-black uppercase text-[10px] tracking-wider px-3 py-0.5 rounded-full inline-flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      {project.type.toUpperCase()}
                    </span>

                    <span className="text-[10px] font-army italic font-black uppercase text-slate-500">
                      {project.attendeesCount} VOLUNTEERS JOINED
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-army italic font-black uppercase text-slate-900 text-base sm:text-lg tracking-wider mt-2 line-clamp-2 leading-snug">
                    {project.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed font-medium">
                    {project.description}
                  </p>
                </div>

                {/* Footer Controls */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex flex-col text-[11px] font-army italic font-bold uppercase tracking-wider text-[#0c7028]">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#0c7028] shrink-0" />
                      {dateInfo.isLongTerm && dateInfo.endDate ? (
                        <span>
                          {dateInfo.startDate} – {dateInfo.endDate}
                        </span>
                      ) : (
                        <span>{dateInfo.startDate}</span>
                      )}
                    </div>
                    {dateInfo.isLongTerm && dateInfo.endDate && (
                      <span className="text-[9px] text-amber-700 font-bold ml-4 lowercase tracking-normal">
                        start: {dateInfo.startDate} • end: {dateInfo.endDate}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    {isAdmin && (
                      <button
                        onClick={() => toggleTopProject(project.id)}
                        className={`p-2 rounded-2xl border transition cursor-pointer ${
                          project.isTopProject
                            ? 'bg-amber-400 text-slate-950 border-amber-500 shadow-xs'
                            : 'bg-slate-100 hover:bg-amber-100 text-slate-600 border-slate-200'
                        }`}
                      >
                        <Star className={`w-3.5 h-3.5 ${project.isTopProject ? 'fill-slate-950' : ''}`} />
                      </button>
                    )}

                    {(isAdmin || project.leader?.id === currentUser?.id) && (
                      <button
                        onClick={() => deleteProject(project.id)}
                        className="p-2 rounded-2xl bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-600 border border-slate-200 transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {isFinished ? (
                      <span className="bg-slate-100 text-slate-500 font-army italic font-black uppercase px-3 py-1.5 rounded-2xl text-[10px] border border-slate-200">
                        COMPLETED
                      </span>
                    ) : isJoined ? (
                      <button
                        onClick={() => leaveProject(project.id)}
                        className="bg-emerald-50 hover:bg-rose-50 text-emerald-700 hover:text-rose-700 font-army italic font-black uppercase px-3 py-1.5 rounded-2xl text-[11px] border border-emerald-200 hover:border-rose-200 transition flex items-center gap-1 cursor-pointer"
                      >
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                        <span>JOINED</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => joinProject(project.id)}
                        className="bg-[#065018] hover:bg-[#086320] text-yellow-400 font-army italic font-black uppercase px-3.5 py-1.5 rounded-2xl text-[11px] shadow-xs transition flex items-center gap-1 border border-emerald-600 cursor-pointer"
                      >
                        <span>JOIN</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
