import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Trophy,
  Star,
  MapPin,
  Calendar,
  Trash2,
  Plus,
  X,
} from 'lucide-react';
import { formatProjectDateRange } from '../../utils/projectStatusUtils';

export const TopProjectsSection: React.FC = () => {
  const { topProjects, projects, toggleTopProject, deleteProject, isAdmin, currentUser } = useApp();
  const [showAddTopModal, setShowAddTopModal] = useState(false);

  const nonTopProjects = projects.filter((p) => !p.isTopProject && p.type === 'Project');

  return (
    <div className="space-y-4">
      {/* Top Achievements Section Header (Matching IMG_1215/1219) */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-1.5 h-6 rounded-full bg-amber-400"></div>
          <div className="bg-[#065018] border border-amber-400/90 px-6 py-1.5 rounded-full shadow-xs flex items-center gap-2">
            <Trophy className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
            <span className="font-army italic font-black text-xs sm:text-sm tracking-widest text-yellow-400 uppercase">
              TOP ACHIEVEMENTS ({topProjects.length})
            </span>
          </div>
        </div>

        {isAdmin && (
          <button
            onClick={() => setShowAddTopModal(true)}
            className="flex items-center gap-1.5 bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-army italic font-black px-4 py-1.5 rounded-full text-xs shadow-xs transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>FEATURE TO TOP</span>
          </button>
        )}
      </div>

      {/* Grid of Top Projects */}
      {topProjects.length === 0 ? (
        <div className="text-center py-8 bg-white rounded-[32px] border-2 border-dashed border-amber-200 p-6">
          <Trophy className="w-8 h-8 text-amber-400 mx-auto mb-2" />
          <p className="font-army italic font-black text-xs text-slate-600 tracking-wider uppercase">
            NO PROJECTS PINNED TO TOP ACHIEVEMENTS YET
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5 sm:gap-5">
          {topProjects.map((project, idx) => (
            <div
              key={project.id ? `${project.id}-${idx}` : `top-proj-${idx}`}
              className="bg-white border-2 border-amber-400/90 rounded-[32px] sm:rounded-[36px] p-3.5 sm:p-4 shadow-md hover:shadow-xl transition-all duration-300 relative overflow-hidden flex flex-col justify-between group"
            >
              <div>
                {/* Banner with Badges */}
                <div className="relative h-52 sm:h-56 w-full rounded-[24px] overflow-hidden">
                  <img
                    src={project.bannerUrl}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent"></div>

                  {/* Spotlight Badge (Golden Colour) */}
                  <div className="absolute top-3 left-3 bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-slate-950 font-army italic font-black text-[10px] sm:text-[11px] px-3.5 py-1 rounded-xl shadow-md border border-amber-200 tracking-wider uppercase">
                    SPOTLIGHT
                  </div>

                  {/* Trophy Badge */}
                  <div className="absolute top-3 right-3 w-9 h-9 rounded-full bg-yellow-400 text-yellow-950 flex items-center justify-center shadow-xs">
                    <Trophy className="w-4 h-4 fill-yellow-950" />
                  </div>
                </div>

                {/* Platinum Tag */}
                <div className="mt-3.5">
                  <span className="bg-gradient-to-r from-amber-500 to-amber-600 text-white font-army italic font-black text-[10px] tracking-wider px-3.5 py-1 rounded-full inline-flex items-center gap-1.5 shadow-xs uppercase">
                    <Star className="w-3 h-3 fill-white" />
                    DISTRICT HERO INITIATIVE
                  </span>
                </div>

                {/* Title */}
                <h3 className="font-army italic font-black uppercase text-slate-900 text-base sm:text-lg tracking-wider mt-2 line-clamp-2 leading-snug">
                  {project.title}
                </h3>

                {/* Description */}
                <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed font-medium">
                  {project.description}
                </p>
              </div>

              {/* Metadata & Actions */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="flex flex-col text-xs font-army italic font-black uppercase tracking-wider text-[#0c7028]">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#0c7028] fill-[#0c7028]" />
                      <span>{project.upazilaScope.toUpperCase()}</span>
                    </div>
                    {(() => {
                      const dateInfo = formatProjectDateRange(project.startingTime, project.closingTime);
                      return (
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-[#0c7028]" />
                          {dateInfo.isLongTerm && dateInfo.endDate ? (
                            <span>
                              {dateInfo.startDate} – {dateInfo.endDate}
                            </span>
                          ) : (
                            <span>{dateInfo.startDate}</span>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {isAdmin && (
                    <button
                      onClick={() => toggleTopProject(project.id)}
                      title="Unpin from Top"
                      className="p-2 rounded-2xl bg-amber-400 hover:bg-amber-300 text-slate-950 border border-amber-500 transition cursor-pointer"
                    >
                      <Star className="w-3.5 h-3.5 fill-slate-950" />
                    </button>
                  )}

                  {(isAdmin || project.leader?.id === currentUser?.id) && (
                    <button
                      onClick={() => deleteProject(project.id)}
                      title="Delete"
                      className="p-2 rounded-2xl bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-600 border border-slate-200 transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add to Top Modal */}
      {showAddTopModal && (
        <div
          onClick={() => setShowAddTopModal(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg bg-white border-2 border-yellow-400 rounded-[32px] shadow-xl p-6 text-slate-900 max-h-[80vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500 fill-amber-500" />
                <h3 className="font-army italic font-black uppercase text-sm text-slate-900">
                  FEATURE PROJECT TO TOP ACHIEVEMENTS
                </h3>
              </div>
              <button
                onClick={() => setShowAddTopModal(false)}
                className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {nonTopProjects.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">
                All projects are already featured in Top Achievements!
              </p>
            ) : (
              <div className="space-y-3">
                {nonTopProjects.map((p, idx) => (
                  <div
                    key={p.id ? `${p.id}-${idx}` : `nontop-proj-${idx}`}
                    className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-200"
                  >
                    <div className="flex items-center gap-3 truncate">
                      <img src={p.bannerUrl} alt={p.title} className="w-12 h-10 rounded-xl object-cover" />
                      <div className="truncate">
                        <p className="font-army italic font-bold text-xs text-slate-800 truncate uppercase">{p.title}</p>
                        <p className="text-[10px] text-slate-500 uppercase">{p.upazilaScope}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        toggleTopProject(p.id);
                        setShowAddTopModal(false);
                      }}
                      className="px-3.5 py-1.5 bg-[#065018] hover:bg-[#086320] text-yellow-400 font-army italic font-black uppercase rounded-full text-xs transition cursor-pointer"
                    >
                      PIN TO TOP
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
