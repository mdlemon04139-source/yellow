import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Trophy,
  MapPin,
  Calendar,
  Trash2,
  Star,
} from 'lucide-react';
import { formatProjectDateRange } from '../../utils/projectStatusUtils';

export const RecentCompletedProjects: React.FC = () => {
  const { recentCompletedProjects, deleteProject, toggleTopProject, setSelectedProjectModal, isAdmin, currentUser } = useApp();

  // Exactly the 3 most recently finished projects
  const displayProjects = recentCompletedProjects.slice(0, 3);

  return (
    <div className="space-y-4">
      {/* Section Header with Left Vertical Pill Bar (Matching IMG_1215) */}
      <div className="flex items-center gap-2.5">
        <div className="w-1.5 h-6 rounded-full bg-[#0c7028]"></div>
        <div className="bg-white/90 border border-slate-200/90 rounded-full px-5 py-2 shadow-xs">
          <span className="font-army italic font-black text-xs sm:text-sm tracking-[0.18em] text-slate-700 uppercase">
            RECENT ARCHIVES
          </span>
        </div>
      </div>

      {/* Grid of Completed Projects */}
      {displayProjects.length === 0 ? (
        <div className="py-12 bg-white/80 border border-dashed border-slate-200 rounded-[32px] p-6 text-center text-slate-400">
          <Trophy className="w-8 h-8 text-amber-400/50 mx-auto mb-2" />
          <p className="font-army italic font-black text-xs uppercase tracking-wider">
            NO COMPLETED PROJECT ARCHIVES AT THIS MOMENT
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4.5 sm:gap-5">
          {displayProjects.map((project, idx) => {
            const isPlatinum = idx === 0 || project.title.includes('RECYCLEAN');

            return (
              <div
                key={project.id ? `${project.id}-${idx}` : `completed-${idx}`}
                onClick={() => setSelectedProjectModal(project)}
                className="bg-white border-2 border-amber-400/90 rounded-[32px] sm:rounded-[36px] p-3.5 sm:p-4 shadow-md hover:shadow-xl transition-all duration-300 relative overflow-hidden flex flex-col justify-between space-y-3 group cursor-pointer"
              >
              <div className="space-y-3">
                {/* Banner with Badges */}
                <div className="relative h-52 sm:h-56 w-full rounded-[24px] overflow-hidden bg-slate-100">
                  <img
                    src={project.bannerUrl}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>

                  {/* Top-Left COMPLETED Badge (Green) */}
                  <div className="absolute top-3 left-3 bg-emerald-600 text-white font-army italic font-black text-[10px] sm:text-xs px-3.5 py-1 rounded-xl shadow-md uppercase tracking-wider">
                    COMPLETED
                  </div>

                  {/* Top-Right Circular Trophy Badge */}
                  <div className="absolute top-3 right-3 w-9 h-9 rounded-full bg-yellow-400 text-amber-950 border border-yellow-300 flex items-center justify-center shadow-md">
                    <Trophy className="w-4 h-4 fill-amber-950" />
                  </div>
                </div>

                {/* Platinum Milestone Tag */}
                {isPlatinum && (
                  <div>
                    <span className="bg-[#ea580c] text-white font-army italic font-black text-[10px] sm:text-[11px] px-3.5 py-1 rounded-full uppercase tracking-wider inline-flex items-center gap-1.5 shadow-xs">
                      <Trophy className="w-3 h-3 fill-white" />
                      PLATINUM MILESTONE
                    </span>
                  </div>
                )}

                {/* Project Title */}
                <h3 className="font-army italic font-black text-base sm:text-xl uppercase tracking-wider text-slate-900 line-clamp-1 leading-tight">
                  {project.title}
                </h3>

                {/* Scope & Date Row */}
                <div className="flex items-center justify-between text-xs sm:text-sm font-army italic font-bold text-[#0c7028]">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#0c7028] fill-[#0c7028]" />
                    <span className="uppercase">{project.upazilaScope}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-[#0c7028]" />
                    {(() => {
                      const dateInfo = formatProjectDateRange(project.startingTime, project.closingTime);
                      return dateInfo.isLongTerm && dateInfo.endDate ? (
                        <span>
                          {dateInfo.startDate} – {dateInfo.endDate}
                        </span>
                      ) : (
                        <span>{dateInfo.startDate}</span>
                      );
                    })()}
                  </div>
                </div>
              </div>

              {/* Metadata & Actions Footer */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleTopProject(project.id);
                  }}
                  title="Feature to Top Spotlight"
                  className={`w-9 h-9 rounded-full border flex items-center justify-center transition active:scale-95 shadow-xs cursor-pointer ${
                    project.isTopProject
                      ? 'bg-amber-400 text-slate-950 border-amber-500'
                      : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                  }`}
                >
                  <Star className={`w-4 h-4 ${project.isTopProject ? 'fill-slate-950' : ''}`} />
                </button>

                {(isAdmin || project.leader?.id === currentUser?.id) && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteProject(project.id);
                    }}
                    title="Delete Project"
                    className="w-9 h-9 rounded-full bg-slate-100 hover:bg-rose-100 border border-slate-200 hover:border-rose-300 text-slate-600 hover:text-rose-600 flex items-center justify-center transition active:scale-95 shadow-xs cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedProjectModal(project);
                  }}
                  title="Milestone Trophy"
                  className="w-9 h-9 rounded-full bg-amber-100 hover:bg-amber-200 border border-amber-300 text-amber-800 flex items-center justify-center transition active:scale-95 shadow-xs cursor-pointer"
                >
                  <Trophy className="w-4 h-4 fill-amber-700" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
      )}
    </div>
  );
};
