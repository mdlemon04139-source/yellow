import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  CalendarRange,
  CalendarDays,
  Activity,
  Hourglass,
  Check,
  Trophy,
  Flame,
  Clock,
} from 'lucide-react';
import { HomeStatCategory } from '../../App';
import { getEffectiveProjectStatus } from '../../utils/projectStatusUtils';

interface StatCardsProps {
  selectedCategory?: HomeStatCategory;
  onSelectCategory?: (category: HomeStatCategory) => void;
}

export const StatCards: React.FC<StatCardsProps> = ({
  selectedCategory = 'all',
  onSelectCategory,
}) => {
  const { stats, selectedUpazila, projects } = useApp();

  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const currentMonthName = now.toLocaleString('en-US', { month: 'short' });

  const filteredProjects = projects.filter((p) => {
    if (selectedUpazila === 'District') return true;
    return p.upazilaScope === 'District' || p.upazilaScope === selectedUpazila;
  });

  const thisYearCount = filteredProjects.filter((p) => {
    const d = new Date(p.startingTime || p.createdAt);
    return d.getFullYear() === currentYear;
  }).length;

  const thisMonthCount = filteredProjects.filter((p) => {
    const d = new Date(p.startingTime || p.createdAt);
    return d.getFullYear() === currentYear && d.getMonth() === currentMonth;
  }).length;

  const ongoingCount = filteredProjects.filter((p) => getEffectiveProjectStatus(p) === 'ongoing').length;
  const upcomingCount = filteredProjects.filter((p) => getEffectiveProjectStatus(p) === 'upcoming').length;

  const handleCardClick = (cat: HomeStatCategory) => {
    if (onSelectCategory) {
      onSelectCategory(cat);
    }
  };

  return (
    <div className="grid grid-cols-2 gap-2.5 sm:gap-4">
      {/* 1. THIS YEAR */}
      <button
        type="button"
        onClick={() => handleCardClick('this_year')}
        className={`bg-[#f0fdf4] border rounded-2xl sm:rounded-3xl p-3 sm:p-4 shadow-2xs flex flex-col justify-between transition-all duration-200 text-left cursor-pointer relative ${
          selectedCategory === 'this_year'
            ? 'border-emerald-600 ring-2 ring-emerald-500/50 bg-emerald-50 scale-[1.01]'
            : 'border-emerald-200 hover:border-emerald-300'
        }`}
      >
        <div className="flex items-center justify-between w-full">
          <span className="bg-white text-emerald-800 border border-emerald-200/80 px-2.5 py-1 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider inline-flex items-center gap-1.5 shadow-2xs">
            <CalendarRange className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>This Year</span>
          </span>
          {selectedCategory === 'this_year' && (
            <span className="bg-emerald-600 text-white rounded-full p-1 text-[10px] font-bold">
              <Check className="w-3 h-3" />
            </span>
          )}
        </div>

        <div className="mt-3 flex items-baseline justify-between w-full">
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl sm:text-4xl font-black text-emerald-700 tracking-tight block leading-none">
              {thisYearCount}
            </span>
            <span className="text-[11px] text-emerald-800 font-bold uppercase">
              Total
            </span>
          </div>
          <Trophy className="w-4 h-4 text-emerald-600 shrink-0 opacity-80" />
        </div>
      </button>

      {/* 2. THIS MONTH */}
      <button
        type="button"
        onClick={() => handleCardClick('this_month')}
        className={`bg-[#eff6ff] border rounded-2xl sm:rounded-3xl p-3 sm:p-4 shadow-2xs flex flex-col justify-between transition-all duration-200 text-left cursor-pointer relative ${
          selectedCategory === 'this_month'
            ? 'border-blue-600 ring-2 ring-blue-500/50 bg-blue-50 scale-[1.01]'
            : 'border-blue-200 hover:border-blue-300'
        }`}
      >
        <div className="flex items-center justify-between w-full">
          <span className="bg-white text-blue-800 border border-blue-200/80 px-2.5 py-1 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider inline-flex items-center gap-1.5 shadow-2xs">
            <CalendarDays className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span>This Month</span>
          </span>
          {selectedCategory === 'this_month' && (
            <span className="bg-blue-600 text-white rounded-full p-1 text-[10px] font-bold">
              <Check className="w-3 h-3" />
            </span>
          )}
        </div>

        <div className="mt-3 flex items-baseline justify-between w-full">
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl sm:text-4xl font-black text-blue-700 tracking-tight block leading-none">
              {thisMonthCount}
            </span>
            <span className="text-[11px] text-blue-800 font-bold uppercase">
              Active
            </span>
          </div>
          <Flame className="w-4 h-4 text-blue-600 shrink-0 opacity-80" />
        </div>
      </button>

      {/* 3. ONGOING */}
      <button
        type="button"
        onClick={() => handleCardClick('ongoing')}
        className={`bg-[#fff7ed] border rounded-2xl sm:rounded-3xl p-3 sm:p-4 shadow-2xs flex flex-col justify-between transition-all duration-200 text-left cursor-pointer relative ${
          selectedCategory === 'ongoing'
            ? 'border-orange-500 ring-2 ring-orange-400/50 bg-orange-50 scale-[1.01]'
            : 'border-orange-200 hover:border-orange-300'
        }`}
      >
        <div className="flex items-center justify-between w-full">
          <span className="bg-white text-orange-800 border border-orange-200/80 px-2.5 py-1 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider inline-flex items-center gap-1.5 shadow-2xs">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
            </span>
            <span>Ongoing</span>
          </span>
          {selectedCategory === 'ongoing' && (
            <span className="bg-orange-500 text-white rounded-full p-1 text-[10px] font-bold">
              <Check className="w-3 h-3" />
            </span>
          )}
        </div>

        <div className="mt-3 flex items-baseline justify-between w-full">
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl sm:text-4xl font-black text-orange-600 tracking-tight block leading-none">
              {ongoingCount}
            </span>
            <span className="text-[11px] text-orange-800 font-bold uppercase">
              Live
            </span>
          </div>
          <Activity className="w-4 h-4 text-orange-600 shrink-0 animate-pulse" />
        </div>
      </button>

      {/* 4. UPCOMING */}
      <button
        type="button"
        onClick={() => handleCardClick('upcoming')}
        className={`bg-[#fafaf9] border rounded-2xl sm:rounded-3xl p-3 sm:p-4 shadow-2xs flex flex-col justify-between transition-all duration-200 text-left cursor-pointer relative ${
          selectedCategory === 'upcoming'
            ? 'border-yellow-500 ring-2 ring-yellow-400/50 bg-yellow-50/50 scale-[1.01]'
            : 'border-slate-200 hover:border-yellow-400'
        }`}
      >
        <div className="flex items-center justify-between w-full">
          <span className="bg-slate-900 text-yellow-400 border border-slate-800 px-2.5 py-1 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider inline-flex items-center gap-1.5 shadow-2xs">
            <Hourglass className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
            <span>Upcoming</span>
          </span>
          {selectedCategory === 'upcoming' && (
            <span className="bg-yellow-500 text-slate-950 rounded-full p-1 text-[10px] font-bold">
              <Check className="w-3 h-3" />
            </span>
          )}
        </div>

        <div className="mt-3 flex items-baseline justify-between w-full">
          <div className="flex items-baseline gap-1.5">
            <span className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight block leading-none">
              {upcomingCount}
            </span>
            <span className="text-[11px] text-slate-600 font-bold uppercase">
              Planned
            </span>
          </div>
          <Clock className="w-4 h-4 text-amber-600 shrink-0" />
        </div>
      </button>
    </div>
  );
};
