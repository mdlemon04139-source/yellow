import React, { useState } from 'react';
import { useApp, isPermanentAdminEmail } from '../../context/AppContext';
import {
  Radio,
  Megaphone,
  BarChart2,
  PlusCircle,
  X,
  CheckCircle2,
  Trash2,
  ShieldCheck,
  AlertTriangle,
  Send,
  MessageSquare,
  Sparkles,
  Bell,
  CheckCheck,
  Calendar,
  Heart,
  Rocket,
  Star,
} from 'lucide-react';
import { RadioBroadcast, RadioPollOption } from '../../types';

export const RadioView: React.FC = () => {
  const {
    broadcasts,
    addRadioBroadcast,
    voteRadioPoll,
    reactToRadioBroadcast,
    deleteRadioBroadcast,
    currentUser,
    isAdmin,
    language,
    ensureRadioLoaded,
    notifications,
    unreadNotificationCount,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    deleteNotification,
    handleNotificationClick,
  } = useApp();

  // Lazy-load radio broadcasts strictly when the Radio tab is opened
  React.useEffect(() => {
    ensureRadioLoaded();
  }, [ensureRadioLoaded]);

  // Permission check: Admin or Moderator only can post
  const canPost =
    isAdmin ||
    currentUser?.adminRole === 'Super Admin' ||
    currentUser?.adminRole === 'District Coordinator' ||
    currentUser?.adminRole === 'Moderator' ||
    currentUser?.roleInVBD === 'Board Member' ||
    isPermanentAdminEmail(currentUser?.email);

  const [activeTabFilter, setActiveTabFilter] = useState<'feeds' | 'messages'>('feeds');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // New broadcast form state
  const [postType, setPostType] = useState<'message' | 'poll'>('message');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [category, setCategory] = useState<RadioBroadcast['category']>('Official Announcement');
  const [priority, setPriority] = useState<RadioBroadcast['priority']>('normal');
  const [pollOptions, setPollOptions] = useState<string[]>(['Option 1', 'Option 2']);

  // Filtered broadcast items (all broadcasts: messages and polls)
  const filteredBroadcasts = broadcasts;

  const handleAddPollOption = () => {
    if (pollOptions.length < 5) {
      setPollOptions([...pollOptions, `Option ${pollOptions.length + 1}`]);
    }
  };

  const handleRemovePollOption = (index: number) => {
    if (pollOptions.length > 2) {
      setPollOptions(pollOptions.filter((_, idx) => idx !== index));
    }
  };

  const handlePollOptionChange = (index: number, val: string) => {
    const updated = [...pollOptions];
    updated[index] = val;
    setPollOptions(updated);
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    let finalPollOptions: RadioPollOption[] | undefined;
    if (postType === 'poll') {
      finalPollOptions = pollOptions
        .filter((opt) => opt.trim().length > 0)
        .map((text, idx) => ({
          id: `opt-${Date.now()}-${idx}`,
          text: text.trim(),
          votes: 0,
        }));
    }

    await addRadioBroadcast({
      title: title.trim(),
      message: message.trim() || (postType === 'poll' ? 'Cast your vote in the official Yellow Army poll below.' : ''),
      speakerName: currentUser?.fullName || 'Command HQ',
      speakerRole: currentUser?.adminRole || currentUser?.roleInVBD || 'Command Admin',
      speakerAvatar:
        currentUser?.avatarUrl ||
        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      category,
      priority,
      contentType: postType,
      pollOptions: finalPollOptions,
      reactions: { '⚡': 1 },
      userReactions: currentUser ? { [currentUser.id]: '⚡' } : {},
    });

    setTitle('');
    setMessage('');
    setPollOptions(['Option 1', 'Option 2']);
    setShowCreateModal(false);
  };

  const availableReactions = ['⚡', '👍', '❤️', '🔥', '👏'];

  return (
    <div className="space-y-6">
      {/* Top Banner Header */}
      <div className="bg-white border border-slate-200 rounded-3xl p-5 sm:p-7 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="p-3 rounded-2xl bg-[#07531d] text-yellow-400 border border-emerald-600 shadow-xs">
            <Radio className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight font-army italic">
                {language === 'bn' ? 'রেডিও এইচকিউ (কমান্ড ব্রডকাস্ট)' : 'RADIO HQ (COMMAND DISPATCH)'}
              </h2>
              <span className="bg-rose-600 text-white text-[10px] font-army font-black tracking-widest px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-2xs">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
                LIVE
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {language === 'bn'
                ? 'এডমিন ও মডারেটরদের অফিসিয়াল বার্তা ও পোল • সকল ভলান্টিয়ার ভোট ও প্রতিক্রিয়া দিতে পারবেন'
                : 'Official messages & team polls by leadership • All volunteers can react and vote'}
            </p>
          </div>
        </div>

        {/* Action Button: Visible for Admins & Moderators */}
        {canPost ? (
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-[#07531d] hover:bg-[#0a6625] text-yellow-400 font-army italic font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-xs transition flex items-center gap-2 border border-emerald-700 cursor-pointer uppercase tracking-wider"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{language === 'bn' ? '+ বার্তা বা পোল দিন' : '+ NEW BROADCAST / POLL'}</span>
          </button>
        ) : (
          <div className="bg-slate-100 text-slate-600 text-xs font-semibold px-3 py-1.5 rounded-xl border border-slate-200 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>{language === 'bn' ? 'শুধুমাত্র অ্যাডমিন/মডারেটর ব্রডকাস্ট করতে পারেন' : 'Admin & Moderator Broadcast Only'}</span>
          </div>
        )}
      </div>

      {/* Filter Tabs: Exactly 2 tabs as requested */}
      <div className="flex flex-wrap items-center gap-2 bg-white border border-slate-200 p-2 sm:p-2.5 rounded-2xl shadow-2xs">
        <button
          onClick={() => setActiveTabFilter('feeds')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-army italic font-black uppercase transition cursor-pointer flex items-center gap-2 ${
            activeTabFilter === 'feeds'
              ? 'bg-[#07531d] text-yellow-400 shadow-xs'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          <Bell className="w-4 h-4" />
          <span>{language === 'bn' ? 'সকল ফিড (নোটিফিকেশন)' : 'ALL FEEDS'}</span>
          <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
            activeTabFilter === 'feeds' ? 'bg-yellow-400 text-slate-950' : 'bg-slate-200 text-slate-700'
          }`}>
            {notifications.length}
          </span>
          {unreadNotificationCount > 0 && (
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" title={`${unreadNotificationCount} unread`}></span>
          )}
        </button>

        <button
          onClick={() => setActiveTabFilter('messages')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-army italic font-black uppercase transition cursor-pointer flex items-center gap-2 ${
            activeTabFilter === 'messages'
              ? 'bg-[#07531d] text-yellow-400 shadow-xs'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>{language === 'bn' ? 'বার্তা ও পোল' : 'MESSAGES'}</span>
          <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
            activeTabFilter === 'messages' ? 'bg-yellow-400 text-slate-950' : 'bg-slate-200 text-slate-700'
          }`}>
            {broadcasts.length}
          </span>
        </button>
      </div>

      {/* TAB 1: ALL FEEDS (ALL NOTIFICATIONS DISPLAYED HERE) */}
      {activeTabFilter === 'feeds' && (
        <div className="space-y-3.5">
          {/* Header row with Feed Title and Mark All Read Button */}
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <span className="font-army italic font-black text-xs sm:text-sm tracking-wider uppercase text-slate-700">
                {language === 'bn' ? 'সক্রিয় অপারেশনাল ফিড ও অ্যালার্ট' : 'LIVE OPERATIONAL ALERTS & FEEDS'}
              </span>
              <span className="bg-emerald-100 text-[#07531d] text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase border border-emerald-300">
                {notifications.length} {language === 'bn' ? 'টি নোটিফিকেশন' : 'UPDATES'}
              </span>
            </div>

            {unreadNotificationCount > 0 && (
              <button
                onClick={markAllNotificationsAsRead}
                className="bg-emerald-50 hover:bg-emerald-100 text-[#07531d] text-xs font-army italic font-black uppercase px-3 py-1.5 rounded-xl border border-emerald-200 shadow-2xs flex items-center gap-1.5 transition cursor-pointer"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'সব পঠিত করুন' : 'MARK ALL READ'}</span>
              </button>
            )}
          </div>

          {/* Notifications List */}
          {notifications.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-[28px] border border-slate-200 p-6 shadow-xs">
              <Bell className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="font-army italic font-black text-xs text-slate-500 uppercase tracking-wider">
                {language === 'bn' ? 'বর্তমানে কোনো নতুন নোটিফিকেশন নেই' : 'NO NOTIFICATIONS FOUND IN ALL FEEDS'}
              </p>
            </div>
          ) : (
            notifications.map((n, idx) => {
              const isRoleReq = n.type === 'role_approval_request';
              const isLaunch = n.type === 'project_launch';
              const isMeeting = n.type === 'meeting';
              const isBlood = n.type === 'blood_request' || n.type === 'emergency_blood' || n.title.includes('Blood');
              const isTop = n.type === 'top_project';
              const isXpChange = n.type === 'xp_change' || n.title.toLowerCase().includes('xp');

              return (
                <div
                  key={n.id ? `${n.id}-${idx}` : `notif-feed-${idx}`}
                  onClick={() => {
                    handleNotificationClick(n);
                  }}
                  className={`bg-white rounded-[24px] p-4 sm:p-5 border shadow-xs hover:shadow-md transition cursor-pointer relative ${
                    !n.read
                      ? 'border-amber-300 ring-2 ring-amber-200/60 bg-amber-50/20'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      {/* Category Badge */}
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-army italic font-black uppercase tracking-wider border shadow-2xs ${
                          isXpChange
                            ? 'bg-amber-100 text-amber-900 border-amber-400'
                            : isRoleReq
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : isBlood
                            ? 'bg-rose-100 text-rose-900 border-rose-300'
                            : isLaunch
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : isMeeting
                            ? 'bg-blue-100 text-blue-900 border-blue-300'
                            : isTop
                            ? 'bg-yellow-100 text-yellow-900 border-yellow-300'
                            : 'bg-slate-100 text-slate-800 border-slate-300'
                        }`}
                      >
                        {isXpChange && <Star className="w-3 h-3 fill-amber-500 text-amber-600" />}
                        {isRoleReq && !isXpChange && <ShieldCheck className="w-3 h-3 text-amber-700" />}
                        {isBlood && <Heart className="w-3 h-3 text-rose-700" />}
                        {isLaunch && <Rocket className="w-3 h-3 text-emerald-700" />}
                        {isMeeting && <Calendar className="w-3 h-3 text-blue-700" />}
                        {isTop && <Sparkles className="w-3 h-3 text-yellow-700" />}
                        <span>
                          {isXpChange
                            ? 'POINTS UPDATE'
                            : isRoleReq
                            ? 'ROLE REQUEST'
                            : isBlood
                            ? 'BLOOD ALERT'
                            : isLaunch
                            ? 'PROJECT LAUNCH'
                            : isMeeting
                            ? 'MEETING'
                            : isTop
                            ? 'TOP SPOTLIGHT'
                            : 'ANNOUNCEMENT'}
                        </span>
                      </span>

                      {/* Upazila Tag */}
                      {n.upazila && (
                        <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                          {n.upazila}
                        </span>
                      )}

                      {/* Unread indicator */}
                      {!n.read && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded-full">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping"></span>
                          NEW
                        </span>
                      )}
                    </div>

                    {/* Timestamp & Dismiss */}
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-slate-400 font-medium whitespace-nowrap flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        {n.timestamp}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteNotification(n.id);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                        title="Dismiss"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Title & Body */}
                  <div className="mt-2.5">
                    <h4 className="font-army italic font-black text-slate-900 text-sm sm:text-base uppercase tracking-wide leading-snug">
                      {n.title}
                    </h4>
                    <p className="text-slate-600 text-xs sm:text-sm mt-1 leading-relaxed">
                      {n.message}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 2: MESSAGES & POLLS (DISPATCHES FEED) */}
      {activeTabFilter === 'messages' && (
      <div className="space-y-4">
        {filteredBroadcasts.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-[28px] border border-slate-200 p-6 shadow-xs">
            <Radio className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="font-army italic font-black text-xs text-slate-500 uppercase tracking-wider">
              {language === 'bn' ? 'কোনো বার্তা বা পোল পাওয়া যায়নি' : 'NO DISPATCHES OR POLLS AVAILABLE'}
            </p>
          </div>
        ) : (
          filteredBroadcasts.map((item) => {
            const isPoll = item.contentType === 'poll';
            const userVotedOptionId = currentUser ? item.pollVoters?.[currentUser.id] : undefined;

            // Calculate total poll votes
            const totalPollVotes = isPoll && item.pollOptions
              ? item.pollOptions.reduce((acc, curr) => acc + (curr.votes || 0), 0)
              : 0;

            return (
              <div
                key={item.id}
                className={`bg-white rounded-[26px] p-5 sm:p-6 border shadow-xs transition hover:shadow-md space-y-4 relative ${
                  item.priority === 'urgent'
                    ? 'border-rose-300 ring-1 ring-rose-300'
                    : 'border-slate-200'
                }`}
              >
                {/* Speaker Header Row */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.speakerAvatar}
                      alt={item.speakerName}
                      className="w-11 h-11 rounded-full object-cover border-2 border-emerald-500 shadow-xs"
                    />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-army font-black text-sm text-slate-900 uppercase">
                          {item.speakerName}
                        </h4>
                        <span className="bg-[#07531d] text-yellow-400 text-[10px] font-army font-black px-2 py-0.5 rounded shadow-2xs">
                          {item.speakerRole}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {item.timestamp} • {item.category}
                      </p>
                    </div>
                  </div>

                  {/* Priority and Admin Delete */}
                  <div className="flex items-center gap-2">
                    {item.priority === 'urgent' && (
                      <span className="bg-rose-100 text-rose-700 text-[10px] font-black uppercase px-2 py-0.5 rounded-full border border-rose-200 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 text-rose-600" />
                        URGENT
                      </span>
                    )}

                    {isPoll && (
                      <span className="bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-army font-black uppercase px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <BarChart2 className="w-3 h-3" />
                        POLL
                      </span>
                    )}

                    {/* Admin Delete with inline confirmation right here */}
                    {canPost && (
                      <div className="relative">
                        {deleteConfirmId === item.id ? (
                          <div className="flex items-center gap-1.5 bg-rose-50 border border-rose-300 px-2 py-0.5 rounded-xl shadow-xs animate-fadeIn">
                            <span className="text-[10px] font-bold text-rose-700">Delete?</span>
                            <button
                              onClick={() => {
                                deleteRadioBroadcast(item.id);
                                setDeleteConfirmId(null);
                              }}
                              className="px-2 py-0.5 bg-rose-600 hover:bg-rose-700 text-white rounded text-[10px] font-bold transition cursor-pointer"
                            >
                              Yes
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(null)}
                              className="px-1.5 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[10px] font-bold transition cursor-pointer"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setDeleteConfirmId(item.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 transition cursor-pointer rounded-lg hover:bg-slate-100"
                            title="Delete broadcast"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Content: Title & Message */}
                <div className="space-y-1.5">
                  <h3 className="font-bold text-base sm:text-lg text-slate-900 leading-snug">
                    {item.title}
                  </h3>
                  {item.message && (
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                      {item.message}
                    </p>
                  )}
                </div>

                {/* POLL INTERACTION BLOCK (All Users Can Vote!) */}
                {isPoll && item.pollOptions && item.pollOptions.length > 0 && (
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                      <span className="font-army uppercase tracking-wider text-slate-700">
                        {language === 'bn' ? 'ভোট দিন (ক্লিক করুন):' : 'CAST YOUR VOTE (CLICK TO SELECT):'}
                      </span>
                      <span className="text-slate-500 font-mono">
                        {totalPollVotes} {totalPollVotes === 1 ? 'vote' : 'total votes'}
                      </span>
                    </div>

                    <div className="space-y-2">
                      {item.pollOptions.map((opt) => {
                        const isSelected = userVotedOptionId === opt.id;
                        const pct = totalPollVotes > 0 ? Math.round((opt.votes / totalPollVotes) * 100) : 0;

                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => voteRadioPoll(item.id, opt.id)}
                            className={`w-full text-left p-3 rounded-xl border transition relative overflow-hidden cursor-pointer group ${
                              isSelected
                                ? 'border-yellow-400 bg-yellow-50/70 ring-1 ring-yellow-400'
                                : 'border-slate-200 bg-white hover:border-emerald-300'
                            }`}
                          >
                            {/* Vote Percentage Progress Bar */}
                            <div
                              className={`absolute top-0 bottom-0 left-0 transition-all duration-500 ${
                                isSelected ? 'bg-yellow-200/50' : 'bg-emerald-50'
                              }`}
                              style={{ width: `${pct}%` }}
                            />

                            {/* Content Over Progress Bar */}
                            <div className="relative z-10 flex items-center justify-between gap-3 text-xs">
                              <div className="flex items-center gap-2">
                                {isSelected ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                                ) : (
                                  <span className="w-4 h-4 rounded-full border border-slate-300 inline-block shrink-0"></span>
                                )}
                                <span className={`font-semibold ${isSelected ? 'text-slate-900 font-bold' : 'text-slate-800'}`}>
                                  {opt.text}
                                </span>
                              </div>

                              <div className="flex items-center gap-2 font-mono shrink-0">
                                <span className="text-slate-500">{opt.votes}</span>
                                <span className="font-bold text-slate-900 bg-white/80 px-2 py-0.5 rounded border border-slate-200 text-[11px]">
                                  {pct}%
                                </span>
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* INTERACTIVE REACTIONS BAR (All Users Can React!) */}
                <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {availableReactions.map((emoji) => {
                      const count = item.reactions?.[emoji] || 0;
                      const hasUserReacted = currentUser && item.userReactions?.[currentUser.id] === emoji;

                      return (
                        <button
                          key={emoji}
                          type="button"
                          onClick={() => reactToRadioBroadcast(item.id, emoji)}
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                            hasUserReacted
                              ? 'bg-yellow-100 border border-yellow-400 text-slate-950 scale-105 shadow-2xs'
                              : count > 0
                              ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                              : 'bg-transparent hover:bg-slate-100 text-slate-400 border border-transparent'
                          }`}
                          title={`React with ${emoji}`}
                        >
                          <span>{emoji}</span>
                          {count > 0 && <span className="text-[11px] font-mono">{count}</span>}
                        </button>
                      );
                    })}
                  </div>

                  <span className="text-[11px] text-slate-400 font-medium">
                    {language === 'bn' ? 'প্রতিক্রিয়া দিতে ইমোজিতে ক্লিক করুন' : 'Tap emoji to react'}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
      )}

      {/* CREATE BROADCAST OR POLL MODAL (Admin / Moderator Only) */}
      {showCreateModal && (
        <div
          onClick={() => setShowCreateModal(false)}
          className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
          style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden p-6 relative my-auto animate-fadeIn space-y-4"
          >
            <button
              onClick={() => setShowCreateModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div>
              <div className="inline-flex items-center gap-1.5 bg-[#07531d] text-yellow-400 px-3 py-1 rounded-full text-xs font-army italic font-black uppercase tracking-wider mb-2">
                <span>COMMAND DISPATCH CONSOLE</span>
              </div>
              <h3 className="text-xl font-black text-slate-900">
                {language === 'bn' ? 'নতুন ব্রডকাস্ট বা পোল প্রকাশ করুন' : 'Publish Command Broadcast or Poll'}
              </h3>
              <p className="text-xs text-slate-500">
                {language === 'bn'
                  ? 'বার্তা পুরো জেলায় প্রদর্শিত হবে এবং সবাই প্রতিক্রিয়া জানাতে পারবে।'
                  : 'Broadcast to all volunteers with instant reactions & voting.'}
              </p>
            </div>

            {/* Type Switcher: Message vs Poll */}
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1.5 rounded-2xl">
              <button
                type="button"
                onClick={() => setPostType('message')}
                className={`py-2 rounded-xl text-xs font-army italic font-black uppercase transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  postType === 'message'
                    ? 'bg-[#07531d] text-yellow-400 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'বার্তা প্রকাশ' : 'MESSAGE'}</span>
              </button>
              <button
                type="button"
                onClick={() => setPostType('poll')}
                className={`py-2 rounded-xl text-xs font-army italic font-black uppercase transition cursor-pointer flex items-center justify-center gap-1.5 ${
                  postType === 'poll'
                    ? 'bg-[#07531d] text-yellow-400 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <BarChart2 className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'ভোট পোল' : 'INTERACTIVE POLL'}</span>
              </button>
            </div>

            <form onSubmit={handlePublish} className="space-y-3.5">
              {/* Title / Question */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  {postType === 'poll'
                    ? (language === 'bn' ? 'পোলের প্রশ্ন' : 'Poll Question')
                    : (language === 'bn' ? 'বার্তার শিরোনাম' : 'Dispatch Title')}{' '}
                  <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    postType === 'poll'
                      ? 'e.g., Should we schedule the flood relief drive this Friday?'
                      : 'e.g., Emergency Coordination Briefing for Sadar Sector'
                  }
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2.5 text-xs text-slate-900 font-medium"
                />
              </div>

              {/* Message / Description */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  {postType === 'poll'
                    ? (language === 'bn' ? 'পোলের বিবরণ (ঐচ্ছিক)' : 'Poll Description (Optional)')
                    : (language === 'bn' ? 'বার্তা বিস্তারিত' : 'Message Body')}{' '}
                  {postType === 'message' && <span className="text-rose-600">*</span>}
                </label>
                <textarea
                  rows={3}
                  required={postType === 'message'}
                  placeholder="Enter complete directive details or voting instructions..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
                />
              </div>

              {/* Poll Options (If Poll) */}
              {postType === 'poll' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-slate-800">
                      {language === 'bn' ? 'পোলের অপশনসমূহ' : 'Poll Options (2 to 5)'}
                    </label>
                    {pollOptions.length < 5 && (
                      <button
                        type="button"
                        onClick={handleAddPollOption}
                        className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer"
                      >
                        + Add Option
                      </button>
                    )}
                  </div>
                  {pollOptions.map((opt, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        required
                        value={opt}
                        onChange={(e) => handlePollOptionChange(idx, e.target.value)}
                        placeholder={`Option ${idx + 1}`}
                        className="flex-1 bg-slate-50 border border-slate-200 focus:border-emerald-500 rounded-xl px-3 py-2 text-xs text-slate-900 font-medium"
                      />
                      {pollOptions.length > 2 && (
                        <button
                          type="button"
                          onClick={() => handleRemovePollOption(idx)}
                          className="text-slate-400 hover:text-rose-500 p-1 cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Category & Priority */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    {language === 'bn' ? 'বিভাগ' : 'Category'}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium"
                  >
                    <option value="Official Announcement">Official Announcement</option>
                    <option value="District Alert">District Alert</option>
                    <option value="Emergency SOS">Emergency SOS</option>
                    <option value="Meeting Briefing">Meeting Briefing</option>
                    <option value="Field Report">Field Report</option>
                    <option value="General">General</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1">
                    {language === 'bn' ? 'অগ্রাধিকার' : 'Priority'}
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium"
                  >
                    <option value="normal">Normal</option>
                    <option value="high">High</option>
                    <option value="urgent">🚨 Urgent (SOS)</option>
                  </select>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#07531d] hover:bg-[#0a6625] text-yellow-400 font-army italic font-black uppercase tracking-wider rounded-xl text-xs transition cursor-pointer shadow-xs"
                >
                  {postType === 'poll' ? 'PUBLISH POLL' : 'DISPATCH MESSAGE'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
