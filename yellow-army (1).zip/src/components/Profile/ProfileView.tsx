import React, { useState, useRef, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  User,
  Droplet,
  MapPin,
  Calendar,
  Phone,
  Mail,
  Award,
  Clock,
  Sparkles,
  Settings,
  Camera,
  Edit3,
  LogOut,
  Globe,
  X,
  LogIn,
  UserPlus,
  ShieldCheck,
  Shield,
  Check,
  Star,
  Trophy,
  Medal,
  Crown,
  Flame,
  CheckCircle2,
  QrCode,
  Download,
} from 'lucide-react';
import { Volunteer, AdminRole, BloodGroup, VBDRole, BoardType, UpazilaName, MYMENSINGH_UPAZILAS, UPAZILA_BENGALI_NAMES } from '../../types';
import { translations } from '../../utils/translations';
import { compressImage, isUserCustomPhoto, isUserCustomCover, inMemoryImageStore } from '../../utils/storageAndImage';
import { getCartoonYellowAvatar } from '../../utils/avatarUtils';
import { getDhpSeasonCountdown, DhpSeasonInfo, calculateVolunteerLevel } from '../../utils/gamification';
import { getVolunteerUnifiedQrCodeImage } from '../../utils/qrUtils';

export const ProfileView: React.FC = () => {
  const {
    currentUser,
    volunteers,
    viewingVolunteer,
    setViewingVolunteer,
    updateProfile,
    updateVolunteerDetails,
    isAdmin,
    logout,
    openAuthModal,
    projects,
    language,
    setLanguage,
    setActiveTab,
    dismissPendingPromotionNotice,
    awardOrDeductPoints,
  } = useApp();

  const t = translations[language];

  // Resolve with latest live volunteer data from volunteers state so point changes reflect immediately
  const liveViewingVolunteer = viewingVolunteer
    ? (volunteers.find((v) => v.id === viewingVolunteer.id) || viewingVolunteer)
    : null;
  const liveCurrentUser = currentUser
    ? (volunteers.find((v) => v.id === currentUser.id || (v.email && currentUser.email && v.email.toLowerCase() === currentUser.email.toLowerCase())) || currentUser)
    : null;
  const activeVolunteer = liveViewingVolunteer || (currentUser ? { ...liveCurrentUser, ...currentUser } : liveCurrentUser);
  const isOwnProfile = !liveViewingVolunteer || (liveCurrentUser && liveViewingVolunteer.id === liveCurrentUser.id);
  const canEdit = Boolean(isOwnProfile || isAdmin);

  const [isEditing, setIsEditing] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showAdminPointsForm, setShowAdminPointsForm] = useState(false);
  const [xpDelta, setXpDelta] = useState(50);
  const [dhpDelta, setDhpDelta] = useState(50);
  const [isDeduct, setIsDeduct] = useState(false);
  const [pointReason, setPointReason] = useState('Outstanding Field Leadership');
  const [isSubmittingPoints, setIsSubmittingPoints] = useState(false);
  const [editAdminRole, setEditAdminRole] = useState<AdminRole>('General Member');

  const [fullName, setFullName] = useState(currentUser?.fullName || 'RI RAHAT');
  const [mobileNo, setMobileNo] = useState(currentUser?.mobileNo || '01736813344');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>(currentUser?.bloodGroup || 'B+');
  const [isBloodDonor, setIsBloodDonor] = useState<boolean>(currentUser?.isBloodDonor !== false);
  const [lastBloodDonationDate, setLastBloodDonationDate] = useState(currentUser?.lastBloodDonationDate || '');
  const [dateOfBirth, setDateOfBirth] = useState(currentUser?.dateOfBirth || '');
  const [roleInVBD, setRoleInVBD] = useState<VBDRole>(currentUser?.roleInVBD || 'General Member');
  const [boardType, setBoardType] = useState<BoardType>(currentUser?.boardType || 'Upazila Board');
  const [showBoardTypeModal, setShowBoardTypeModal] = useState(false);
  const [upazila, setUpazila] = useState<UpazilaName>(currentUser?.upazila || 'Mymensingh Sadar');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [avatarUrl, setAvatarUrl] = useState(currentUser?.avatarUrl || '');
  const [coverUrl, setCoverUrl] = useState(currentUser?.coverUrl || '');
  const [isCopied, setIsCopied] = useState(false);
  const [countdown, setCountdown] = useState<DhpSeasonInfo>(getDhpSeasonCountdown());

  const openEditModal = () => {
    const target = activeVolunteer || currentUser;
    if (!target) return;
    setFullName(target.fullName || '');
    setMobileNo(target.mobileNo || '');
    setBloodGroup(target.bloodGroup || 'B+');
    setIsBloodDonor(target.isBloodDonor !== false);
    setLastBloodDonationDate(target.lastBloodDonationDate || '');
    setDateOfBirth(target.dateOfBirth || '');
    setRoleInVBD(target.roleInVBD || 'General Member');
    setBoardType(target.boardType || 'Upazila Board');
    setUpazila(target.upazila || 'Mymensingh Sadar');
    setBio(target.bio || '');
    setAvatarUrl(target.avatarUrl || '');
    setCoverUrl(target.coverUrl || '');
    setEditAdminRole(target.adminRole || 'General Member');
    setIsEditing(true);
  };

  // Check 3-month blood donation window (90 days)
  const getDonationEligibility = (dateStr?: string) => {
    if (!dateStr) return { eligible: true, text: 'Ready to donate', detail: 'No donation recorded' };
    const last = new Date(dateStr).getTime();
    if (isNaN(last)) return { eligible: true, text: 'Ready to donate', detail: 'Invalid date' };
    const now = Date.now();
    const diffDays = Math.floor((now - last) / (1000 * 60 * 60 * 24));
    if (diffDays < 90) {
      const rest = 90 - diffDays;
      return {
        eligible: false,
        text: 'Not ready for donate',
        detail: `Donated ${diffDays} days ago (${rest} days rest remaining)`,
      };
    }
    return {
      eligible: true,
      text: 'Ready to donate',
      detail: `Last donated ${diffDays} days ago`,
    };
  };

  const donationEligibility = useMemo(() => {
    return getDonationEligibility(activeVolunteer?.lastBloodDonationDate);
  }, [activeVolunteer?.lastBloodDonationDate]);

  // Keep form fields synchronized with currentUser when user logs in or profile changes
  React.useEffect(() => {
    if (currentUser) {
      setFullName(currentUser.fullName || '');
      setMobileNo(currentUser.mobileNo || '');
      setBloodGroup(currentUser.bloodGroup || 'B+');
      setIsBloodDonor(currentUser.isBloodDonor !== false);
      setLastBloodDonationDate(currentUser.lastBloodDonationDate || '');
      setDateOfBirth(currentUser.dateOfBirth || '');
      setRoleInVBD(currentUser.roleInVBD || 'General Member');
      setBoardType(currentUser.boardType || 'Upazila Board');
      setUpazila(currentUser.upazila || 'Mymensingh Sadar');
      setBio(currentUser.bio || '');
      setAvatarUrl(currentUser.avatarUrl || '');
      setCoverUrl(currentUser.coverUrl || '');
    }
  }, [currentUser]);

  React.useEffect(() => {
    setCountdown(getDhpSeasonCountdown());
  }, []);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  if (!activeVolunteer) {
    return (
      <div className="max-w-xl mx-auto py-8 px-4 animate-fadeIn">
        <div className="bg-white rounded-[32px] border-2 border-emerald-500/40 p-6 sm:p-8 shadow-xl text-center space-y-4">
          <div className="w-16 h-16 rounded-2xl bg-[#065018] text-yellow-400 flex items-center justify-center mx-auto font-army italic font-black text-2xl shadow-md border border-emerald-700">
            YA
          </div>
          <h2 className="font-army italic font-black text-2xl text-slate-900 uppercase">
            YELLOW ARMY VOLUNTEER HQ
          </h2>
          <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed font-medium">
            Sign in to access your volunteer dossier, Level of Volunteerism, District Heroes Points (DHP), and Mymensingh District initiatives.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => openAuthModal('login')}
              className="w-full sm:w-auto flex items-center justify-center gap-2 bg-[#065018] hover:bg-[#086320] text-yellow-400 font-army italic font-black px-6 py-3 rounded-full text-xs shadow-md transition cursor-pointer"
            >
              <LogIn className="w-4 h-4" />
              <span>SIGN IN TO PROFILE</span>
            </button>

            <button
              onClick={() => openAuthModal('signup')}
              className="w-full sm:w-auto flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-army italic font-bold px-6 py-3 rounded-full text-xs transition cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>NEW RECRUIT REGISTRATION</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Handle direct photo upload with fast canvas compression (under 50KB)
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const compressedAvatar = await compressImage(file, 400, 400, 0.8);
      if (compressedAvatar) {
        setAvatarUrl(compressedAvatar);
        updateProfile({ avatarUrl: compressedAvatar });
      }
    }
  };

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const compressedCover = await compressImage(file, 900, 450, 0.75);
      if (compressedCover) {
        setCoverUrl(compressedCover);
        updateProfile({ coverUrl: compressedCover });
      }
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeVolunteer) return;

    if (isAdmin && !isOwnProfile) {
      // Admin editing any volunteer's profile
      const updatedData: Partial<Volunteer> = {
        fullName,
        mobileNo,
        bloodGroup,
        isBloodDonor,
        lastBloodDonationDate,
        dateOfBirth,
        roleInVBD,
        boardType: roleInVBD === 'Board Member' ? boardType : undefined,
        upazila,
        bio,
        adminRole: editAdminRole,
        avatarUrl: avatarUrl || activeVolunteer.avatarUrl,
        coverUrl: coverUrl || activeVolunteer.coverUrl,
      };
      await updateVolunteerDetails(activeVolunteer.id, updatedData);
      setViewingVolunteer({
        ...activeVolunteer,
        ...updatedData,
      });
      setIsEditing(false);
      return;
    }

    if (!isAdmin && roleInVBD === 'Board Member' && activeVolunteer.roleInVBD !== 'Board Member') {
      alert(
        language === 'bn'
          ? 'বোর্ড মেম্বার পদবির আবেদনটি পর্যালোচনার জন্য জেলা অ্যাডমিনদের কাছে জমা হয়েছে। অ্যাডমিন অনুমোদন দেওয়া পর্যন্ত আপনার বর্তমান পদবি বহাল থাকবে।'
          : 'Your application for Board Member role has been submitted for Admin Review. It will become active once approved by District Admins.'
      );
    }

    await updateProfile({
      fullName,
      mobileNo,
      bloodGroup,
      isBloodDonor,
      lastBloodDonationDate,
      dateOfBirth,
      roleInVBD,
      boardType: roleInVBD === 'Board Member' ? boardType : undefined,
      upazila,
      bio,
      ...(isAdmin ? { adminRole: editAdminRole } : {}),
      avatarUrl: avatarUrl || currentUser?.avatarUrl,
      coverUrl: coverUrl || currentUser?.coverUrl,
    });
    setIsEditing(false);
  };

  const userProjects = projects.filter((p) =>
    p.registeredVolunteerIds?.includes(activeVolunteer.id)
  );

  const dhpPoints = typeof activeVolunteer.dhp === 'number' ? activeVolunteer.dhp : typeof activeVolunteer.dhpPoints === 'number' ? activeVolunteer.dhpPoints : 0;
  const volunteeringScore = typeof activeVolunteer.xp === 'number' ? activeVolunteer.xp : typeof activeVolunteer.volunteeringScore === 'number' ? activeVolunteer.volunteeringScore : 0;
  const volunteerRank = activeVolunteer.rankName || 'TRAINEE VOLUNTEER';
  const levelData = calculateVolunteerLevel(volunteeringScore);
  const isAlumni = activeVolunteer.roleInVBD === 'Alumni' || activeVolunteer.status === 'alumni';

  // Badge Color-Coding: General Member (none), Committee Member (yellow), Upazila Board (yellow), District Board (deep green), Alumni (black)
  const renderAvatarRoleBadge = () => {
    if (!activeVolunteer?.roleInVBD || activeVolunteer.roleInVBD === 'General Member') return null;

    if (activeVolunteer.roleInVBD === 'Board Member') {
      const isDistrict = activeVolunteer.boardType === 'District Board';
      return (
        <span
          title={isDistrict ? 'District Board Member' : 'Upazila Board Member'}
          className={`absolute -bottom-1 -right-1 px-2.5 py-0.5 rounded-full ${
            isDistrict
              ? 'bg-[#053712] text-white border-2 border-white'
              : 'bg-yellow-400 text-slate-950 border-2 border-white font-black'
          } shadow-md text-[9px] font-black tracking-wider uppercase`}
        >
          {isDistrict ? 'DISTRICT BOARD' : 'UPAZILA BOARD'}
        </span>
      );
    }

    if (activeVolunteer.roleInVBD === 'Committee Member') {
      return (
        <span
          title="Committee Member"
          className="absolute -bottom-1 -right-1 px-2 py-0.5 rounded-full bg-yellow-400 text-slate-950 border-2 border-white shadow-md text-[9px] font-black tracking-wider uppercase"
        >
          COMMITTEE
        </span>
      );
    }

    if (activeVolunteer.roleInVBD === 'Alumni') {
      return (
        <span
          title="Alumni"
          className="absolute -bottom-1 -right-1 px-2 py-0.5 rounded-full bg-black text-yellow-400 border-2 border-white shadow-md text-[9px] font-black tracking-wider uppercase"
        >
          ALUMNI
        </span>
      );
    }

    return null;
  };

  const getRolePillClasses = (role?: VBDRole, bType?: BoardType) => {
    if (role === 'Board Member') {
      if (bType === 'District Board') {
        return 'bg-[#053712] text-white border-2 border-emerald-600 shadow-md';
      }
      return 'bg-yellow-400 text-slate-950 border-2 border-yellow-500 font-black shadow-md';
    }
    if (role === 'Committee Member') return 'bg-yellow-400 text-slate-950 border border-yellow-500 font-black shadow-md';
    if (role === 'Alumni') return 'bg-black text-yellow-300 border border-yellow-500/50 shadow-md';
    return 'bg-slate-800 text-slate-100 border border-slate-700 shadow-md';
  };

  const memoryPhotos = useMemo(() => {
    if (!activeVolunteer) return null;
    return (
      inMemoryImageStore.get(activeVolunteer.id) ||
      inMemoryImageStore.get((activeVolunteer.email || '').toLowerCase())
    );
  }, [activeVolunteer?.id, activeVolunteer?.email]);

  const effectiveAvatar = useMemo(() => {
    if (isOwnProfile && isUserCustomPhoto(avatarUrl)) return avatarUrl;
    if (isUserCustomPhoto(activeVolunteer?.avatarUrl)) return activeVolunteer.avatarUrl;
    if (isUserCustomPhoto(currentUser?.avatarUrl)) return currentUser!.avatarUrl;
    if (memoryPhotos?.avatarUrl && isUserCustomPhoto(memoryPhotos.avatarUrl)) return memoryPhotos.avatarUrl;
    if (avatarUrl && !avatarUrl.includes('data:image/svg') && !avatarUrl.includes('photo-15')) return avatarUrl;
    if (activeVolunteer?.avatarUrl && !activeVolunteer.avatarUrl.includes('data:image/svg') && !activeVolunteer.avatarUrl.includes('photo-15')) return activeVolunteer.avatarUrl;
    return (
      avatarUrl ||
      activeVolunteer?.avatarUrl ||
      getCartoonYellowAvatar(activeVolunteer?.gender, activeVolunteer?.fullName)
    );
  }, [isOwnProfile, avatarUrl, activeVolunteer?.avatarUrl, activeVolunteer?.gender, activeVolunteer?.fullName, currentUser?.avatarUrl, memoryPhotos]);

  const effectiveCover = useMemo(() => {
    if (isOwnProfile && isUserCustomCover(coverUrl)) return coverUrl;
    if (isUserCustomCover(activeVolunteer?.coverUrl)) return activeVolunteer.coverUrl;
    if (isUserCustomCover(currentUser?.coverUrl)) return currentUser!.coverUrl;
    if (memoryPhotos?.coverUrl && isUserCustomCover(memoryPhotos.coverUrl)) return memoryPhotos.coverUrl;
    return (
      coverUrl ||
      activeVolunteer?.coverUrl ||
      'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=1200&auto=format&fit=crop&q=80'
    );
  }, [isOwnProfile, coverUrl, activeVolunteer?.coverUrl, currentUser?.coverUrl, memoryPhotos]);

  return (
    <div className="space-y-6 animate-fadeIn pb-6 max-w-4xl mx-auto">
      {/* Viewing Other Volunteer Profile Notice */}
      {viewingVolunteer && (!currentUser || viewingVolunteer.id !== currentUser.id) && (
        <div className="bg-[#07531d] border-2 border-yellow-400 rounded-3xl p-4 text-white flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
            <img
              src={effectiveAvatar}
              onError={(e) => {
                const fallback = getCartoonYellowAvatar(activeVolunteer.gender, activeVolunteer.fullName);
                if (e.currentTarget.src !== fallback) e.currentTarget.src = fallback;
              }}
              alt={activeVolunteer.fullName}
              className="w-11 h-11 rounded-2xl border-2 border-yellow-400 object-cover shrink-0"
            />
            <div>
              <span className="text-[10px] font-army italic font-bold text-yellow-300 uppercase tracking-widest block">
                {language === 'bn' ? 'ভলান্টিয়ার প্রোফাইল পরিদর্শন' : 'VOLUNTEER DOSSIER VIEW'}
              </span>
              <h3 className="font-army font-black text-sm uppercase text-white">
                {activeVolunteer.fullName} ({activeVolunteer.volunteerIdCode || 'VOLUNTEER'})
              </h3>
            </div>
          </div>
          <button
            onClick={() => setViewingVolunteer(null)}
            className="bg-yellow-400 hover:bg-yellow-500 text-slate-950 font-army font-black text-xs px-4 py-2 rounded-full uppercase tracking-wider transition cursor-pointer shadow-sm"
          >
            {language === 'bn' ? 'আমার প্রোফাইল' : 'My Profile'}
          </button>
        </div>
      )}
      {/* Role Change Pending Approval Notice */}
      {isOwnProfile && currentUser?.pendingRole && currentUser.roleInVBD !== currentUser.pendingRole && currentUser.roleInVBD !== 'Board Member' && (
        <div className="bg-amber-50 border-2 border-amber-300 text-amber-900 rounded-[28px] p-4 flex items-center justify-between gap-3 text-xs shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-200 text-amber-900 flex items-center justify-center shrink-0 text-lg font-black">
              ⏳
            </div>
            <div>
              <p className="font-army italic font-black uppercase tracking-wider text-amber-900 text-sm">
                Promotion Request Pending Admin Review
              </p>
              <p className="text-amber-800 font-medium">
                Your request to become a <span className="font-bold underline">{currentUser.pendingRole}</span> has been submitted to District Admins. Your active role remains <span className="font-bold">{currentUser.roleInVBD}</span> until approved.
              </p>
            </div>
          </div>
          <button
            onClick={dismissPendingPromotionNotice}
            title="Dismiss notice"
            className="px-3.5 py-1.5 bg-amber-200 hover:bg-amber-300 text-amber-950 font-army font-black text-[10px] rounded-xl transition shrink-0 cursor-pointer uppercase shadow-xs tracking-wider"
          >
            DISMISS
          </button>
        </div>
      )}

      {/* 1. HERO PROFILE IDENTITY SECTION (Matching IMG_1216) */}
      <div className="bg-white border-2 border-slate-200/80 rounded-[36px] sm:rounded-[42px] p-3 sm:p-4 shadow-md overflow-hidden relative space-y-4">
        {/* Cover Image Banner with Floating Circular Controls */}
        <div className="relative h-44 sm:h-56 w-full rounded-[28px] overflow-hidden bg-slate-200 shadow-inner">
          <img
            src={effectiveCover}
            alt="Profile Cover"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>

          {/* Floating Action Buttons Top Right (Settings & Camera) - Only on Own Profile */}
          {isOwnProfile && (
            <div className="absolute top-3 right-3 flex items-center gap-2">
              <button
                onClick={() => setShowSettingsModal(true)}
                title="Settings & Config"
                className="w-9 h-9 rounded-full bg-white/95 backdrop-blur-xs text-slate-700 shadow-md flex items-center justify-center hover:bg-white hover:scale-105 transition active:scale-95 cursor-pointer"
              >
                <Settings className="w-4 h-4 text-slate-800" />
              </button>

              <input
                type="file"
                ref={coverInputRef}
                accept="image/*"
                onChange={handleCoverUpload}
                className="hidden"
              />
              <button
                onClick={() => coverInputRef.current?.click()}
                title="Change Cover Banner"
                className="w-9 h-9 rounded-full bg-white/95 backdrop-blur-xs text-slate-700 shadow-md flex items-center justify-center hover:bg-white hover:scale-105 transition active:scale-95 cursor-pointer"
              >
                <Camera className="w-4 h-4 text-slate-800" />
              </button>
            </div>
          )}
        </div>

        {/* Profile Avatar & Center Info Card */}
        <div className="flex flex-col items-center text-center -mt-16 sm:-mt-20 relative z-10 space-y-3 pb-3">
          {/* Main Avatar with Thick Yellow/Gold Ring & Dynamic Verified Badge */}
          <div className="relative group inline-block">
            <img
              src={effectiveAvatar}
              onError={(e) => {
                const fallback = getCartoonYellowAvatar(activeVolunteer.gender, activeVolunteer.fullName);
                if (e.currentTarget.src !== fallback) e.currentTarget.src = fallback;
              }}
              alt={activeVolunteer.fullName}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-full sm:rounded-[36px] object-cover border-4 border-yellow-400 shadow-2xl bg-white"
            />

            {/* Direct Avatar Change Button Overlay - Only on Own Profile */}
            {isOwnProfile && (
              <>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute top-1 right-1 bg-slate-900/80 hover:bg-slate-950 text-white p-1.5 rounded-full border border-white shadow-md transition cursor-pointer"
                  title="Update Profile Picture"
                >
                  <Camera className="w-3 h-3" />
                </button>
              </>
            )}

            {/* Dynamic Role Badge (Yellow: Committee, Green: Board, Black: Alumni - No Checkmarks) */}
            {renderAvatarRoleBadge()}
          </div>

          {/* Name */}
          <div className="flex items-center justify-center">
            <h1 className="font-army italic font-black text-3xl sm:text-4xl text-[#0b5c15] tracking-wider uppercase">
              {activeVolunteer.fullName || 'VOLUNTEER'}
            </h1>
          </div>

          {/* Role Badge with Verified Styling */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            <span className={`${getRolePillClasses(activeVolunteer.roleInVBD, activeVolunteer.boardType)} font-army italic font-black text-xs sm:text-sm px-6 py-1.5 rounded-full uppercase tracking-widest inline-block`}>
              {activeVolunteer.roleInVBD === 'Board Member'
                ? activeVolunteer.boardType === 'District Board'
                  ? 'DISTRICT BOARD'
                  : 'UPAZILA BOARD'
                : (activeVolunteer.roleInVBD || 'GENERAL MEMBER')}
            </span>
          </div>

          {/* Location Line */}
          <div className="flex items-center justify-center gap-1.5 text-slate-700 font-army italic font-black text-xs sm:text-sm tracking-wider uppercase">
            <MapPin className="w-4 h-4 text-emerald-700 fill-emerald-700" />
            <span>{activeVolunteer.upazila || 'MYMENSINGH SADAR'}</span>
          </div>

          {/* Action Button: Edit Profile (For Own Profile or Admin) */}
          {canEdit && (
            <div className="pt-1 flex items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={openEditModal}
                className="flex items-center gap-2 bg-[#053712] hover:bg-[#07471b] text-yellow-400 font-army italic font-black px-5 py-2.5 rounded-full text-xs shadow-md hover:shadow-lg transition cursor-pointer active:scale-95 border border-emerald-600"
              >
                <Edit3 className="w-4 h-4 text-yellow-400" />
                <span>
                  {isOwnProfile
                    ? (language === 'bn' ? 'প্রোফাইল এডিট করুন' : 'EDIT MY PROFILE')
                    : (language === 'bn' ? 'অ্যাডমিন: তথ্য পরিবর্তন' : 'ADMIN: EDIT PROFILE')}
                </span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* 2. PERSONAL INFORMATION CARD (Enhanced & Distinctive) */}
      <div className="bg-white rounded-[32px] sm:rounded-[36px] p-5 sm:p-7 shadow-lg border-2 border-emerald-600/30 relative overflow-hidden space-y-5">
        {/* Subtle Decorative Accent */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none"></div>

        {/* Section Header with Left Vertical Green Accent Bar & Confidential Pill */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-2 h-7 rounded-full bg-gradient-to-b from-[#0c7028] to-[#065018]"></div>
            <div>
              <h3 className="font-army italic font-black text-lg sm:text-xl text-slate-900 tracking-wider uppercase">
                PERSONAL INFORMATION
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                Verified District Volunteer Credentials
              </p>
            </div>
          </div>
          <span className="text-[10px] font-army italic font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100/80 px-3.5 py-1.5 rounded-full border border-emerald-300 shadow-2xs">
            CREDENTIALS
          </span>
        </div>

        {/* Modern 2-Column Responsive Information Grid (Double Sided on Phone & PC) */}
        <div className="grid grid-cols-2 gap-2 sm:gap-3.5 relative z-10">
          {/* Blood Group */}
          <div className="bg-gradient-to-br from-rose-50/90 to-red-50/50 border-2 border-rose-300/80 rounded-2xl p-2.5 sm:p-4 flex items-center justify-between shadow-2xs hover:border-rose-400 transition">
            <div className="flex items-center gap-2 sm:gap-3.5 min-w-0">
              <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-rose-500 text-white flex items-center justify-center shadow-md shrink-0">
                <Droplet className="w-4 h-4 sm:w-6 sm:h-6 fill-white" />
              </div>
              <div className="min-w-0">
                <p className="text-[9px] sm:text-[10px] font-army italic font-black tracking-wider uppercase text-rose-800 truncate">
                  BLOOD GROUP
                </p>
                <p className="font-army italic font-black text-rose-600 text-lg sm:text-2xl leading-tight">
                  {activeVolunteer.bloodGroup || 'B+'}
                </p>
              </div>
            </div>
            <span className="hidden sm:inline-block text-[10px] font-black uppercase px-2.5 py-1 rounded-full bg-rose-200 text-rose-900 border border-rose-300 font-army">
              {activeVolunteer.isBloodDonor === false ? 'NON-DONOR' : 'DONOR'}
            </span>
          </div>

          {/* Last Time Blood Donated */}
          <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-2.5 sm:p-4 flex items-center justify-between shadow-2xs hover:border-slate-300 transition">
            <div className="flex items-center gap-2 sm:gap-3.5 min-w-0">
              <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center shadow-xs shrink-0">
                <Droplet className="w-4 h-4 sm:w-6 sm:h-6" />
              </div>
              <div className="min-w-0">
                <p className="text-[9px] sm:text-[10px] font-army italic font-black tracking-wider uppercase text-slate-500 truncate">
                  LAST DONATION
                </p>
                <p className="font-army italic font-black text-slate-900 text-xs sm:text-base truncate">
                  {activeVolunteer.lastBloodDonationDate || 'Not recorded'}
                </p>
                <p className="text-[9px] sm:text-[10px] text-slate-500 truncate font-medium">
                  {donationEligibility.detail}
                </p>
              </div>
            </div>
            <span
              className={`text-[9px] sm:text-[10px] font-black font-army uppercase px-1.5 sm:px-2.5 py-0.5 sm:py-1 rounded-full shrink-0 border ${
                donationEligibility.eligible
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-300 shadow-2xs'
                  : 'bg-amber-100 text-amber-900 border-amber-300'
              }`}
            >
              {donationEligibility.eligible ? 'READY' : 'WAIT'}
            </span>
          </div>

          {/* Upazila / Zone */}
          <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-2.5 sm:p-4 flex items-center gap-2 sm:gap-3.5 shadow-2xs hover:border-slate-300 transition">
            <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center shadow-xs shrink-0">
              <MapPin className="w-4 h-4 sm:w-6 sm:h-6" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[9px] sm:text-[10px] font-army italic font-black tracking-wider uppercase text-slate-500 truncate">
                UPAZILA / SECTOR
              </p>
              <p className="font-army italic font-black text-slate-900 text-xs sm:text-base uppercase truncate">
                {activeVolunteer.upazila || 'MYMENSINGH SADAR'}
              </p>
              <p className="text-[8px] sm:text-[10px] text-emerald-700 font-bold uppercase font-army truncate">
                Mymensingh District
              </p>
            </div>
          </div>

          {/* Contact Number with Call Trigger */}
          <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-2.5 sm:p-4 flex items-center justify-between shadow-2xs hover:border-slate-300 transition">
            <div className="flex items-center gap-2 sm:gap-3.5 min-w-0">
              <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center shadow-xs shrink-0">
                <Phone className="w-4 h-4 sm:w-6 sm:h-6" />
              </div>
              <div className="min-w-0">
                <p className="text-[9px] sm:text-[10px] font-army italic font-black tracking-wider uppercase text-slate-500 truncate">
                  CONTACT
                </p>
                <p className="font-army italic font-black text-slate-900 text-xs sm:text-base truncate">
                  {activeVolunteer.mobileNo || '01736813344'}
                </p>
              </div>
            </div>
            {activeVolunteer.mobileNo && (
              <a
                href={`tel:${activeVolunteer.mobileNo}`}
                className="px-2 sm:px-3 py-1 sm:py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-army italic font-black text-[10px] sm:text-xs rounded-lg sm:rounded-xl shadow-xs transition flex items-center gap-1 shrink-0"
              >
                <Phone className="w-3 h-3 fill-white" />
                <span className="hidden sm:inline">CALL</span>
              </a>
            )}
          </div>

          {/* Date of Birth */}
          <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-2.5 sm:p-4 flex items-center gap-2 sm:gap-3.5 shadow-2xs hover:border-slate-300 transition">
            <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-blue-100 text-blue-800 flex items-center justify-center shadow-xs shrink-0">
              <Calendar className="w-4 h-4 sm:w-6 sm:h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-[9px] sm:text-[10px] font-army italic font-black tracking-wider uppercase text-slate-500 truncate">
                DATE OF BIRTH
              </p>
              <p className="font-army italic font-black text-slate-900 text-xs sm:text-base truncate">
                {activeVolunteer.dateOfBirth || 'Not set'} 🎂
              </p>
            </div>
          </div>

          {/* Gender */}
          <div className="bg-slate-50 border-2 border-slate-200 rounded-2xl p-2.5 sm:p-4 flex items-center gap-2 sm:gap-3.5 shadow-2xs hover:border-slate-300 transition">
            <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-purple-100 text-purple-800 flex items-center justify-center shadow-xs shrink-0">
              <User className="w-4 h-4 sm:w-6 sm:h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-[9px] sm:text-[10px] font-army italic font-black tracking-wider uppercase text-slate-500 truncate">
                GENDER
              </p>
              <p className="font-army italic font-black text-slate-900 text-xs sm:text-base uppercase truncate">
                {activeVolunteer.gender || 'MALE'}
              </p>
            </div>
          </div>

          {/* Official Email - Spanning both columns */}
          <div className="col-span-2 bg-slate-50 border-2 border-slate-200 rounded-2xl p-2.5 sm:p-4 flex items-center justify-between shadow-2xs hover:border-slate-300 transition">
            <div className="flex items-center gap-2 sm:gap-3.5 min-w-0">
              <div className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-teal-100 text-teal-800 flex items-center justify-center shadow-xs shrink-0">
                <Mail className="w-4 h-4 sm:w-6 sm:h-6" />
              </div>
              <div className="min-w-0">
                <p className="text-[9px] sm:text-[10px] font-army italic font-black tracking-wider uppercase text-slate-500 truncate">
                  OFFICIAL EMAIL ADDRESS
                </p>
                <p className="font-army italic font-bold text-slate-900 text-xs sm:text-sm truncate">
                  {activeVolunteer.email || 'volunteer@yellownetwork.org'}
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                if (activeVolunteer.email) {
                  navigator.clipboard.writeText(activeVolunteer.email);
                  setIsCopied(true);
                  setTimeout(() => setIsCopied(false), 2000);
                }
              }}
              className="px-2.5 sm:px-3 py-1 sm:py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-army italic font-black text-[10px] sm:text-xs rounded-lg sm:rounded-xl transition shrink-0 cursor-pointer"
            >
              {isCopied ? 'COPIED!' : 'COPY'}
            </button>
          </div>
        </div>

        {/* Actions on Personal Information Card */}
        <div className="pt-2 flex flex-wrap items-center justify-end gap-2.5">
          {canEdit && (
            <button
              type="button"
              onClick={openEditModal}
              className="flex items-center gap-1.5 px-4 py-2 bg-[#07531d] hover:bg-[#0a6625] text-yellow-400 font-army italic font-black text-xs rounded-xl uppercase tracking-wider transition cursor-pointer shadow-xs active:scale-95"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>
                {isOwnProfile
                  ? (language === 'bn' ? 'আমার প্রোফাইল এডিট' : 'EDIT MY PROFILE')
                  : (language === 'bn' ? 'অ্যাডমিন: তথ্য পরিবর্তন' : 'ADMIN: EDIT DOSSIER')}
              </span>
            </button>
          )}
        </div>
      </div>

      {/* ADMIN VALOR CONTROLS (Only visible to District Admins) */}
      {isAdmin && activeVolunteer && (
        <div className="bg-emerald-50/90 border-2 border-emerald-600/40 rounded-[32px] p-5 sm:p-6 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-800" />
              <h4 className="font-army font-black text-xs sm:text-sm text-emerald-950 uppercase tracking-wide">
                {language === 'bn' ? 'অ্যাডমিন স্কোর ও পয়েন্ট নিয়ন্ত্রণ' : 'ADMIN VALOR & POINT CONTROLS'}
              </h4>
            </div>
            <button
              type="button"
              onClick={() => setShowAdminPointsForm(!showAdminPointsForm)}
              className="px-3 py-1 bg-[#053712] hover:bg-[#07471b] text-yellow-400 font-army font-black text-[11px] rounded-xl transition cursor-pointer shadow-xs"
            >
              {showAdminPointsForm ? (language === 'bn' ? 'বন্ধ করুন' : 'CLOSE') : (language === 'bn' ? 'পয়েন্ট যোগ/কর্তন' : 'ADJUST POINTS')}
            </button>
          </div>

          {showAdminPointsForm && (
            <div className="bg-white border border-emerald-200 rounded-2xl p-4 space-y-3 text-xs animate-fadeIn">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsDeduct(false)}
                  className={`flex-1 py-1.5 rounded-xl font-army font-black uppercase text-xs transition cursor-pointer ${
                    !isDeduct ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  + Award Points
                </button>
                <button
                  type="button"
                  onClick={() => setIsDeduct(true)}
                  className={`flex-1 py-1.5 rounded-xl font-army font-black uppercase text-xs transition cursor-pointer ${
                    isDeduct ? 'bg-rose-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  - Deduct Points
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block font-bold text-slate-600 uppercase text-[10px] mb-1">
                    XP Points ({isDeduct ? '-' : '+'})
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={xpDelta}
                    onChange={(e) => setXpDelta(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-600 uppercase text-[10px] mb-1">
                    DHP Points ({isDeduct ? '-' : '+'})
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={dhpDelta}
                    onChange={(e) => setDhpDelta(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-600 uppercase text-[10px] mb-1">
                  Reason for Adjustment
                </label>
                <input
                  type="text"
                  value={pointReason}
                  onChange={(e) => setPointReason(e.target.value)}
                  placeholder="e.g., Outstanding Field Leadership"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 font-medium"
                />
              </div>

              <button
                type="button"
                disabled={isSubmittingPoints}
                onClick={async () => {
                  if (!awardOrDeductPoints || !activeVolunteer) return;
                  setIsSubmittingPoints(true);
                  const finalXp = isDeduct ? -Math.abs(xpDelta) : Math.abs(xpDelta);
                  const finalDhp = isDeduct ? -Math.abs(dhpDelta) : Math.abs(dhpDelta);
                  await awardOrDeductPoints(
                    activeVolunteer.id,
                    finalXp,
                    finalDhp,
                    pointReason.trim() || 'Admin manual point adjustment'
                  );
                  setIsSubmittingPoints(false);
                  setShowAdminPointsForm(false);
                }}
                className="w-full py-2 bg-[#053712] hover:bg-[#07471b] text-yellow-400 font-army font-black rounded-xl uppercase tracking-wider transition cursor-pointer shadow-xs"
              >
                {isSubmittingPoints ? 'Processing...' : (isDeduct ? 'Deduct Points' : 'Award Points')}
              </button>
            </div>
          )}
        </div>
      )}

      {/* 4. DISTRICT HEROES POINT (DHP) CARD (Enhanced Dark Valor League Theme) - Never for Alumni */}
      {!isAlumni && (
        <div className="bg-gradient-to-b from-zinc-900 via-zinc-950 to-black border-2 border-yellow-500/60 rounded-[32px] sm:rounded-[36px] p-6 sm:p-8 shadow-2xl text-center space-y-5 text-white relative overflow-hidden">
          {/* Glow Accent */}
          <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-72 h-40 bg-yellow-500/10 blur-3xl pointer-events-none rounded-full"></div>

          {/* Yellow Header Pill */}
          <div className="flex flex-col items-center gap-1">
            <div className="inline-flex items-center gap-2 bg-yellow-400 text-slate-950 font-army italic font-black text-xs sm:text-sm px-6 py-2 rounded-full uppercase tracking-widest shadow-lg border border-yellow-300">
              <Trophy className="w-4 h-4 fill-slate-950" />
              <span>DISTRICT HEROES POINT (DHP) • {countdown.seasonName.toUpperCase()}</span>
            </div>
          </div>

          {/* Live 6-Month Countdown Clock */}
          <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-4 space-y-2">
            <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-yellow-400/90 font-black flex items-center justify-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-yellow-400" />
              <span>SEASON COUNTDOWN TIMER</span>
            </div>

            <div className="flex items-center justify-center gap-2 sm:gap-4 text-center">
              <div className="bg-black/80 border border-zinc-800 rounded-2xl px-3 py-2 min-w-[54px] sm:min-w-[64px]">
                <div className="text-2xl sm:text-3xl font-black font-mono text-yellow-300 leading-none">
                  {countdown.days}
                </div>
                <div className="text-[9px] uppercase tracking-wider text-zinc-400 font-bold mt-1">
                  Days
                </div>
              </div>
              <span className="text-yellow-400 font-mono font-bold text-xl">:</span>
              <div className="bg-black/80 border border-zinc-800 rounded-2xl px-3 py-2 min-w-[54px] sm:min-w-[64px]">
                <div className="text-2xl sm:text-3xl font-black font-mono text-yellow-300 leading-none">
                  {String(countdown.hours).padStart(2, '0')}
                </div>
                <div className="text-[9px] uppercase tracking-wider text-zinc-400 font-bold mt-1">
                  Hours
                </div>
              </div>
              <span className="text-yellow-400 font-mono font-bold text-xl">:</span>
              <div className="bg-black/80 border border-zinc-800 rounded-2xl px-3 py-2 min-w-[54px] sm:min-w-[64px]">
                <div className="text-2xl sm:text-3xl font-black font-mono text-yellow-300 leading-none">
                  {String(countdown.minutes).padStart(2, '0')}
                </div>
                <div className="text-[9px] uppercase tracking-wider text-zinc-400 font-bold mt-1">
                  Mins
                </div>
              </div>
              <span className="text-yellow-400 font-mono font-bold text-xl">:</span>
              <div className="bg-black/80 border border-zinc-800 rounded-2xl px-3 py-2 min-w-[54px] sm:min-w-[64px]">
                <div className="text-2xl sm:text-3xl font-black font-mono text-yellow-300 leading-none">
                  {String(countdown.seconds).padStart(2, '0')}
                </div>
                <div className="text-[9px] uppercase tracking-wider text-zinc-400 font-bold mt-1">
                  Secs
                </div>
              </div>
            </div>

            <p className="text-[10px] font-mono font-bold tracking-[0.15em] text-zinc-400 uppercase pt-1">
              AUTOMATIC RESTART ON {countdown.nextResetDateStr} (NEW SEASON BEGINS)
            </p>
          </div>

          {/* Inner Dark Container with Points */}
          <div className="bg-gradient-to-b from-zinc-900 to-black border-2 border-yellow-500/40 rounded-3xl p-5 sm:p-6 flex flex-col items-center justify-center shadow-inner space-y-1 relative">
            <span className="text-[10px] sm:text-xs font-mono tracking-widest text-zinc-400 uppercase font-bold flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5 text-yellow-400" />
              <span>ACCUMULATED DHP VALOR POINTS</span>
            </span>
            <span className="text-5xl sm:text-7xl font-army italic font-black text-yellow-400 tracking-tight leading-none my-1 drop-shadow-[0_2px_12px_rgba(250,204,21,0.3)]">
              {dhpPoints}
            </span>
            <span className="text-xs font-army italic font-black text-amber-300 tracking-widest uppercase">
              ACTIVE SEASON COMBAT SCORE
            </span>
          </div>

          {/* DHP Season Matrix */}
          <div className="space-y-2 pt-1 border-t border-zinc-800 text-[10px] text-zinc-400">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-army italic font-black text-[10px]">
              <div className="bg-zinc-900 border border-amber-500/40 p-2 rounded-xl text-yellow-300">
                👑 LEADER: +125 DHP
              </div>
              <div className="bg-zinc-900 border border-blue-500/40 p-2 rounded-xl text-blue-300">
                ⭐ CO-LEADER: +100 DHP
              </div>
              <div className="bg-zinc-900 border border-emerald-500/40 p-2 rounded-xl text-emerald-300">
                🎯 PARTICIPANT: +90 DHP
              </div>
              <div className="bg-zinc-900 border border-purple-500/40 p-2 rounded-xl text-purple-300">
                📢 MEETING: +50 DHP
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ALUMNI EXCLUSIVE: THE HALL OF IMMORTAL GUARDIANS • ALUMNI CHAPTER */}
      {isAlumni && (
        <div className="bg-gradient-to-br from-slate-950 via-zinc-900 to-black border-2 border-yellow-500/80 rounded-[32px] sm:rounded-[36px] p-6 sm:p-7 shadow-2xl text-white relative overflow-hidden space-y-4">
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-2 bg-yellow-400 text-slate-950 px-4 py-1.5 rounded-full text-xs font-army italic font-black uppercase tracking-wider shadow-md">
              <Crown className="w-4 h-4 fill-slate-950" />
              <span>THE HALL OF IMMORTAL GUARDIANS • ALUMNI CHAPTER</span>
            </div>
            <div className="w-10 h-10 rounded-full bg-black border-2 border-yellow-400 flex items-center justify-center font-army italic font-black text-sm text-yellow-400 shadow-sm shrink-0">
              AL
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-army italic font-black text-lg sm:text-xl text-yellow-300 uppercase tracking-wide">
              HONORARY VETERAN & FOUNDING PILLAR
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-medium">
              পথিকৃৎ অগ্রজ — নিঃস্বার্থ আত্মত্যাগ, নিষ্ঠা ও নিরলস মানবসেবায় যাঁদের অবদানে আজকের ময়মনসিংহ ইয়েলো আর্মি এক অনন্য উচ্চতায় পৌঁছেছে। তাঁদের এই অবদান চিরস্মরণীয়।
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2.5 pt-1 text-center">
            <div className="bg-zinc-900/90 border border-yellow-500/30 rounded-2xl p-2.5">
              <span className="text-[10px] text-zinc-400 uppercase font-mono block">Status</span>
              <span className="font-army italic font-black text-yellow-400 text-xs sm:text-sm">EMERITUS</span>
            </div>
            <div className="bg-zinc-900/90 border border-yellow-500/30 rounded-2xl p-2.5">
              <span className="text-[10px] text-zinc-400 uppercase font-mono block">Legacy Tier</span>
              <span className="font-army italic font-black text-yellow-400 text-xs sm:text-sm">IMMORTAL</span>
            </div>
            <div className="bg-zinc-900/90 border border-yellow-500/30 rounded-2xl p-2.5">
              <span className="text-[10px] text-zinc-400 uppercase font-mono block">Chapter</span>
              <span className="font-army italic font-black text-yellow-400 text-xs sm:text-sm">LEGENDS</span>
            </div>
          </div>
        </div>
      )}

      {/* 5. PROJECT PARTICIPATION SECTION (Matching IMG_1218 + Explicit Position Tags) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-1.5 h-6 rounded-full bg-[#0c7028]"></div>
            <h3 className="font-army italic font-black text-base sm:text-lg text-slate-900 tracking-wider uppercase">
              PROJECT PARTICIPATION
            </h3>
          </div>

          <span className="bg-slate-200 text-slate-800 font-army italic font-black text-[11px] px-3 py-1 rounded-full uppercase">
            {userProjects.length} MISSIONS
          </span>
        </div>

        {userProjects.length === 0 ? (
          <div className="bg-white rounded-[32px] border-2 border-dashed border-slate-200 p-8 text-center space-y-3">
            <p className="text-xs font-army italic font-black text-slate-500 uppercase tracking-wider">
              NO MISSIONS JOINED YET
            </p>
            <p className="text-xs text-slate-500 max-w-sm mx-auto font-medium">
              Explore ongoing and upcoming initiatives across the 13 upazilas of Mymensingh District on the Project Center tab.
            </p>
            <button
              onClick={() => setActiveTab('home')}
              className="bg-[#065018] hover:bg-[#086320] text-yellow-400 font-army italic font-black px-5 py-2.5 rounded-full text-xs shadow-md transition cursor-pointer"
            >
              EXPLORE MISSIONS NOW
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {userProjects.map((p) => {
              const isLeader =
                p.leader?.id === activeVolunteer.id ||
                (p.leader?.name && activeVolunteer.fullName && p.leader.name.toLowerCase().trim() === activeVolunteer.fullName.toLowerCase().trim());
              const isCoLeader =
                p.coLeader?.id === activeVolunteer.id ||
                (p.coLeader?.name && activeVolunteer.fullName && p.coLeader.name.toLowerCase().trim() === activeVolunteer.fullName.toLowerCase().trim());

              const positionLabel = isLeader ? '👑 LEADER' : isCoLeader ? '⭐ CO-LEADER' : '🎯 PARTICIPANT';
              const positionClass = isLeader
                ? 'bg-amber-100 text-amber-950 border-amber-400 font-black'
                : isCoLeader
                ? 'bg-blue-100 text-blue-950 border-blue-400 font-black'
                : 'bg-emerald-50 text-emerald-900 border-emerald-300 font-bold';

              return (
                <div
                  key={p.id}
                  className="bg-white rounded-[28px] border-2 border-emerald-300/80 p-3.5 sm:p-4 shadow-sm flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 truncate">
                    <img
                      src={p.bannerUrl}
                      alt={p.title}
                      className="w-14 h-14 rounded-2xl object-cover shadow-2xs shrink-0"
                    />
                    <div className="truncate">
                      <h4 className="font-army italic font-black text-sm text-slate-900 truncate uppercase">
                        {p.title}
                      </h4>
                      <p className="text-[10px] font-army italic text-[#0c7028] uppercase font-bold">
                        📍 {p.upazilaScope} • {p.status}
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row items-end sm:items-center gap-1.5 shrink-0">
                    <span className="bg-emerald-100 text-emerald-800 font-army italic font-black text-[10px] px-2.5 py-1 rounded-full uppercase">
                      ENROLLED
                    </span>
                    <span className={`font-army italic text-[10px] px-2.5 py-1 rounded-full uppercase border shadow-2xs ${positionClass}`}>
                      {positionLabel}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Settings Modal */}
      {showSettingsModal && (
        <div
          onClick={() => setShowSettingsModal(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-white border-2 border-yellow-400 rounded-[36px] shadow-2xl p-6 text-slate-900 space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-emerald-700" />
                <h3 className="font-army italic font-black text-base uppercase text-slate-900">
                  APP SETTINGS & PREFERENCES
                </h3>
              </div>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Edit Profile Action */}
              <div className="p-3 bg-emerald-50/80 rounded-2xl border border-emerald-200 flex items-center justify-between">
                <div>
                  <h4 className="font-army italic font-black text-xs text-slate-900 uppercase">
                    PROFILE DETAILS
                  </h4>
                  <p className="text-[11px] text-slate-600 font-medium">
                    Edit personal info, phone, and volunteer sector
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowSettingsModal(false);
                    openEditModal();
                  }}
                  className="px-3.5 py-1.5 bg-[#065018] hover:bg-[#086320] text-yellow-400 font-army italic font-black text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>EDIT PROFILE</span>
                </button>
              </div>

              {/* Language Selector */}
              <div>
                <label className="block font-army italic font-bold text-slate-800 mb-2 uppercase flex items-center gap-1.5">
                  <Globe className="w-4 h-4 text-emerald-700" />
                  <span>Language Preference</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setLanguage('en')}
                    className={`p-3 rounded-2xl border text-center font-army italic font-black transition cursor-pointer ${
                      language === 'en'
                        ? 'bg-[#065018] text-yellow-400 border-emerald-700 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    ENGLISH (US/UK)
                  </button>
                  <button
                    type="button"
                    onClick={() => setLanguage('bn')}
                    className={`p-3 rounded-2xl border text-center font-army italic font-black transition cursor-pointer ${
                      language === 'bn'
                        ? 'bg-[#065018] text-yellow-400 border-emerald-700 shadow-xs'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    বাংলা (BANGLA)
                  </button>
                </div>
              </div>

              {/* Blood Donation & Eligibility */}
              <div className="pt-3 border-t border-slate-100 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block font-army italic font-bold text-slate-800 uppercase flex items-center gap-1.5">
                    <Droplet className="w-4 h-4 text-rose-600 fill-rose-600" />
                    <span>Blood Donation Record</span>
                  </label>
                  {!donationEligibility.eligible ? (
                    <span className="bg-rose-100 text-rose-800 border border-rose-300 px-2.5 py-0.5 rounded-full font-black text-[10px] uppercase">
                      Not ready for donate
                    </span>
                  ) : (
                    <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2.5 py-0.5 rounded-full font-bold text-[10px] uppercase">
                      Ready to donate
                    </span>
                  )}
                </div>

                <div className="space-y-1.5">
                  <label className="block text-[11px] text-slate-600 font-medium">
                    Last Blood Donation Date
                  </label>
                  <input
                    type="date"
                    value={lastBloodDonationDate}
                    onChange={(e) => {
                      const newDate = e.target.value;
                      setLastBloodDonationDate(newDate);
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-900 font-bold focus:border-emerald-600 focus:outline-none text-xs"
                  />
                  <p className="text-[10px] text-slate-500">
                    {donationEligibility.detail} (Safe rest window: 90 days / 3 months)
                  </p>
                </div>
              </div>

              {/* Account Actions */}
              <div className="pt-3 border-t border-slate-100 space-y-2">
                <label className="block font-army italic font-bold text-slate-800 uppercase">
                  Account Management
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowSettingsModal(false);
                      openAuthModal('login');
                    }}
                    className="p-3 rounded-2xl border border-slate-200 bg-slate-50 hover:bg-slate-100 font-army italic font-bold text-slate-800 flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <LogIn className="w-4 h-4 text-emerald-700" />
                    <span>SWITCH LOGIN</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowSettingsModal(false);
                      logout();
                    }}
                    className="p-3 rounded-2xl border border-rose-200 bg-rose-50 hover:bg-rose-100 font-army italic font-bold text-rose-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>SIGN OUT</span>
                  </button>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="button"
                  onClick={() => {
                    if (lastBloodDonationDate !== currentUser?.lastBloodDonationDate) {
                      updateProfile({ lastBloodDonationDate });
                    }
                    setShowSettingsModal(false);
                  }}
                  className="px-6 py-2.5 bg-[#065018] hover:bg-[#086320] text-yellow-400 font-army italic font-black rounded-full text-xs transition shadow-xs cursor-pointer"
                >
                  SAVE & CLOSE
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditing && (
        <div
          onClick={() => setIsEditing(false)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg bg-white border-2 border-yellow-400 rounded-[36px] shadow-2xl p-6 text-slate-900 max-h-[85vh] overflow-y-auto space-y-4"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-army italic font-black text-lg text-slate-900 uppercase">
                EDIT VOLUNTEER PROFILE
              </h3>
              <button
                onClick={() => setIsEditing(false)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-army italic font-bold text-slate-700 mb-1 uppercase">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-slate-900 font-bold focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-army italic font-bold text-slate-700 mb-1 uppercase">
                    Contact Number
                  </label>
                  <input
                    type="tel"
                    required
                    value={mobileNo}
                    onChange={(e) => setMobileNo(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-slate-900 font-bold focus:border-emerald-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-army italic font-bold text-slate-700 mb-1 uppercase">
                    Blood Group
                  </label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-slate-900 font-bold focus:border-emerald-600 focus:outline-none"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map((bg) => (
                      <option key={bg} value={bg}>
                        {bg}
                      </option>
                    ))}
                  </select>

                  {/* Blood Donor Toggle in Edit Form */}
                  <div className="mt-1.5 flex items-center justify-between bg-slate-100 p-2 rounded-xl">
                    <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
                      <Droplet className={`w-3.5 h-3.5 ${isBloodDonor ? 'fill-red-600 text-red-600' : 'text-slate-400'}`} />
                      <span>{isBloodDonor ? 'রক্তদাতা হিসেবে সম্মত (Donor)' : 'রক্তদাতা হিসেবে তালিকাভুক্ত নন'}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsBloodDonor(!isBloodDonor)}
                      className={`text-[10px] font-bold px-2.5 py-1 rounded-lg transition cursor-pointer ${
                        isBloodDonor
                          ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                          : 'bg-slate-300 hover:bg-slate-400 text-slate-800'
                      }`}
                    >
                      {isBloodDonor ? 'ব্লাড ব্যাংকে সক্রিয়' : 'অনিচ্ছুক (লুকানো)'}
                    </button>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-army italic font-bold text-slate-700 mb-1 uppercase">
                    Role in Yellow Army
                  </label>
                  <select
                    value={
                      roleInVBD === 'Board Member'
                        ? boardType === 'District Board'
                          ? 'District Board Member'
                          : 'Upazila Board Member'
                        : roleInVBD
                    }
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val === 'District Board Member') {
                        setRoleInVBD('Board Member');
                        setBoardType('District Board');
                      } else if (val === 'Upazila Board Member') {
                        setRoleInVBD('Board Member');
                        setBoardType('Upazila Board');
                      } else if (val === 'Board Member') {
                        setRoleInVBD('Board Member');
                        if (!boardType) setBoardType('District Board');
                      } else {
                        setRoleInVBD(val as VBDRole);
                      }
                    }}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-slate-900 font-bold focus:border-emerald-600 focus:outline-none"
                  >
                    <option value="General Member">General Member (সাধারণ সদস্য)</option>
                    <option value="Committee Member">Committee Member (কমিটি মেম্বার)</option>
                    <option value="District Board Member">District Board Member (জেলা বোর্ড মেম্বার)</option>
                    <option value="Upazila Board Member">Upazila Board Member (উপজেলা বোর্ড মেম্বার)</option>
                    <option value="Alumni">Alumni (অ্যালামনাই)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-army italic font-bold text-slate-700 mb-1 uppercase">
                    Sector / Upazila
                  </label>
                  <select
                    value={upazila}
                    onChange={(e) => setUpazila(e.target.value as UpazilaName)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-slate-900 font-bold focus:border-emerald-600 focus:outline-none"
                  >
                    {MYMENSINGH_UPAZILAS.map((upz) => (
                      <option key={upz} value={upz}>
                        {upz}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Board Member Specific Board Type Selection */}
                {roleInVBD === 'Board Member' && (
                  <div className="col-span-2 space-y-2 animate-fadeIn">
                    <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                      Board Category:
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      {/* Option 1: Upazila Board */}
                      <button
                        type="button"
                        onClick={() => setBoardType('Upazila Board')}
                        className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition shadow-xs active:scale-[0.98] ${
                          boardType === 'Upazila Board'
                            ? 'bg-yellow-400 text-slate-950 border-yellow-500 ring-2 ring-yellow-400 font-black'
                            : 'bg-white hover:bg-yellow-50/70 text-slate-700 border-slate-200 font-bold'
                        }`}
                      >
                        <span className="text-xs uppercase font-army">
                          Upazila Board
                        </span>
                        {boardType === 'Upazila Board' && (
                          <CheckCircle2 className="w-4 h-4 text-slate-950 shrink-0" />
                        )}
                      </button>

                      {/* Option 2: District Board */}
                      <button
                        type="button"
                        onClick={() => setBoardType('District Board')}
                        className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition shadow-xs active:scale-[0.98] ${
                          boardType === 'District Board'
                            ? 'bg-[#053712] text-white border-emerald-600 ring-2 ring-emerald-500 font-black'
                            : 'bg-white hover:bg-emerald-50/70 text-slate-700 border-slate-200 font-bold'
                        }`}
                      >
                        <span className="text-xs uppercase font-army">
                          District Board
                        </span>
                        {boardType === 'District Board' && (
                          <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                        )}
                      </button>
                    </div>

                    {/* Notice for Volunteers: Board Member requires Admin Review */}
                    {!isAdmin && (
                      <div className="bg-amber-50 border border-amber-300 rounded-2xl p-3 text-amber-900 text-xs space-y-1 mt-1">
                        <div className="flex items-center gap-1.5 font-army font-black uppercase text-amber-950">
                          <span>⚠️ {language === 'bn' ? 'অ্যাডমিন রিভিউ প্রয়োজন' : 'Admin Review Required'}</span>
                        </div>
                        <p className="text-[11px] leading-relaxed">
                          {language === 'bn'
                            ? 'বোর্ড মেম্বার (জেলা বা উপজেলা) পদবি নির্বাচনের জন্য জেলা অ্যাডমিনদের রিভিউ ও অনুমোদন প্রয়োজন। সংরক্ষণের পর আবেদনটি অ্যাডমিন রিভিউতে অপেক্ষমাণ থাকবে।'
                            : 'Selecting Board Member role requires District Admin Review & Approval before becoming active.'}
                        </p>
                      </div>
                    )}
                  </div>
                )}

                {/* Elevated Privileges Control for Admins */}
                {isAdmin && (
                  <div className="col-span-2 p-3 bg-emerald-50/80 border border-emerald-300 rounded-2xl space-y-1.5 mt-1">
                    <label className="block font-army italic font-bold text-[#053712] uppercase text-xs">
                      {language === 'bn' ? 'অ্যাডমিনিস্ট্রেটিভ রোল ও প্রিভিলেজ' : 'Administrative Privileges'}
                    </label>
                    <select
                      value={editAdminRole}
                      onChange={(e) => setEditAdminRole(e.target.value as any)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold focus:border-emerald-600 focus:outline-none"
                    >
                      <option value="General Member">General Volunteer (No Elevated Admin)</option>
                      <option value="District Coordinator">District Coordinator (HQ Admin)</option>
                      <option value="Super Admin">Super Admin (Full System Control)</option>
                    </select>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block font-army italic font-bold text-slate-700 uppercase">
                      Last Time Blood Donated
                    </label>
                    {lastBloodDonationDate && (
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                        !getDonationEligibility(lastBloodDonationDate).eligible
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      }`}>
                        {!getDonationEligibility(lastBloodDonationDate).eligible ? 'Not ready for donate' : 'Ready'}
                      </span>
                    )}
                  </div>
                  <input
                    type="date"
                    value={lastBloodDonationDate}
                    onChange={(e) => setLastBloodDonationDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-slate-900 font-bold focus:border-emerald-600 focus:outline-none"
                  />
                  {lastBloodDonationDate && (
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      {getDonationEligibility(lastBloodDonationDate).detail}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block font-army italic font-bold text-slate-700 mb-1 uppercase">
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-slate-900 font-bold focus:border-emerald-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-army italic font-bold text-slate-700 mb-1 uppercase">
                  Volunteer Bio
                </label>
                <textarea
                  rows={2}
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-3 text-slate-900 focus:border-emerald-600 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-5 py-2.5 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-full font-army italic font-bold transition cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#053712] hover:bg-[#07471b] text-yellow-400 font-army italic font-black rounded-full transition shadow-md cursor-pointer"
                >
                  SAVE CHANGES
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Board Member Type Selection Popup Modal */}
      {showBoardTypeModal && (
        <div
          onClick={() => setShowBoardTypeModal(false)}
          className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
          style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-200 relative animate-fadeIn space-y-4 text-center"
          >
            <button
              onClick={() => setShowBoardTypeModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100 cursor-pointer transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-black text-slate-900 font-army uppercase">
              Board Category:
            </h3>

            <div className="grid grid-cols-1 gap-2.5 pt-1 text-left">
              {/* Option 1: Upazila Board */}
              <button
                type="button"
                onClick={() => {
                  setBoardType('Upazila Board');
                  setShowBoardTypeModal(false);
                }}
                className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-center justify-between gap-3 shadow-xs ${
                  boardType === 'Upazila Board'
                    ? 'bg-yellow-400 text-slate-950 border-yellow-500 ring-2 ring-yellow-400 font-black'
                    : 'bg-white hover:bg-yellow-50 text-slate-800 border-slate-200 font-bold'
                }`}
              >
                <span className="font-army text-sm uppercase">Upazila Board</span>
                {boardType === 'Upazila Board' && (
                  <CheckCircle2 className="w-4 h-4 text-slate-950 shrink-0" />
                )}
              </button>

              {/* Option 2: District Board */}
              <button
                type="button"
                onClick={() => {
                  setBoardType('District Board');
                  setShowBoardTypeModal(false);
                }}
                className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-center justify-between gap-3 shadow-xs ${
                  boardType === 'District Board'
                    ? 'bg-[#053712] text-white border-emerald-600 ring-2 ring-emerald-500 font-black'
                    : 'bg-white hover:bg-emerald-50 text-slate-800 border-slate-200 font-bold'
                }`}
              >
                <span className="font-army text-sm uppercase">District Board</span>
                {boardType === 'District Board' && (
                  <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
