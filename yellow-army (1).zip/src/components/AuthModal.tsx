import React, { useState } from 'react';
import { useApp, isPermanentAdminEmail } from '../context/AppContext';
import {
  X,
  Lock,
  Mail,
  User,
  Phone,
  Calendar,
  Droplet,
  Users,
  MapPin,
  Sparkles,
  ShieldCheck,
  Shield,
  ArrowRight,
  CheckCircle2,
  Check,
  Eye,
  EyeOff,
  LogIn,
  UserPlus,
  BadgeCheck,
  Smartphone,
  IdCard,
} from 'lucide-react';
import {
  BloodGroup,
  Gender,
  VBDRole,
  BoardType,
  UpazilaName,
  MYMENSINGH_UPAZILAS,
  UPAZILA_BENGALI_NAMES,
} from '../types';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalMode,
    openAuthModal,
    loginWithEmail,
    loginAsVolunteer,
    signUpVolunteer,
    completeOnboarding,
    volunteers,
    language,
  } = useApp();

  // Login form state
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Sign up form state
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [mobileNo, setMobileNo] = useState('+88017');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);
  const [dateOfBirth, setDateOfBirth] = useState('2001-05-15');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('B+');
  const [isBloodDonor, setIsBloodDonor] = useState<boolean>(true);
  const [showBloodDonorModal, setShowBloodDonorModal] = useState<boolean>(false);
  const [gender, setGender] = useState<Gender>('Male');
  const [roleInVBD, setRoleInVBD] = useState<VBDRole>('General Member');
  const [boardType, setBoardType] = useState<BoardType>('Upazila Board');
  const [showBoardTypeModal, setShowBoardTypeModal] = useState(false);
  const [upazila, setUpazila] = useState<UpazilaName>('Mymensingh Sadar');
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isAuthModalOpen) return null;

  const bloodGroupOptions: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
  const genderOptions: Gender[] = ['Male', 'Female', 'Other'];
  const roleOptions: VBDRole[] = ['General Member', 'Committee Member', 'Board Member', 'Alumni'];

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!identifier.trim()) {
      setErrorMsg(
        language === 'bn'
          ? 'অনুগ্রহ করে আপনার ইমেইল, মোবাইল নম্বর অথবা ভলান্টিয়ার আইডি দিন'
          : 'Please provide your Email, Mobile number, or Volunteer ID'
      );
      return;
    }
    setIsLoading(true);
    const res = await loginWithEmail(identifier, password);
    setIsLoading(false);
    if (!res.success) {
      setErrorMsg(res.error || 'Login failed. Please check your credentials or register.');
    }
  };

  const handleSignUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!fullName.trim()) {
      setErrorMsg(language === 'bn' ? 'অনুগ্রহ করে আপনার পুরো নাম লিখুন' : 'Please provide your Full Name');
      return;
    }
    if (!email.trim() && !mobileNo.trim()) {
      setErrorMsg(
        language === 'bn'
          ? 'অনুগ্রহ করে একটি বৈধ ইমেইল বা মোবাইল নম্বর দিন'
          : 'Please provide an Email or Mobile Number'
      );
      return;
    }

    if (!signUpPassword || signUpPassword.length < 6) {
      setErrorMsg(
        language === 'bn'
          ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে'
          : 'Password must be at least 6 characters long'
      );
      return;
    }

    if (signUpPassword !== confirmPassword) {
      setErrorMsg(
        language === 'bn'
          ? 'পাসওয়ার্ড দুটি মিলছে না!'
          : 'Passwords do not match!'
      );
      return;
    }

    setIsLoading(true);
    const res = await signUpVolunteer({
      fullName,
      email: email.trim() || `vol_${Date.now()}@yellowarmy.org`,
      mobileNo: mobileNo.trim() || '+8801700000000',
      password: signUpPassword,
      dateOfBirth,
      bloodGroup,
      isBloodDonor,
      gender,
      roleInVBD,
      boardType: roleInVBD === 'Board Member' ? boardType : undefined,
      upazila,
      avatarUrl:
        gender === 'Female'
          ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    });
    setIsLoading(false);
    if (!res.success) {
      setErrorMsg(res.error || 'Failed to sign up');
    }
  };

  const handleOnboardingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    await completeOnboarding({
      fullName,
      email: email || 'volunteer.myn@gmail.com',
      mobileNo,
      dateOfBirth,
      bloodGroup,
      isBloodDonor,
      gender,
      roleInVBD,
      boardType: roleInVBD === 'Board Member' ? boardType : undefined,
      upazila,
    });
    setIsLoading(false);
  };

  // 4 Featured Quick Demo Accounts for regular volunteers only (Super Admin accounts excluded for security)
  const demoAccounts = volunteers
    .filter((v) => !isPermanentAdminEmail(v.email) && v.adminRole !== 'Super Admin')
    .slice(0, 4);

  return (
    <div
      onClick={closeAuthModal}
      className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
      style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg bg-white border border-slate-200 rounded-3xl shadow-2xl overflow-hidden text-slate-900 flex flex-col my-auto max-h-[92vh]"
      >
        {/* Header Ribbon */}
        <div className="bg-amber-400 p-4 text-slate-950 flex items-center justify-between border-b border-amber-500/30">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-slate-950 flex items-center justify-center text-amber-400 font-black text-xs shadow-sm">
              VBD
            </div>
            <div>
              <h2 className="font-extrabold text-base leading-tight text-slate-950 flex items-center gap-1.5">
                {authModalMode === 'login' && (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>{language === 'bn' ? 'সাইন ইন করুন: Yellow Network' : 'Sign in to Yellow Network'}</span>
                  </>
                )}
                {authModalMode === 'signup' && (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>{language === 'bn' ? 'নতুন ভলান্টিয়ার রেজিস্ট্রেশন' : 'Volunteer Registration'}</span>
                  </>
                )}
                {authModalMode === 'onboarding' && (
                  <>
                    <BadgeCheck className="w-4 h-4" />
                    <span>{language === 'bn' ? 'প্রোফাইল সম্পন্ন করুন' : 'Complete Volunteer Profile'}</span>
                  </>
                )}
              </h2>
              <p className="text-[10px] sm:text-[11px] text-slate-800 font-bold uppercase tracking-wider">
                A SPECIAL NETWORK FOR VBD - MYMENSINGH DISTRICT
              </p>
            </div>
          </div>
          <button
            onClick={closeAuthModal}
            className="p-1.5 rounded-full hover:bg-amber-500/40 text-slate-950 transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        {authModalMode !== 'onboarding' && (
          <div className="grid grid-cols-2 bg-slate-100/80 border-b border-slate-200 p-1.5 gap-1.5">
            <button
              onClick={() => {
                setErrorMsg('');
                openAuthModal('login');
              }}
              className={`py-2 px-3 text-xs font-black rounded-xl transition flex items-center justify-center gap-1.5 ${
                authModalMode === 'login'
                  ? 'bg-amber-400 text-slate-950 shadow-xs border border-amber-500/30'
                  : 'bg-white/60 text-slate-600 hover:text-slate-950 hover:bg-white'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'লগইন করুন (Sign In)' : 'Sign In / Login'}</span>
            </button>
            <button
              onClick={() => {
                setErrorMsg('');
                openAuthModal('signup');
              }}
              className={`py-2 px-3 text-xs font-black rounded-xl transition flex items-center justify-center gap-1.5 ${
                authModalMode === 'signup'
                  ? 'bg-amber-400 text-slate-950 shadow-xs border border-amber-500/30'
                  : 'bg-white/60 text-slate-600 hover:text-slate-950 hover:bg-white'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'নতুন রেজিস্ট্রেশন (Sign Up)' : 'Volunteer Sign Up'}</span>
            </button>
          </div>
        )}

        {/* Scrollable Form Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-xs font-semibold flex items-center gap-2 animate-fadeIn">
              <span className="w-2 h-2 rounded-full bg-rose-600 shrink-0"></span>
              <span>{errorMsg}</span>
            </div>
          )}

          {/* TAB 1: LOGIN MODE */}
          {authModalMode === 'login' && (
            <div className="space-y-4">
              {/* Login Form */}
              <form onSubmit={handleLoginSubmit} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn'
                      ? 'ইমেইল এড্রেস'
                      : 'Email Address'}
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. rahat@example.com"
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white focus:ring-2 focus:ring-amber-400/20 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-slate-900 placeholder-slate-400 transition"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      {language === 'bn' ? 'পাসওয়ার্ড' : 'Password'}
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        alert(
                          language === 'bn'
                            ? 'ডেমো অ্যাকাউন্টের জন্য যেকোনো পাসওয়ার্ড ব্যবহার করতে পারেন অথবা সরাসরি ডেমো প্রোফাইলে ক্লিক করুন।'
                            : 'For demo access, you can enter any password or use the 1-click accounts below.'
                        )
                      }
                      className="text-[11px] text-amber-600 hover:text-amber-700 font-bold"
                    >
                      {language === 'bn' ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot Password?'}
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white focus:ring-2 focus:ring-amber-400/20 rounded-xl pl-9 pr-10 py-2 text-xs sm:text-sm text-slate-900 placeholder-slate-400 transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-600 pt-1">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="rounded text-amber-500 focus:ring-amber-400"
                    />
                    <span>{language === 'bn' ? 'লগইন মনে রাখুন' : 'Remember me on this device'}</span>
                  </label>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-amber-400 hover:bg-amber-300 active:scale-[0.99] text-slate-950 font-black py-2.5 rounded-xl text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2 border border-amber-500/40"
                >
                  <LogIn className="w-4 h-4" />
                  <span>
                    {isLoading
                      ? language === 'bn' ? 'লগইন হচ্ছে...' : 'Signing in...'
                      : language === 'bn' ? 'নেটওয়ার্কে প্রবেশ করুন' : 'Sign In to Network'}
                  </span>
                </button>
              </form>

              {/* 1-Click Fast Demo Logins Section */}
              <div className="mt-4 pt-4 border-t border-slate-200/80">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-[11px] font-extrabold uppercase tracking-wider text-slate-600 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>{language === 'bn' ? '১-ক্লিকে ডেমো ভলান্টিয়ার লগইন' : '1-Click Fast Demo Logins'}</span>
                  </p>
                  <span className="text-[10px] text-slate-400 font-semibold">
                    {language === 'bn' ? 'ক্লিক করলেই লগইন' : 'Click to instant log in'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {demoAccounts.map((vol, idx) => (
                    <button
                      key={vol.id ? `${vol.id}-${idx}` : `demo-acc-${idx}`}
                      type="button"
                      onClick={() => loginAsVolunteer(vol.id)}
                      className="flex items-center gap-2.5 p-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-amber-50/80 hover:border-amber-300 text-left transition group"
                    >
                      <img
                        src={vol.avatarUrl}
                        alt={vol.fullName}
                        className="w-8 h-8 rounded-full object-cover border border-amber-400 shadow-2xs group-hover:scale-105 transition-transform"
                      />
                      <div className="overflow-hidden flex-1">
                        <p className="text-xs font-bold text-slate-900 truncate leading-tight group-hover:text-amber-950">
                          {vol.fullName}
                        </p>
                        <p className="text-[10px] text-amber-600 font-semibold truncate leading-none mt-0.5">
                          {vol.adminRole || vol.roleInVBD} • {vol.upazila}
                        </p>
                      </div>
                      <span className="text-[10px] bg-white group-hover:bg-amber-400 px-1.5 py-0.5 rounded font-bold text-slate-700 group-hover:text-slate-950 border border-slate-200 group-hover:border-amber-500/30 transition">
                        Login
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SIGN UP OR ONBOARDING MODE */}
          {(authModalMode === 'signup' || authModalMode === 'onboarding') && (
            <form onSubmit={authModalMode === 'signup' ? handleSignUpSubmit : handleOnboardingSubmit} className="space-y-3">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'পুরো নাম (Full Name)' : 'Full Name'} <span className="text-amber-600">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    placeholder="RI Rahat"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 transition"
                  />
                </div>
              </div>

              {/* Email & Mobile */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'ইমেইল এড্রেস' : 'Email Address'} <span className="text-amber-600">*</span>
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type="email"
                      required
                      placeholder="e.g. rahat@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'মোবাইল নম্বর' : 'Mobile Number'} <span className="text-amber-600">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type="tel"
                      required
                      placeholder="+88017XXXXXXXX"
                      value={mobileNo}
                      onChange={(e) => setMobileNo(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 placeholder-slate-400 transition"
                    />
                  </div>
                </div>
              </div>

              {/* Passwords for Signup */}
              {authModalMode === 'signup' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'পাসওয়ার্ড তৈরি করুন' : 'Create Password'} <span className="text-amber-600">*</span>
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                      <input
                        type={showSignUpPassword ? 'text' : 'password'}
                        required
                        minLength={6}
                        placeholder="Min. 6 chars"
                        value={signUpPassword}
                        onChange={(e) => setSignUpPassword(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-8 py-2 text-xs text-slate-900 transition"
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                        className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                      >
                        {showSignUpPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'কনফার্ম পাসওয়ার্ড' : 'Confirm Password'} <span className="text-amber-600">*</span>
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                      <input
                        type={showSignUpPassword ? 'text' : 'password'}
                        required
                        minLength={6}
                        placeholder="Re-enter password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 transition"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* DOB & Gender */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'জন্ম তারিখ (DOB)' : 'Date of Birth'} <span className="text-amber-600">*</span>
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                    <input
                      type="date"
                      required
                      value={dateOfBirth}
                      onChange={(e) => setDateOfBirth(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'লিঙ্গ (Gender)' : 'Gender'} <span className="text-amber-600">*</span>
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as Gender)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl px-3 py-2 text-xs text-slate-900 transition font-medium"
                  >
                    {genderOptions.map((g) => (
                      <option key={g} value={g} className="bg-white text-slate-900">
                        {g} {g === 'Male' ? '(পুরুষ)' : g === 'Female' ? '(মহিলা)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Blood Group & Role in VBD */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'রক্তের গ্রুপ (Blood Group)' : 'Blood Group'} <span className="text-amber-600">*</span>
                  </label>
                  <div className="relative">
                    <Droplet className="absolute left-3 top-2.5 w-4 h-4 text-rose-500" />
                    <select
                      value={bloodGroup}
                      onChange={(e) => {
                        const bg = e.target.value as BloodGroup;
                        setBloodGroup(bg);
                        setShowBloodDonorModal(true);
                      }}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 font-bold transition cursor-pointer"
                    >
                      {bloodGroupOptions.map((bg) => (
                        <option key={bg} value={bg} className="bg-white text-slate-900">
                          {bg}
                        </option>
                      ))}
                    </select>
                  </div>
                  {/* Blood Donor Status Pill & Manual Toggle */}
                  <button
                    type="button"
                    onClick={() => setShowBloodDonorModal(true)}
                    className={`mt-1.5 w-full flex items-center justify-between px-2.5 py-1 rounded-lg text-[10px] font-bold border transition cursor-pointer ${
                      isBloodDonor
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                        : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    <span className="flex items-center gap-1">
                      <Droplet className={`w-3 h-3 ${isBloodDonor ? 'fill-rose-500 text-rose-500' : 'text-slate-400'}`} />
                      <span>{isBloodDonor ? '🩸 ব্লাড ব্যাংকে তালিকাভুক্ত (Donor)' : '❌ ব্লাড ব্যাংকে অনিচ্ছুক'}</span>
                    </span>
                    <span className="text-[9px] underline text-slate-500">{language === 'bn' ? 'পরিবর্তন' : 'Change'}</span>
                  </button>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'ভিবিডি পদবি (Role)' : 'Role in VBD'} <span className="text-amber-600">*</span>
                  </label>
                  <div className="relative">
                    <Users className="absolute left-3 top-2.5 w-4 h-4 text-amber-600" />
                    <select
                      value={
                        roleInVBD === 'Board Member'
                          ? boardType === 'District Board'
                            ? 'District Board Member'
                            : 'Upazila Board Member'
                          : roleInVBD
                      }
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === 'District Board Member') {
                          setRoleInVBD('Board Member');
                          setBoardType('District Board');
                        } else if (val === 'Upazila Board Member') {
                          setRoleInVBD('Board Member');
                          setBoardType('Upazila Board');
                        } else if (val === 'Board Member') {
                          setRoleInVBD('Board Member');
                          if (!boardType) setBoardType('District Board');
                        } else {
                          setRoleInVBD(val as VBDRole);
                        }
                      }}
                      className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 font-medium transition"
                    >
                      <option value="General Member" className="bg-white text-slate-900">
                        General Member (সাধারণ সদস্য)
                      </option>
                      <option value="Committee Member" className="bg-white text-slate-900">
                        Committee Member (কমিটি সদস্য)
                      </option>
                      <option value="District Board Member" className="bg-white text-slate-900">
                        District Board Member (জেলা বোর্ড মেম্বার)
                      </option>
                      <option value="Upazila Board Member" className="bg-white text-slate-900">
                        Upazila Board Member (উপজেলা বোর্ড মেম্বার)
                      </option>
                      <option value="Alumni" className="bg-white text-slate-900">
                        Alumni (অ্যালামনাই)
                      </option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Board Member Specific Board Type Selection */}
              {roleInVBD === 'Board Member' && (
                <div className="space-y-1.5 animate-fadeIn">
                  <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                    Board Category:
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    {/* Option 1: Upazila Board */}
                    <button
                      type="button"
                      onClick={() => setBoardType('Upazila Board')}
                      className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition shadow-xs active:scale-[0.98] ${
                        boardType === 'Upazila Board'
                          ? 'bg-yellow-400 text-slate-950 border-yellow-500 ring-2 ring-yellow-400 font-black'
                          : 'bg-white hover:bg-yellow-50/70 text-slate-700 border-slate-200 font-bold'
                      }`}
                    >
                      <span className="text-xs uppercase font-army">
                        Upazila Board
                      </span>
                      {boardType === 'Upazila Board' && (
                        <CheckCircle2 className="w-4 h-4 text-slate-950 shrink-0" />
                      )}
                    </button>

                    {/* Option 2: District Board */}
                    <button
                      type="button"
                      onClick={() => setBoardType('District Board')}
                      className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition shadow-xs active:scale-[0.98] ${
                        boardType === 'District Board'
                          ? 'bg-[#053712] text-white border-emerald-600 ring-2 ring-emerald-500 font-black'
                          : 'bg-white hover:bg-emerald-50/70 text-slate-700 border-slate-200 font-bold'
                      }`}
                    >
                      <span className="text-xs uppercase font-army">
                        District Board
                      </span>
                      {boardType === 'District Board' && (
                        <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                      )}
                    </button>
                  </div>

                  <div className="bg-amber-50 border border-amber-300 rounded-2xl p-2.5 text-amber-900 text-xs space-y-0.5">
                    <div className="font-army font-black uppercase text-amber-950 flex items-center gap-1 text-[11px]">
                      <span>⚠️ {language === 'bn' ? 'অ্যাডমিন রিভিউ প্রয়োজন' : 'Admin Review Required'}</span>
                    </div>
                    <p className="text-[10px] leading-tight text-amber-900">
                      {language === 'bn'
                        ? 'বোর্ড মেম্বার পদবির জন্য জেলা অ্যাডমিনদের রিভিউ ও অনুমোদন প্রয়োজন হবে।'
                        : 'Selecting Board Member role requires District Admin Review & Approval before becoming active.'}
                    </p>
                  </div>
                </div>
              )}

              {/* Upazila Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'উপজেলা (ময়মনসিংহের ১৩টি উপজেলা)' : 'Upazila (13 Mymensingh Upazilas)'}{' '}
                  <span className="text-amber-600">*</span>
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-2.5 w-4 h-4 text-amber-600" />
                  <select
                    value={upazila}
                    onChange={(e) => setUpazila(e.target.value as UpazilaName)}
                    className="w-full bg-slate-50 border border-slate-200 focus:border-amber-500 focus:bg-white rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 font-semibold transition"
                  >
                    {MYMENSINGH_UPAZILAS.map((upz) => (
                      <option key={upz} value={upz} className="bg-white text-slate-900">
                        {language === 'bn' ? UPAZILA_BENGALI_NAMES[upz] : upz}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 bg-amber-400 hover:bg-amber-300 active:scale-[0.99] text-slate-950 font-black py-2.5 rounded-xl text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2 border border-amber-500/40"
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {language === 'bn'
                    ? 'রেজিস্ট্রেশন সম্পন্ন করে যুক্ত হন'
                    : 'Complete Registration & Join Yellow Network'}
                </span>
              </button>
            </form>
          )}

          {/* Developer Credit */}
          <div className="pt-2 text-center">
            <span className="inline-flex items-center gap-1.5 bg-yellow-100 text-yellow-900 border border-yellow-300 px-3 py-1 rounded-full text-[10px] font-army italic font-black uppercase tracking-wider">
              <ShieldCheck className="w-3 h-3 text-yellow-700" />
              <span>DEVELOPED BY RI</span>
            </span>
          </div>
        </div>
      </div>

      {/* Board Member Type Selection Popup Modal */}
      {showBoardTypeModal && (
        <div
          onClick={() => setShowBoardTypeModal(false)}
          className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
          style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-200 relative animate-fadeIn space-y-4 text-center"
          >
            <button
              onClick={() => setShowBoardTypeModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100 cursor-pointer transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-black text-slate-900 font-army uppercase">
              Board Category:
            </h3>

            <div className="grid grid-cols-1 gap-2.5 pt-1 text-left">
              {/* Option 1: Upazila Board */}
              <button
                type="button"
                onClick={() => {
                  setBoardType('Upazila Board');
                  setShowBoardTypeModal(false);
                }}
                className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-center justify-between gap-3 shadow-xs ${
                  boardType === 'Upazila Board'
                    ? 'bg-yellow-400 text-slate-950 border-yellow-500 ring-2 ring-yellow-400 font-black'
                    : 'bg-white hover:bg-yellow-50 text-slate-800 border-slate-200 font-bold'
                }`}
              >
                <span className="font-army text-sm uppercase">Upazila Board</span>
                {boardType === 'Upazila Board' && (
                  <CheckCircle2 className="w-4 h-4 text-slate-950 shrink-0" />
                )}
              </button>

              {/* Option 2: District Board */}
              <button
                type="button"
                onClick={() => {
                  setBoardType('District Board');
                  setShowBoardTypeModal(false);
                }}
                className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-center justify-between gap-3 shadow-xs ${
                  boardType === 'District Board'
                    ? 'bg-[#053712] text-white border-emerald-600 ring-2 ring-emerald-500 font-black'
                    : 'bg-white hover:bg-emerald-50 text-slate-800 border-slate-200 font-bold'
                }`}
              >
                <span className="font-army text-sm uppercase">District Board</span>
                {boardType === 'District Board' && (
                  <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                )}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* BLOOD DONOR CONSENT MODAL */}
      {showBloodDonorModal && (
        <div
          onClick={() => setShowBloodDonorModal(false)}
          className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white border-2 border-red-500 rounded-[32px] p-6 shadow-2xl text-center space-y-4 animate-scaleUp"
          >
            <div className="w-14 h-14 rounded-2xl bg-rose-100 text-red-600 flex items-center justify-center mx-auto shadow-sm border border-rose-200">
              <Droplet className="w-8 h-8 fill-red-600 text-red-600 animate-pulse" />
            </div>

            <div>
              <span className="text-[10px] font-army italic font-black uppercase text-rose-600 tracking-wider bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
                BLOOD GROUP {bloodGroup}
              </span>
              <h3 className="font-army italic font-black text-lg text-slate-900 uppercase mt-2">
                রক্তদান করতে ইচ্ছুক?
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                জরুরি প্রয়োজনে আপনি কি রক্তদান করতে ইচ্ছুক? সম্মতি দিলে আমাদের <strong>ব্লাড ব্যাংক</strong> ডিরেক্টরিতে আপনার তথ্য প্রদর্শিত হবে।
              </p>
            </div>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setIsBloodDonor(true);
                  setShowBloodDonorModal(false);
                }}
                className="w-full py-3 px-4 bg-[#053712] hover:bg-[#07471b] text-yellow-400 font-army italic font-black text-xs rounded-2xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer border border-emerald-600 active:scale-98 uppercase"
              >
                <Check className="w-4 h-4 text-yellow-400" />
                <span>হ্যাঁ, আমি রক্তদান করতে চাই (Yes, I'm a Donor)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsBloodDonor(false);
                  setShowBloodDonorModal(false);
                }}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-army italic font-bold text-xs rounded-2xl transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 uppercase"
              >
                <X className="w-3.5 h-3.5 text-slate-500" />
                <span>না, আপাতত ইচ্ছুক নই (No, Not Right Now)</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
