import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Lock,
  Mail,
  User,
  Phone,
  Calendar,
  Droplet,
  Users,
  MapPin,
  Sparkles,
  Eye,
  EyeOff,
  LogIn,
  UserPlus,
  Globe,
  Database,
  CheckCircle2,
  Check,
  Zap,
  Shield,
  ShieldCheck,
  X,
} from 'lucide-react';
import {
  BloodGroup,
  Gender,
  VBDRole,
  BoardType,
  UpazilaName,
  MYMENSINGH_UPAZILAS,
  UPAZILA_BENGALI_NAMES,
} from '../../types';

export const AuthGateway: React.FC = () => {
  const {
    loginWithEmail,
    signUpVolunteer,
    language,
    setLanguage,
    isFirebaseSynced,
  } = useApp();

  const [mode, setMode] = useState<'login' | 'signup'>('login');

  // Login form state
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Sign up form state
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [mobileNo, setMobileNo] = useState('+88017');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);
  const [dateOfBirth, setDateOfBirth] = useState('2001-05-15');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('B+');
  const [isBloodDonor, setIsBloodDonor] = useState<boolean>(true);
  const [showBloodDonorModal, setShowBloodDonorModal] = useState<boolean>(false);
  const [gender, setGender] = useState<Gender>('Male');
  const [roleInVBD, setRoleInVBD] = useState<VBDRole>('General Member');
  const [boardType, setBoardType] = useState<BoardType>('Upazila Board');
  const [showBoardTypeModal, setShowBoardTypeModal] = useState(false);
  const [upazila, setUpazila] = useState<UpazilaName>('Mymensingh Sadar');

  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const bloodGroupOptions: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];
  const genderOptions: Gender[] = ['Male', 'Female', 'Other'];
  // Role options now includes Alumni
  const roleOptions: VBDRole[] = ['General Member', 'Committee Member', 'Board Member', 'Alumni'];

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!identifier.trim()) {
      setErrorMsg(
        language === 'bn'
          ? 'অনুগ্রহ করে আপনার ইমেইল এড্রেস লিখুন'
          : 'Please provide your Email Address'
      );
      return;
    }
    setIsLoading(true);
    const res = await loginWithEmail(identifier, password);
    setIsLoading(false);
    if (!res.success) {
      setErrorMsg(res.error || 'Login failed. Please check credentials or register.');
    }
  };

  const handleSignUpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!fullName.trim()) {
      setErrorMsg(language === 'bn' ? 'অনুগ্রহ করে আপনার পুরো নাম লিখুন' : 'Please provide your Full Name');
      return;
    }

    if (!email.trim() && !mobileNo.trim()) {
      setErrorMsg(
        language === 'bn'
          ? 'অনুগ্রহ করে একটি বৈধ ইমেইল বা মোবাইল নম্বর দিন'
          : 'Please provide an Email or Mobile Number'
      );
      return;
    }

    if (!signUpPassword || signUpPassword.length < 6) {
      setErrorMsg(
        language === 'bn'
          ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে'
          : 'Password must be at least 6 characters long'
      );
      return;
    }

    if (signUpPassword !== confirmPassword) {
      setErrorMsg(
        language === 'bn'
          ? 'পাসওয়ার্ড দুটি মিলছে না! অনুগ্রহ করে পুনরায় চেক করুন।'
          : 'Passwords do not match! Please recheck.'
      );
      return;
    }

    setIsLoading(true);
    const res = await signUpVolunteer({
      fullName,
      email: email.trim() || `vol_${Date.now()}@yellownetwork.org`,
      mobileNo: mobileNo.trim() || '+8801700000000',
      password: signUpPassword,
      dateOfBirth,
      bloodGroup,
      isBloodDonor,
      gender,
      roleInVBD,
      boardType: roleInVBD === 'Board Member' ? boardType : undefined,
      upazila,
      avatarUrl:
        gender === 'Female'
          ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    });
    setIsLoading(false);
    if (!res.success) {
      setErrorMsg(res.error || 'Failed to sign up');
    }
  };

  return (
    <div className="min-h-screen bg-[#f3f9f4] text-slate-900 flex flex-col justify-between selection:bg-emerald-600 selection:text-white font-sans p-3 sm:p-6 relative overflow-x-hidden">
      {/* Subtle Background Accent Blurs */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-200/40 rounded-full blur-3xl pointer-events-none -z-10"></div>
      <div className="absolute bottom-10 right-10 w-80 h-80 bg-yellow-200/30 rounded-full blur-3xl pointer-events-none -z-10"></div>

      {/* Top Header Bar */}
      <header className="max-w-xl w-full mx-auto flex items-center justify-between py-2">
        {/* Version Pill */}
        <div className="inline-flex items-center gap-1.5 bg-emerald-100/90 border border-emerald-300 text-[#07531d] px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-2xs">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
          <span>Trail Version</span>
        </div>

        {/* Language switch */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
            className="flex items-center gap-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 px-3 py-1 rounded-xl text-xs font-bold transition shadow-2xs cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-emerald-600" />
            <span>{language === 'en' ? 'বাংলা' : 'English'}</span>
          </button>
        </div>
      </header>

      {/* Main Branding & Form Container */}
      <main className="max-w-xl w-full mx-auto my-3 animate-fadeIn space-y-4">
        {/* Brand Header: Matches Demo Image */}
        <div className="text-center space-y-2">
          {/* Logo Mark and Title */}
          <div className="flex items-center justify-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#07531d] text-yellow-400 flex items-center justify-center shadow-md border-2 border-emerald-500/40 shrink-0">
              <Zap className="w-6 h-6 fill-yellow-400 text-yellow-400" />
            </div>

            <div className="text-left">
              <div className="flex items-center gap-1.5">
                <span className="text-2xl sm:text-3xl font-black font-army tracking-wide text-[#097327] leading-none">
                  YELLOW
                </span>
                <span className="bg-[#07531d] text-white text-[10px] sm:text-[11px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-widest leading-none">
                  NETWORK
                </span>
              </div>
              <p className="text-[8px] sm:text-[9px] font-mono font-bold tracking-[0.25em] text-slate-500 uppercase mt-0.5">
                THE PULSE WITH PURPOSE
              </p>
            </div>
          </div>

          {/* District Tagline: Requested all capital, smaller font */}
          <div className="inline-flex items-center gap-1.5 bg-white/80 border border-emerald-200 px-3.5 py-1 rounded-full shadow-2xs">
            <span className="w-1.5 h-1.5 rounded-full bg-[#0c7028]"></span>
            <p className="text-[10px] sm:text-[11px] text-slate-700 font-army font-black tracking-wider uppercase">
              A SPECIAL NETWORK FOR VBD - MYMENSINGH DISTRICT
            </p>
          </div>
        </div>

        {/* Card Container with Clean Theme */}
        <div className="bg-[#eef8f1] text-slate-900 rounded-[32px] sm:rounded-[36px] shadow-lg border-2 border-emerald-200/90 overflow-hidden">
          {/* Mode Switcher Tabs: Smaller, proportional & centered */}
          <div className="flex justify-center p-2.5 bg-[#e3f2e7] border-b border-emerald-200/80">
            <div className="inline-flex p-1 bg-white/70 rounded-2xl border border-emerald-200/80 gap-1.5 max-w-xs w-full shadow-2xs">
              <button
                type="button"
                onClick={() => {
                  setErrorMsg('');
                  setMode('login');
                }}
                className={`flex-1 py-1.5 px-3 text-[11px] sm:text-xs font-army italic font-black rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider ${
                  mode === 'login'
                    ? 'bg-[#07531d] text-yellow-300 shadow-xs border border-emerald-700'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'লগইন' : 'Sign In / Login'}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setErrorMsg('');
                  setMode('signup');
                }}
                className={`flex-1 py-1.5 px-3 text-[11px] sm:text-xs font-army italic font-black rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider ${
                  mode === 'signup'
                    ? 'bg-[#07531d] text-yellow-300 shadow-xs border border-emerald-700'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'রেজিস্ট্রেশন' : 'Volunteer Sign Up'}</span>
              </button>
            </div>
          </div>

          <div className="p-5 sm:p-7">
            {/* Header Text inside Form */}
            <div className="mb-5 text-center">
              <h2 className="text-xl sm:text-2xl font-black font-army tracking-wide text-slate-900">
                {mode === 'login'
                  ? language === 'bn' ? 'সাইন ইন করুন: Yellow Network' : 'Sign in to Yellow Network'
                  : language === 'bn' ? 'নতুন ভলান্টিয়ার রেজিস্ট্রেশন' : 'Volunteer Sign Up'}
              </h2>
              <p className="text-[10px] sm:text-[11px] text-slate-600 font-army font-black uppercase tracking-wider mt-1">
                {mode === 'login'
                  ? 'A SPECIAL NETWORK FOR VBD - MYMENSINGH DISTRICT'
                  : 'Join the premier humanitarian network of Mymensingh'}
              </p>
            </div>

            {/* Error Message Box */}
            {errorMsg && (
              <div className="mb-4 p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2 animate-fadeIn">
                <span className="text-base">⚠️</span>
                <span>{errorMsg}</span>
              </div>
            )}

            {/* LOGIN FORM */}
            {mode === 'login' ? (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                {/* Email Address */}
                <div>
                  <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1.5 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-[#07531d]" />
                    <span>{language === 'bn' ? 'ইমেইল এড্রেস' : 'Email Address'}</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="e.g. rahat@example.com"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    className="w-full bg-white border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 rounded-2xl px-4 py-3 text-xs sm:text-sm text-slate-900 placeholder-slate-400 transition shadow-2xs font-medium"
                  />
                </div>

                {/* Password */}
                <div>
                  <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-[#07531d]" />
                      <span>{language === 'bn' ? 'পাসওয়ার্ড' : 'Password'}</span>
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      Min 6 chars
                    </span>
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-white border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 rounded-2xl pl-4 pr-11 py-3 text-xs sm:text-sm text-slate-900 placeholder-slate-400 transition shadow-2xs font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-700 cursor-pointer p-0.5"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Sign In Button: Requested "Sign In to Network" */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-[#065e1f] hover:bg-[#077326] text-yellow-300 font-army italic font-black py-3.5 px-5 rounded-2xl text-xs sm:text-sm shadow-md transition border border-emerald-700 flex items-center justify-center gap-2 mt-2 cursor-pointer active:scale-98 tracking-wider uppercase"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-yellow-300 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <LogIn className="w-4 h-4" />
                      <span>{language === 'bn' ? 'নেটওয়ার্কে প্রবেশ করুন' : 'Sign In to Network'}</span>
                    </>
                  )}
                </button>

                {/* Switch to Signup */}
                <div className="text-center pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMsg('');
                      setMode('signup');
                    }}
                    className="text-xs font-black font-army tracking-wider text-[#053712] hover:text-[#04280d] uppercase cursor-pointer"
                  >
                    NOT ENROLLED? JOIN THE NETWORK NOW
                  </button>
                </div>
              </form>
            ) : (
              /* SIGNUP FORM WITH "RI Rahat" placeholder, "Alumni" role */
              <form onSubmit={handleSignUpSubmit} className="space-y-3.5">
                {/* Full Name */}
                <div>
                  <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-[#07531d]" />
                    <span>{language === 'bn' ? 'পুরো নাম *' : 'Full Name *'}</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="RI Rahat"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-white border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 rounded-2xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 placeholder-slate-400 transition font-medium shadow-2xs"
                  />
                </div>

                {/* Email Address & Mobile Number */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1 flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-[#07531d]" />
                      <span>{language === 'bn' ? 'ইমেইল এড্রেস *' : 'Email Address *'}</span>
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. rahat@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-white border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 rounded-2xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 placeholder-slate-400 transition font-medium shadow-2xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#07531d]" />
                      <span>{language === 'bn' ? 'মোবাইল নম্বর *' : 'Mobile Number *'}</span>
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="+88017xxxxxxxx"
                      value={mobileNo}
                      onChange={(e) => setMobileNo(e.target.value)}
                      className="w-full bg-white border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 rounded-2xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 placeholder-slate-400 transition font-medium shadow-2xs"
                    />
                  </div>
                </div>

                {/* Password & Confirm Password */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1 flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-[#07531d]" />
                      <span>{language === 'bn' ? 'পাসওয়ার্ড তৈরি করুন *' : 'Create Password *'}</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showSignUpPassword ? 'text' : 'password'}
                        required
                        minLength={6}
                        placeholder="Min 6 characters"
                        value={signUpPassword}
                        onChange={(e) => setSignUpPassword(e.target.value)}
                        className="w-full bg-white border border-slate-300 focus:border-emerald-600 rounded-2xl pl-4 pr-9 py-2.5 text-xs sm:text-sm text-slate-900 transition font-medium shadow-2xs"
                      />
                      <button
                        type="button"
                        onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                        className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                      >
                        {showSignUpPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1 flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5 text-[#07531d]" />
                      <span>{language === 'bn' ? 'পাসওয়ার্ড নিশ্চিত করুন *' : 'Confirm Password *'}</span>
                    </label>
                    <input
                      type={showSignUpPassword ? 'text' : 'password'}
                      required
                      minLength={6}
                      placeholder="Repeat password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className={`w-full bg-white border rounded-2xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 transition font-medium shadow-2xs ${
                        confirmPassword && confirmPassword !== signUpPassword
                          ? 'border-rose-400 bg-rose-50'
                          : 'border-slate-300 focus:border-emerald-600'
                      }`}
                    />
                  </div>
                </div>

                {/* Upazila & Blood Group */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#07531d]" />
                      <span>{language === 'bn' ? 'উপজেলা *' : 'Upazila *'}</span>
                    </label>
                    <select
                      value={upazila}
                      onChange={(e) => setUpazila(e.target.value as UpazilaName)}
                      className="w-full bg-white border border-slate-300 focus:border-emerald-600 rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-900 font-semibold transition shadow-2xs"
                    >
                      {MYMENSINGH_UPAZILAS.map((upz) => (
                        <option key={upz} value={upz}>
                          {language === 'bn' ? UPAZILA_BENGALI_NAMES[upz] : upz}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] sm:text-xs font-army italic font-black tracking-wider uppercase text-slate-700 mb-1 flex items-center gap-1.5">
                      <Droplet className="w-3.5 h-3.5 text-rose-500" />
                      <span>{language === 'bn' ? 'রক্তের গ্রুপ *' : 'Blood Group *'}</span>
                    </label>
                    <select
                      value={bloodGroup}
                      onChange={(e) => {
                        const bg = e.target.value as BloodGroup;
                        setBloodGroup(bg);
                        setShowBloodDonorModal(true);
                      }}
                      className="w-full bg-white border border-slate-300 focus:border-emerald-600 rounded-2xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-900 font-bold transition shadow-2xs cursor-pointer"
                    >
                      {bloodGroupOptions.map((bg) => (
                        <option key={bg} value={bg}>
                          {bg}
                        </option>
                      ))}
                    </select>
                    {/* Blood Donor Status Pill & Manual Toggle */}
                    <button
                      type="button"
                      onClick={() => setShowBloodDonorModal(true)}
                      className={`mt-1.5 w-full flex items-center justify-between px-2.5 py-1 rounded-lg text-[10px] font-bold border transition cursor-pointer ${
                        isBloodDonor
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
                          : 'bg-slate-100 text-slate-600 border-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      <span className="flex items-center gap-1">
                        <Droplet className={`w-3 h-3 ${isBloodDonor ? 'fill-rose-500 text-rose-500' : 'text-slate-400'}`} />
                        <span>{isBloodDonor ? '🩸 ব্লাড ব্যাংকে তালিকাভুক্ত (Donor)' : '❌ ব্লাড ব্যাংকে অনিচ্ছুক'}</span>
                      </span>
                      <span className="text-[9px] underline text-slate-500">{language === 'bn' ? 'পরিবর্তন' : 'Change'}</span>
                    </button>
                  </div>
                </div>

                {/* Gender, DOB & Role (Includes Alumni option) */}
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] sm:text-[11px] font-army italic font-black uppercase text-slate-700 mb-1">
                      {language === 'bn' ? 'লিঙ্গ' : 'Gender'}
                    </label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value as Gender)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-2 py-2 text-xs text-slate-900 font-medium"
                    >
                      {genderOptions.map((g) => (
                        <option key={g} value={g}>
                          {g}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] sm:text-[11px] font-army italic font-black uppercase text-slate-700 mb-1">
                      {language === 'bn' ? 'জন্ম তারিখ' : 'Birth Date'}
                    </label>
                    <input
                      type="date"
                      value={dateOfBirth}
                      onChange={(e) => setDateOfBirth(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded-xl px-2 py-1.5 text-xs text-slate-900 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] sm:text-[11px] font-army italic font-black uppercase text-slate-700 mb-1">
                      {language === 'bn' ? 'পদবি' : 'Role'}
                    </label>
                    <select
                      value={
                        roleInVBD === 'Board Member'
                          ? boardType === 'District Board'
                            ? 'District Board Member'
                            : 'Upazila Board Member'
                          : roleInVBD
                      }
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val === 'District Board Member') {
                          setRoleInVBD('Board Member');
                          setBoardType('District Board');
                        } else if (val === 'Upazila Board Member') {
                          setRoleInVBD('Board Member');
                          setBoardType('Upazila Board');
                        } else if (val === 'Board Member') {
                          setRoleInVBD('Board Member');
                          if (!boardType) setBoardType('District Board');
                        } else {
                          setRoleInVBD(val as VBDRole);
                        }
                      }}
                      className="w-full bg-white border border-slate-300 rounded-xl px-2 py-2 text-xs text-slate-900 font-bold"
                    >
                      <option value="General Member">General Member</option>
                      <option value="Committee Member">Committee Member</option>
                      <option value="District Board Member">District Board Member</option>
                      <option value="Upazila Board Member">Upazila Board Member</option>
                      <option value="Alumni">Alumni</option>
                    </select>
                  </div>
                </div>

                {/* Board Member Specific Board Type (Upazila Board / District Board) */}
                {roleInVBD === 'Board Member' && (
                  <div className="space-y-1.5 animate-fadeIn">
                    <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                      Board Category:
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      {/* Option 1: Upazila Board */}
                      <button
                        type="button"
                        onClick={() => setBoardType('Upazila Board')}
                        className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition shadow-xs active:scale-[0.98] ${
                          boardType === 'Upazila Board'
                            ? 'bg-yellow-400 text-slate-950 border-yellow-500 ring-2 ring-yellow-400 font-black'
                            : 'bg-white hover:bg-yellow-50/70 text-slate-700 border-slate-200 font-bold'
                        }`}
                      >
                        <span className="text-xs uppercase font-army">
                          Upazila Board
                        </span>
                        {boardType === 'Upazila Board' && (
                          <CheckCircle2 className="w-4 h-4 text-slate-950 shrink-0" />
                        )}
                      </button>

                      {/* Option 2: District Board */}
                      <button
                        type="button"
                        onClick={() => setBoardType('District Board')}
                        className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition shadow-xs active:scale-[0.98] ${
                          boardType === 'District Board'
                            ? 'bg-[#053712] text-white border-emerald-600 ring-2 ring-emerald-500 font-black'
                            : 'bg-white hover:bg-emerald-50/70 text-slate-700 border-slate-200 font-bold'
                        }`}
                      >
                        <span className="text-xs uppercase font-army">
                          District Board
                        </span>
                        {boardType === 'District Board' && (
                          <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                        )}
                      </button>
                    </div>

                    <div className="bg-amber-50 border border-amber-300 rounded-2xl p-2.5 text-amber-900 text-xs space-y-0.5">
                      <div className="font-army font-black uppercase text-amber-950 flex items-center gap-1 text-[11px]">
                        <span>⚠️ {language === 'bn' ? 'অ্যাডমিন রিভিউ প্রয়োজন' : 'Admin Review Required'}</span>
                      </div>
                      <p className="text-[10px] leading-tight text-amber-900">
                        {language === 'bn'
                          ? 'বোর্ড মেম্বার পদবির জন্য জেলা অ্যাডমিনদের রিভিউ ও অনুমোদন প্রয়োজন হবে।'
                          : 'Selecting Board Member role requires District Admin Review & Approval before becoming active.'}
                      </p>
                    </div>
                  </div>
                )}

                {/* Complete Registration Button */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-[#053712] hover:bg-[#07471b] text-yellow-300 font-army italic font-black py-3.5 px-4 rounded-2xl text-xs sm:text-sm shadow-md transition border border-emerald-700 flex items-center justify-center gap-2 mt-3 cursor-pointer active:scale-98 tracking-wider uppercase"
                >
                  {isLoading ? (
                    <div className="w-4 h-4 border-2 border-yellow-300 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4" />
                      <span>{language === 'bn' ? 'রেজিস্ট্রেশন সম্পন্ন করে যুক্ত হন' : 'Complete Registration & Join'}</span>
                    </>
                  )}
                </button>

                {/* Return to Login */}
                <div className="text-center pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setErrorMsg('');
                      setMode('login');
                    }}
                    className="text-xs font-black font-army tracking-wider text-[#053712] hover:text-[#04280d] uppercase cursor-pointer"
                  >
                    ALREADY ACTIVATED? RETURN TO LOGIN
                  </button>
                </div>
              </form>
            )}

              {/* Board Member Type Selection Popup Modal */}
              {showBoardTypeModal && (
                <div
                  onClick={() => setShowBoardTypeModal(false)}
                  className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
                  style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
                >
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="w-full max-w-sm bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border border-slate-200 relative animate-fadeIn space-y-4 text-center"
                  >
                    <button
                      onClick={() => setShowBoardTypeModal(false)}
                      className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1.5 rounded-full hover:bg-slate-100 cursor-pointer transition"
                    >
                      <X className="w-5 h-5" />
                    </button>

                    <h3 className="text-base font-black text-slate-900 font-army uppercase">
                      Board Category:
                    </h3>

                    <div className="grid grid-cols-1 gap-2.5 pt-1 text-left">
                      {/* Option 1: Upazila Board */}
                      <button
                        type="button"
                        onClick={() => {
                          setBoardType('Upazila Board');
                          setShowBoardTypeModal(false);
                        }}
                        className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-center justify-between gap-3 shadow-xs ${
                          boardType === 'Upazila Board'
                            ? 'bg-yellow-400 text-slate-950 border-yellow-500 ring-2 ring-yellow-400 font-black'
                            : 'bg-white hover:bg-yellow-50 text-slate-800 border-slate-200 font-bold'
                        }`}
                      >
                        <span className="font-army text-sm uppercase">Upazila Board</span>
                        {boardType === 'Upazila Board' && (
                          <CheckCircle2 className="w-4 h-4 text-slate-950 shrink-0" />
                        )}
                      </button>

                      {/* Option 2: District Board */}
                      <button
                        type="button"
                        onClick={() => {
                          setBoardType('District Board');
                          setShowBoardTypeModal(false);
                        }}
                        className={`p-3.5 rounded-2xl border-2 transition cursor-pointer flex items-center justify-between gap-3 shadow-xs ${
                          boardType === 'District Board'
                            ? 'bg-[#053712] text-white border-emerald-600 ring-2 ring-emerald-500 font-black'
                            : 'bg-white hover:bg-emerald-50 text-slate-800 border-slate-200 font-bold'
                        }`}
                      >
                        <span className="font-army text-sm uppercase">District Board</span>
                        {boardType === 'District Board' && (
                          <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              )}
          </div>
        </div>
      </main>

      {/* Footer Section: Matching Attached Demo Images & User Specification */}
      <footer className="max-w-xl w-full mx-auto py-4 text-center space-y-3">
        {/* Powered By Pill Box */}
        <div className="bg-[#e4f3e7] border border-emerald-300/80 rounded-2xl p-3 text-center space-y-0.5 shadow-2xs">
          <p className="text-[9px] font-mono font-bold tracking-[0.2em] text-slate-500 uppercase">
            POWERED BY
          </p>
          <p className="text-xs font-army italic font-black text-slate-900 tracking-wider uppercase">
            VOLUNTEERS FOR BANGLADESH
          </p>
          <p className="text-[10px] font-bold text-emerald-800 uppercase tracking-widest">
            MYMENSINGH DISTRICT • EST - 2026
          </p>
        </div>

        {/* Developer Sign */}
        <div className="flex items-center justify-center gap-2">
          <div className="inline-flex items-center gap-1.5 bg-yellow-400 border border-yellow-500 text-slate-950 px-4 py-1.5 rounded-full text-xs font-army italic font-black uppercase tracking-widest shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5 fill-slate-950 text-yellow-400" />
            <span>DEVELOPED BY RI</span>
          </div>
        </div>
      </footer>
      {/* BLOOD DONOR CONSENT MODAL */}
      {showBloodDonorModal && (
        <div
          onClick={() => setShowBloodDonorModal(false)}
          className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm bg-white border-2 border-red-500 rounded-[32px] p-6 shadow-2xl text-center space-y-4 animate-scaleUp"
          >
            <div className="w-14 h-14 rounded-2xl bg-rose-100 text-red-600 flex items-center justify-center mx-auto shadow-sm border border-rose-200">
              <Droplet className="w-8 h-8 fill-red-600 text-red-600 animate-pulse" />
            </div>

            <div>
              <span className="text-[10px] font-army italic font-black uppercase text-rose-600 tracking-wider bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
                BLOOD GROUP {bloodGroup}
              </span>
              <h3 className="font-army italic font-black text-lg text-slate-900 uppercase mt-2">
                রক্তদান করতে ইচ্ছুক?
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                জরুরি প্রয়োজনে আপনি কি রক্তদান করতে ইচ্ছুক? সম্মতি দিলে আমাদের <strong>ব্লাড ব্যাংক</strong> ডিরেক্টরিতে আপনার তথ্য প্রদর্শিত হবে।
              </p>
            </div>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setIsBloodDonor(true);
                  setShowBloodDonorModal(false);
                }}
                className="w-full py-3 px-4 bg-[#053712] hover:bg-[#07471b] text-yellow-400 font-army italic font-black text-xs rounded-2xl shadow-md transition flex items-center justify-center gap-2 cursor-pointer border border-emerald-600 active:scale-98 uppercase"
              >
                <Check className="w-4 h-4 text-yellow-400" />
                <span>হ্যাঁ, আমি রক্তদান করতে চাই (Yes, I'm a Donor)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setIsBloodDonor(false);
                  setShowBloodDonorModal(false);
                }}
                className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-army italic font-bold text-xs rounded-2xl transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-98 uppercase"
              >
                <X className="w-3.5 h-3.5 text-slate-500" />
                <span>না, আপাতত ইচ্ছুক নই (No, Not Right Now)</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
