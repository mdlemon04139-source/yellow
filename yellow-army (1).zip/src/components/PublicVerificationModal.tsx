import React from 'react';
import { Volunteer, ProjectMeeting } from '../types';
import {
  ShieldCheck,
  Droplet,
  MapPin,
  Phone,
  Calendar,
  Award,
  CheckCircle2,
  X,
  Clock,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { getVolunteerUnifiedQrCodeImage } from '../utils/qrUtils';

interface PublicVerificationModalProps {
  volunteer: Volunteer;
  projects: ProjectMeeting[];
  onClose: () => void;
}

export const PublicVerificationModal: React.FC<PublicVerificationModalProps> = ({
  volunteer,
  projects,
  onClose,
}) => {
  // Find projects this volunteer joined or led
  const attendedProjects = projects.filter((p) =>
    p.registeredVolunteerIds?.includes(volunteer.id)
  );

  const getRoleBadgeClasses = (role?: string) => {
    if (role === 'Board Member') return 'bg-emerald-600 text-white border-emerald-500';
    if (role === 'Committee Member') return 'bg-yellow-400 text-slate-950 border-yellow-500 font-black';
    if (role === 'Alumni') return 'bg-black text-yellow-400 border-yellow-500/60';
    return 'bg-slate-700 text-white border-slate-600';
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[999] overflow-y-auto flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn"
      style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-white border-2 border-yellow-400 rounded-3xl sm:rounded-[36px] shadow-2xl overflow-hidden my-auto animate-fadeIn relative text-slate-900 max-h-[92vh] flex flex-col"
      >
        {/* Modal Top Header */}
        <div className="bg-[#07531d] px-5 py-3.5 sm:px-6 sm:py-4 flex items-center justify-between text-white border-b border-emerald-700 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-yellow-400 text-slate-950 flex items-center justify-center font-army font-black text-sm shadow-sm">
              YA
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-yellow-400" />
                <span className="font-army italic font-black text-xs sm:text-sm text-yellow-400 tracking-wider uppercase">
                  OFFICIAL VOLUNTEER VERIFICATION
                </span>
              </div>
              <p className="text-[10px] text-emerald-200 font-mono">
                YELLOW ARMY • MYMENSINGH DISTRICT COMMAND
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer transition"
            title="Close Verification"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {/* Identity Card with Photo, Name & Roles */}
          <div className="bg-gradient-to-br from-[#065018] to-[#043610] text-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 border-2 border-yellow-400 shadow-lg relative overflow-hidden">
            <div className="flex items-start gap-4">
              <img
                src={volunteer.avatarUrl}
                alt={volunteer.fullName}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-yellow-400 shadow-md shrink-0"
              />

              <div className="space-y-1 min-w-0 flex-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span
                    className={`text-[10px] font-army font-black px-2.5 py-0.5 rounded-full border shadow-2xs ${getRoleBadgeClasses(
                      volunteer.roleInVBD
                    )}`}
                  >
                    {volunteer.roleInVBD || 'GENERAL MEMBER'}
                  </span>
                  <span className="bg-white/20 text-white font-mono font-bold text-[10px] px-2 py-0.5 rounded-full">
                    {volunteer.volunteerIdCode || 'YA-MYM-001'}
                  </span>
                </div>

                <h3 className="font-army italic font-black text-lg sm:text-xl text-white uppercase leading-tight truncate">
                  {volunteer.fullName}
                </h3>

                <p className="text-xs text-emerald-200 font-medium flex items-center gap-1 truncate">
                  <MapPin className="w-3.5 h-3.5 text-yellow-400 shrink-0" />
                  <span>{volunteer.upazila || 'Mymensingh Sadar'} Sector</span>
                </p>

                <div className="flex items-center gap-2 pt-1 flex-wrap">
                  <span className="inline-flex items-center gap-1 bg-rose-600 text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-2xs">
                    <Droplet className="w-3 h-3 fill-white" />
                    <span>{volunteer.bloodGroup || 'Blood Donor'}</span>
                  </span>

                  {volunteer.mobileNo && (
                    <a
                      href={`tel:${volunteer.mobileNo}`}
                      className="inline-flex items-center gap-1 bg-emerald-700 hover:bg-emerald-600 text-yellow-300 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-500 shadow-xs transition"
                    >
                      <Phone className="w-3 h-3 fill-yellow-300" />
                      <span>{volunteer.mobileNo}</span>
                    </a>
                  )}
                </div>
              </div>
            </div>

            {/* Authenticated Banner */}
            <div className="mt-3.5 pt-3 border-t border-emerald-700/80 flex items-center justify-between text-[10px] font-mono text-emerald-200">
              <span className="flex items-center gap-1 text-yellow-300 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5 text-yellow-400" />
                AUTHENTICATED CREDENTIAL
              </span>
              <span>NO LOGIN REQUIRED</span>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-2 sm:gap-3 text-center">
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5 sm:p-3">
              <span className="text-[10px] font-bold text-slate-500 block uppercase">Missions</span>
              <span className="font-army font-black text-base sm:text-lg text-[#07531d]">
                {volunteer.projectsAttendedCount || attendedProjects.length || 0}
              </span>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5 sm:p-3">
              <span className="text-[10px] font-bold text-slate-500 block uppercase">Hours</span>
              <span className="font-army font-black text-base sm:text-lg text-slate-900">
                {volunteer.totalVolunteerHours || 30}+ hrs
              </span>
            </div>
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5 sm:p-3">
              <span className="text-[10px] font-bold text-slate-500 block uppercase">Status</span>
              <span className="font-army font-black text-base sm:text-lg text-emerald-700">
                ACTIVE
              </span>
            </div>
          </div>

          {/* Attended Operations & Field Work */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-army font-black text-xs uppercase tracking-wider text-slate-900 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#07531d]" />
                <span>FIELD MISSIONS & WORK RECORD ({attendedProjects.length})</span>
              </h4>
            </div>

            {attendedProjects.length === 0 ? (
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center text-xs text-slate-500">
                {volunteer.fullName} has participated in registered operational drills and district humanitarian initiatives.
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {attendedProjects.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 bg-slate-50 border border-slate-200 rounded-2xl flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span
                          className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${
                            p.type === 'Project'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {p.type}
                        </span>
                        <span className="text-[10px] text-slate-400">{p.startingTime?.split('T')[0] || '2026'}</span>
                      </div>
                      <h5 className="font-bold text-xs text-slate-900 truncate">{p.title}</h5>
                      <p className="text-[11px] text-slate-500 truncate">📍 {p.location}</p>
                    </div>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200 shrink-0">
                      Completed
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Verification QR Code Section */}
          <div className="bg-slate-900 text-white rounded-2xl p-3.5 flex items-center justify-between gap-3 border border-yellow-400/40">
            <div className="space-y-0.5 min-w-0">
              <span className="text-[9px] font-mono font-bold text-yellow-400 uppercase tracking-widest block">
                PERMANENT QR CODE
              </span>
              <p className="text-xs font-bold text-white truncate">{volunteer.fullName}</p>
              <p className="text-[10px] text-slate-400 font-mono">
                Code: {volunteer.volunteerIdCode || volunteer.id}
              </p>
              <p className="text-[10px] text-emerald-400 font-bold">Public Verification Link</p>
            </div>

            <div className="bg-white p-1.5 rounded-xl border border-yellow-400 shrink-0">
              <img
                src={getVolunteerUnifiedQrCodeImage(volunteer, 120)}
                alt="Unified QR Code"
                className="w-16 h-16 object-contain"
              />
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-500 font-medium">
            Yellow Army District Platform
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#07531d] hover:bg-[#096324] text-yellow-400 font-army font-black text-xs uppercase tracking-wider rounded-xl transition cursor-pointer shadow-sm"
          >
            Close & Go to App
          </button>
        </div>
      </div>
    </div>
  );
};
