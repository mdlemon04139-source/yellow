import React from 'react';
import { useApp } from '../context/AppContext';
import {
  Home,
  Calendar,
  Users,
  Radio,
  ShieldCheck,
  User,
} from 'lucide-react';
import { AppTab } from '../types';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, currentUser, isAdmin, pendingApprovalsCount } = useApp();

  const navItems: { id: AppTab; label: string; icon: any; pulse?: boolean }[] = [
    { id: 'home', label: 'HOME', icon: Home },
    { id: 'calendar', label: 'CALENDAR', icon: Calendar },
    { id: 'army', label: 'ARMY', icon: Users },
    { id: 'radio', label: 'RADIO', icon: Radio, pulse: true },
    { id: 'profile', label: 'PROFILE', icon: User },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#053712] border-t border-emerald-700/60 shadow-2xl py-1.5 px-1 sm:px-4">
      <div className="max-w-xl md:max-w-3xl mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-1.5 sm:px-3 rounded-2xl transition-all duration-200 relative cursor-pointer group ${
                isActive
                  ? 'text-yellow-400 font-black'
                  : 'text-emerald-100/70 hover:text-white font-bold'
              }`}
            >
              {/* Icon Container with active pill background */}
              <div
                className={`relative flex items-center justify-center p-1 rounded-full transition-all ${
                  isActive ? 'bg-[#07471b] shadow-xs' : 'group-hover:bg-emerald-800/40'
                }`}
              >
                <Icon
                  className={`w-4 h-4 sm:w-5 sm:h-5 ${
                    isActive ? 'text-yellow-400 stroke-[2.5]' : 'text-emerald-100/80 stroke-2'
                  }`}
                />
                {item.id === 'admin' && pendingApprovalsCount > 0 && (
                  <span
                    title={`${pendingApprovalsCount} pending approvals`}
                    className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-600 border border-white animate-pulse shadow-sm"
                  ></span>
                )}
                {item.pulse && (
                  <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                )}
              </div>

              {/* Label */}
              <span
                className={`text-[8px] sm:text-[9px] mt-0.5 tracking-wider uppercase leading-tight ${
                  isActive ? 'text-yellow-400 font-black italic' : 'text-emerald-100/70 font-bold'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
