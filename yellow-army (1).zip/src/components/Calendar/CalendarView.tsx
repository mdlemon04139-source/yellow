import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  MapPin,
  PlusCircle,
  Cake,
  Users,
} from 'lucide-react';
import { translations } from '../../utils/translations';

interface CalendarViewProps {
  onOpenLaunchModal: () => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ onOpenLaunchModal }) => {
  const { projects, volunteers, language, currentUser, isAdmin, setSelectedProjectModal } = useApp();
  const t = translations[language];

  // Restrict Event Initialization to Admin/Moderator/Board/Committee members
  const canManageEvents =
    isAdmin ||
    currentUser?.roleInVBD === 'Board Member' ||
    currentUser?.roleInVBD === 'Committee Member';

  // Current viewed month and year
  const [currentMonth, setCurrentMonth] = useState<Date>(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });

  // Selected date (defaults to today)
  const [selectedDate, setSelectedDate] = useState<Date>(() => new Date());

  // Month navigation helpers
  const handlePrevMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 1));
  };

  const handleToday = () => {
    const today = new Date();
    setCurrentMonth(new Date(today.getFullYear(), today.getMonth(), 1));
    setSelectedDate(today);
  };

  // Days of week
  const weekDays = useMemo(() => {
    if (language === 'bn') {
      return ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
    }
    return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  }, [language]);

  // Calendar Grid Calculation
  const calendarDays = useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();

    const firstDayIndex = new Date(year, month, 1).getDay();
    const totalDaysInMonth = new Date(year, month + 1, 0).getDate();
    const totalDaysInPrevMonth = new Date(year, month, 0).getDate();

    const days: {
      date: Date;
      isCurrentMonth: boolean;
      isToday: boolean;
      isSelected: boolean;
    }[] = [];

    const todayStr = new Date().toDateString();
    const selectedStr = selectedDate.toDateString();

    // Previous month padding days
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const d = new Date(year, month - 1, totalDaysInPrevMonth - i);
      days.push({
        date: d,
        isCurrentMonth: false,
        isToday: d.toDateString() === todayStr,
        isSelected: d.toDateString() === selectedStr,
      });
    }

    // Current month days
    for (let day = 1; day <= totalDaysInMonth; day++) {
      const d = new Date(year, month, day);
      days.push({
        date: d,
        isCurrentMonth: true,
        isToday: d.toDateString() === todayStr,
        isSelected: d.toDateString() === selectedStr,
      });
    }

    // Next month padding days to complete grid cells
    const remaining = (7 - (days.length % 7)) % 7;
    for (let i = 1; i <= remaining; i++) {
      const d = new Date(year, month + 1, i);
      days.push({
        date: d,
        isCurrentMonth: false,
        isToday: d.toDateString() === todayStr,
        isSelected: d.toDateString() === selectedStr,
      });
    }

    return days;
  }, [currentMonth, selectedDate]);

  // Helper to get events for any date
  const getEventsForDate = (date: Date) => {
    const dMonth = date.getMonth();
    const dDate = date.getDate();
    const dYear = date.getFullYear();

    // 1. Projects on this date
    const dateProjects = projects.filter((p) => {
      if (p.type !== 'Project') return false;
      const pDate = new Date(p.startingTime);
      return (
        pDate.getFullYear() === dYear &&
        pDate.getMonth() === dMonth &&
        pDate.getDate() === dDate
      );
    });

    // 2. Meetings on this date
    const dateMeetings = projects.filter((p) => {
      if (p.type !== 'Meeting') return false;
      const pDate = new Date(p.startingTime);
      return (
        pDate.getFullYear() === dYear &&
        pDate.getMonth() === dMonth &&
        pDate.getDate() === dDate
      );
    });

    // 3. Birthdays on this date (month & day match, year independent)
    const dateBirthdays = volunteers.filter((vol) => {
      if (!vol.dateOfBirth) return false;
      const bDate = new Date(vol.dateOfBirth);
      return bDate.getMonth() === dMonth && bDate.getDate() === dDate;
    });

    return {
      projects: dateProjects,
      meetings: dateMeetings,
      birthdays: dateBirthdays,
      totalCount: dateProjects.length + dateMeetings.length + dateBirthdays.length,
    };
  };

  // Events on the currently selected date
  const selectedDateEvents = useMemo(() => {
    return getEventsForDate(selectedDate);
  }, [selectedDate, projects, volunteers]);

  // Formatted header string
  const monthNamesEn = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];
  const monthNamesBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর',
  ];

  const currentMonthName = language === 'bn'
    ? `${monthNamesBn[currentMonth.getMonth()]} ${currentMonth.getFullYear()}`
    : `${monthNamesEn[currentMonth.getMonth()]} ${currentMonth.getFullYear()}`;

  const selectedDateFormatted = selectedDate.toLocaleDateString(
    language === 'bn' ? 'bn-BD' : 'en-US',
    { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }
  );

  return (
    <div className="max-w-2xl mx-auto space-y-3.5 animate-fadeIn">
      {/* Calendar Section: Compact Layout & Large Date Boxes */}
      <div className="bg-white border border-slate-200 rounded-3xl p-3.5 sm:p-5 shadow-xs space-y-3">
        {/* Month Navigation Toolbar with + Schedule Event Button */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 pb-2.5 border-b border-slate-100">
          <div className="flex items-center gap-1.5">
            <button
              onClick={handlePrevMonth}
              className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
              title="Previous Month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <h3 className="font-army font-black text-base sm:text-lg text-slate-900 min-w-[140px] text-center uppercase tracking-wide">
              {currentMonthName}
            </h3>
            <button
              onClick={handleNextMonth}
              className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
              title="Next Month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={handleToday}
              className="ml-1 px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-bold transition cursor-pointer border border-slate-200"
            >
              {language === 'bn' ? 'আজ' : 'Today'}
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Color Dots Legend */}
            <div className="hidden sm:flex items-center gap-3 text-[11px] font-bold bg-slate-50 px-2.5 py-1 rounded-xl border border-slate-200">
              <span className="flex items-center gap-1 text-slate-700">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-2xs"></span>
                <span>Project</span>
              </span>
              <span className="flex items-center gap-1 text-slate-700">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow-2xs"></span>
                <span>Meeting</span>
              </span>
              <span className="flex items-center gap-1 text-slate-700">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-2xs"></span>
                <span>Birthday</span>
              </span>
            </div>

            {canManageEvents && (
              <button
                onClick={onOpenLaunchModal}
                className="bg-[#07531d] hover:bg-[#0a6625] text-yellow-400 font-army font-black px-3 py-1.5 rounded-xl text-xs shadow-2xs transition flex items-center gap-1.5 border border-emerald-700 cursor-pointer uppercase tracking-wider"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? '+ ইভেন্ট' : '+ EVENT'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Legend */}
        <div className="flex sm:hidden items-center justify-around text-[10px] font-bold bg-slate-50 py-1 px-2 rounded-xl border border-slate-200">
          <span className="flex items-center gap-1 text-slate-700">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Project</span>
          </span>
          <span className="flex items-center gap-1 text-slate-700">
            <span className="w-2 h-2 rounded-full bg-blue-500"></span>
            <span>Meeting</span>
          </span>
          <span className="flex items-center gap-1 text-slate-700">
            <span className="w-2 h-2 rounded-full bg-rose-500"></span>
            <span>Birthday</span>
          </span>
        </div>

        {/* Calendar Grid: Large Date Boxes with Color Dots (1:1 aspect ratio on mobile) */}
        <div className="grid grid-cols-7 gap-1 sm:gap-2">
          {/* Day Names Header - Only Friday (idx === 5) is red */}
          {weekDays.map((dayName, idx) => (
            <div
              key={idx}
              className={`py-1 text-center text-[10px] sm:text-[11px] font-army font-black uppercase tracking-wider ${
                idx === 5 ? 'text-rose-600' : 'text-slate-500'
              }`}
            >
              {dayName}
            </div>
          ))}

          {/* Date Cells */}
          {calendarDays.map((dayItem, idx) => {
            const dateNumber = dayItem.date.getDate();
            const { projects: pList, meetings: mList, birthdays: bList, totalCount } = getEventsForDate(dayItem.date);

            // Determine tinted background if events exist
            const hasProject = pList.length > 0;
            const hasMeeting = mList.length > 0;
            const hasBirthday = bList.length > 0;

            let eventBgClass = 'bg-slate-50/70 hover:bg-slate-100 border-slate-200';
            if (dayItem.isCurrentMonth && totalCount > 0) {
              if (hasProject && !hasMeeting && !hasBirthday) {
                eventBgClass = 'bg-emerald-50/80 border-emerald-300 hover:bg-emerald-100/70';
              } else if (hasMeeting && !hasProject && !hasBirthday) {
                eventBgClass = 'bg-blue-50/80 border-blue-300 hover:bg-blue-100/70';
              } else if (hasBirthday && !hasProject && !hasMeeting) {
                eventBgClass = 'bg-rose-50/80 border-rose-300 hover:bg-rose-100/70';
              } else {
                eventBgClass = 'bg-amber-50/80 border-amber-300 hover:bg-amber-100/70';
              }
            }

            return (
              <button
                key={idx}
                type="button"
                onClick={() => setSelectedDate(dayItem.date)}
                className={`aspect-square sm:aspect-auto min-h-0 sm:min-h-[96px] p-1 sm:p-2.5 rounded-xl sm:rounded-2xl flex flex-col justify-between text-left transition relative cursor-pointer group border ${
                  dayItem.isSelected
                    ? 'bg-[#07531d] text-white shadow-md ring-2 ring-yellow-400 border-transparent'
                    : dayItem.isToday
                    ? 'bg-yellow-50 border-2 border-yellow-400 text-slate-900'
                    : dayItem.isCurrentMonth
                    ? eventBgClass + ' text-slate-800'
                    : 'bg-transparent text-slate-300 border-transparent hover:bg-slate-50/40'
                }`}
              >
                {/* Date Number Header with TODAY badge placed below date */}
                <div className="w-full flex flex-col items-center sm:items-start leading-tight">
                  <span
                    className={`text-xs sm:text-base font-black font-army leading-none ${
                      dayItem.isSelected
                        ? 'text-yellow-400'
                        : dayItem.isToday
                        ? 'text-[#07531d]'
                        : dayItem.date.getDay() === 5 && dayItem.isCurrentMonth
                        ? 'text-rose-600'
                        : dayItem.isCurrentMonth
                        ? 'text-slate-900'
                        : 'text-slate-300'
                    }`}
                  >
                    {dateNumber}
                  </span>

                  {dayItem.isToday && (
                    <span
                      className={`text-[7px] sm:text-[8px] font-black uppercase px-1 py-0.5 mt-0.5 rounded tracking-wider leading-none shadow-2xs ${
                        dayItem.isSelected ? 'bg-yellow-400 text-slate-950' : 'bg-[#07531d] text-yellow-400'
                      }`}
                    >
                      {language === 'bn' ? 'আজ' : 'TODAY'}
                    </span>
                  )}
                </div>

                {/* Event Category Color Dots */}
                <div className="w-full flex flex-wrap items-center justify-center gap-1 my-auto py-0.5">
                  {/* Field Projects: Green Dot */}
                  {pList.length > 0 && (
                    <span
                      className="w-1.5 h-1.5 sm:w-2.5 sm:h-2.5 rounded-full bg-emerald-500 shadow-xs ring-1 ring-white"
                      title={`${pList.length} Field Project(s)`}
                    />
                  )}

                  {/* Meetings: Blue Dot */}
                  {mList.length > 0 && (
                    <span
                      className="w-1.5 h-1.5 sm:w-2.5 sm:h-2.5 rounded-full bg-blue-500 shadow-xs ring-1 ring-white"
                      title={`${mList.length} Meeting(s)`}
                    />
                  )}

                  {/* Birthdays: Rose Dot */}
                  {bList.length > 0 && (
                    <span
                      className="w-1.5 h-1.5 sm:w-2.5 sm:h-2.5 rounded-full bg-rose-500 shadow-xs ring-1 ring-white"
                      title={`🎂 ${bList.length} Birthday(s)`}
                    />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Date Details Panel: Compact, Clean Schedule Card */}
      <div className="bg-white border border-slate-200 rounded-3xl p-3.5 sm:p-4 shadow-xs space-y-2.5 animate-fadeIn">
        {/* Header of selected date */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
              {language === 'bn' ? 'নির্বাচিত তারিখ' : 'SCHEDULE FOR SELECTED DATE'}
            </span>
            <h4 className="text-xs sm:text-sm font-black text-slate-900">
              {selectedDateFormatted}
            </h4>
          </div>
          <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full">
            {selectedDateEvents.totalCount} {selectedDateEvents.totalCount === 1 ? 'Item' : 'Items'}
          </span>
        </div>

        {selectedDateEvents.totalCount === 0 ? (
          <div className="py-4 text-center text-xs text-slate-500 font-medium">
            {language === 'bn' ? 'এই তারিখে কোনো ইভেন্ট নির্ধারিত নেই।' : 'No events scheduled for this date.'}
          </div>
        ) : (
          /* Compact Event Items */
          <div className="space-y-2">
            {/* 1. Projects on this date */}
            {selectedDateEvents.projects.map((proj) => {
              const startDate = new Date(proj.startingTime);
              return (
                <div
                  key={proj.id}
                  onClick={() => setSelectedProjectModal(proj)}
                  className="bg-emerald-50/70 hover:bg-emerald-100/70 border border-emerald-200 rounded-2xl p-2.5 flex items-center justify-between gap-3 text-xs cursor-pointer transition shadow-2xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black text-xs shrink-0">
                      🚀
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] font-black uppercase text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded">
                          Project
                        </span>
                        <span className="text-[10px] text-slate-500 font-medium">
                          {proj.upazilaScope}
                        </span>
                      </div>
                      <h5 className="font-bold text-slate-900 truncate text-xs mt-0.5">
                        {proj.title}
                      </h5>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 text-[11px] text-slate-600">
                    <span className="flex items-center gap-1 font-mono font-medium">
                      <Clock className="w-3 h-3 text-emerald-600" />
                      {startDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <span className="text-[10px] font-semibold text-emerald-900 bg-white border border-emerald-200 px-2 py-0.5 rounded-lg hidden sm:inline-block">
                      Leader: {proj.leader.name}
                    </span>
                  </div>
                </div>
              );
            })}

            {/* 2. Meetings on this date */}
            {selectedDateEvents.meetings.map((meet) => {
              const startDate = new Date(meet.startingTime);
              return (
                <div
                  key={meet.id}
                  onClick={() => setSelectedProjectModal(meet)}
                  className="bg-blue-50/70 hover:bg-blue-100/70 border border-blue-200 rounded-2xl p-2.5 flex items-center justify-between gap-3 text-xs cursor-pointer transition shadow-2xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-7 h-7 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-xs shrink-0">
                      📅
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[9px] font-black uppercase text-blue-800 bg-blue-100 px-1.5 py-0.5 rounded">
                          Meeting
                        </span>
                        <span className="text-[10px] text-slate-500 font-medium">
                          {meet.upazilaScope}
                        </span>
                      </div>
                      <h5 className="font-bold text-slate-900 truncate text-xs mt-0.5">
                        {meet.title}
                      </h5>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 text-[11px] text-slate-600">
                    <span className="flex items-center gap-1 font-mono font-medium">
                      <Clock className="w-3 h-3 text-blue-600" />
                      {startDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <span className="text-[10px] font-semibold text-blue-900 bg-white border border-blue-200 px-2 py-0.5 rounded-lg hidden sm:inline-block">
                      Host: {meet.leader.name}
                    </span>
                  </div>
                </div>
              );
            })}

            {/* 3. Birthdays on this date */}
            {selectedDateEvents.birthdays.map((vol) => (
              <div
                key={vol.id}
                className="bg-rose-50/70 border border-rose-200 rounded-2xl p-2.5 flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="relative shrink-0">
                    <img
                      src={vol.avatarUrl}
                      alt={vol.fullName}
                      className="w-8 h-8 rounded-full object-cover border border-rose-300"
                    />
                    <span className="absolute -bottom-1 -right-1 text-[10px]">🎂</span>
                  </div>
                  <div className="min-w-0">
                    <span className="text-[9px] font-black uppercase text-rose-800 bg-rose-100 px-1.5 py-0.5 rounded">
                      Birthday 🎂
                    </span>
                    <h5 className="font-bold text-slate-900 truncate text-xs mt-0.5">
                      {vol.fullName}
                    </h5>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 text-[11px]">
                  <span className="text-slate-500">{vol.upazila}</span>
                  <span className="text-rose-700 bg-white border border-rose-200 px-2 py-0.5 rounded-lg font-bold flex items-center gap-1">
                    <Cake className="w-3 h-3 text-rose-500" />
                    <span>Salute</span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
