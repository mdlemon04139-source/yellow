import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Zap,
  User,
  LogOut,
  ShieldCheck,
  LogIn,
  RefreshCw,
} from 'lucide-react';
import { translations } from '../utils/translations';

interface NavbarProps {
  onOpenLaunchModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenLaunchModal }) => {
  const {
    currentUser,
    activeTab,
    setActiveTab,
    pendingApprovalsCount,
    openAuthModal,
    logout,
    language,
    isFirebaseSynced,
    isAdmin,
    refreshData,
    isRefreshing,
  } = useApp();

  const t = translations[language];
  const [showUserMenu, setShowUserMenu] = useState(false);

  // Dynamic header title matching the screenshots
  const getTabHeaderTitle = () => {
    switch (activeTab) {
      case 'home':
        return 'HOME';
      case 'calendar':
        return 'CALENDAR SCHEDULE';
      case 'army':
        return 'ARMY FORCES';
      case 'radio':
        return 'RADIO HQ';
      case 'admin':
        return 'ADMIN HQ';
      case 'profile':
        return 'VOLUNTEER PROFILE';
      default:
        return 'PROJECT CENTER';
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-[#053712] border-b-2 border-yellow-400 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          
          {/* Left Brand Badge & Center Tab Title */}
          <div className="flex items-center gap-3 sm:gap-4 min-w-0">
            {/* Left Brand Badge with Zap */}
            <button
              onClick={() => setActiveTab('home')}
              className="flex items-center gap-2 text-left shrink-0 group focus:outline-none cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#07471b] border border-emerald-400/40 flex items-center justify-center text-yellow-400 shadow-xs group-hover:scale-105 transition-transform">
                <Zap className="w-5 h-5 fill-yellow-400" />
              </div>
              <div className="flex flex-col">
                <span className="font-black italic uppercase tracking-widest text-yellow-400 text-xs sm:text-sm leading-none">
                  YELLOW
                </span>
                <span className="mt-0.5 bg-[#021d07] text-emerald-300 font-black text-[9px] px-1.5 py-0.5 rounded tracking-wider uppercase inline-block w-fit">
                  NETWORK
                </span>
              </div>
            </button>

            {/* Vertical Divider */}
            <div className="h-7 w-[1px] bg-emerald-600/60 hidden sm:block"></div>

            {/* Center Dynamic Title */}
            <div className="flex flex-col min-w-0">
              <h1 className="font-black italic uppercase tracking-wider text-yellow-400 text-sm sm:text-base truncate leading-none">
                {getTabHeaderTitle()}
              </h1>
              <span className="text-[9px] sm:text-[10px] font-bold italic tracking-widest text-emerald-200/80 uppercase mt-0.5 truncate">
                PULSE OF PURPOSE
              </span>
            </div>
          </div>

          {/* Right Action Icons & Profile */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Sync Indicator */}
            {isFirebaseSynced && (
              <span className="hidden md:inline-flex items-center gap-1 bg-[#053d15] text-emerald-300 text-[10px] font-black italic uppercase px-2.5 py-1 rounded-full border border-emerald-600/40">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                SYNCED
              </span>
            )}

            {/* Manual Cloud Refresh Button */}
            <button
              onClick={refreshData}
              disabled={isRefreshing}
              title={isRefreshing ? 'Refreshing data from cloud...' : 'Refresh cloud data'}
              className={`p-2 sm:p-2.5 rounded-full ${
                isRefreshing
                  ? 'bg-[#043312] border-yellow-400 text-yellow-300'
                  : 'bg-[#0c6b29] hover:bg-[#107e32] border-emerald-500/40 text-yellow-400'
              } border transition cursor-pointer active:scale-95 shadow-xs flex items-center justify-center disabled:opacity-75`}
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-yellow-300' : ''}`} />
            </button>

            {/* Admin Section Quick Access with Red Dot Alert */}
            {isAdmin && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`relative p-2 sm:p-2.5 rounded-full ${
                  activeTab === 'admin' ? 'bg-[#043312] border-yellow-400' : 'bg-[#0c6b29] hover:bg-[#107e32] border-emerald-500/40'
                } text-yellow-400 border transition cursor-pointer active:scale-95 shadow-xs flex items-center justify-center`}
                title="Admin HQ"
              >
                <ShieldCheck className="w-4 h-4" />
                {pendingApprovalsCount > 0 && (
                  <span
                    title={`${pendingApprovalsCount} pending approval(s)`}
                    className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-600 border-2 border-[#07531d] animate-pulse shadow-xs"
                  ></span>
                )}
              </button>
            )}

            {/* User Profile Avatar & Menu */}
            <div className="relative">
              {currentUser ? (
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center gap-1.5 p-0.5 rounded-full bg-[#0c6b29] hover:bg-[#107e32] border-2 border-yellow-400 transition cursor-pointer active:scale-95 shadow-xs"
                >
                  <img
                    src={currentUser.avatarUrl}
                    alt={currentUser.fullName}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                </button>
              ) : (
                <button
                  onClick={() => openAuthModal('login')}
                  className="bg-yellow-400 hover:bg-yellow-300 text-slate-900 font-army italic font-black text-xs px-3 py-1.5 rounded-full shadow-xs flex items-center gap-1 uppercase transition cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>LOGIN</span>
                </button>
              )}

              {/* Backdrop */}
              {showUserMenu && (
                <div
                  className="fixed inset-0 z-40 bg-transparent"
                  onClick={() => setShowUserMenu(false)}
                />
              )}

              {/* User Dropdown */}
              {showUserMenu && currentUser && (
                <div className="absolute right-0 mt-2 w-56 bg-white border border-slate-200 rounded-2xl shadow-xl p-2 z-50 animate-fadeIn text-slate-800">
                  <div className="p-2 border-b border-slate-100 mb-1">
                    <p className="font-army italic font-black text-xs text-slate-900 uppercase truncate">
                      {currentUser.fullName}
                    </p>
                    <p className="text-[10px] text-slate-500 truncate">{currentUser.email || currentUser.volunteerIdCode}</p>
                    <span className="inline-block mt-1 bg-emerald-50 text-emerald-800 text-[9px] font-bold px-1.5 py-0.5 rounded border border-emerald-200 uppercase">
                      {currentUser.roleInVBD || 'Volunteer'}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      setActiveTab('profile');
                      setShowUserMenu(false);
                    }}
                    className="w-full flex items-center gap-2 p-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 transition cursor-pointer text-left"
                  >
                    <User className="w-3.5 h-3.5 text-emerald-600" />
                    <span>View Profile</span>
                  </button>

                  <button
                    onClick={() => {
                      logout();
                      setShowUserMenu(false);
                    }}
                    className="w-full flex items-center gap-2 p-2 rounded-xl text-xs font-semibold text-rose-600 hover:bg-rose-50 transition cursor-pointer text-left"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Log Out</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
