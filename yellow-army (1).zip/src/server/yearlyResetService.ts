import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  collection,
  getDocs,
  getFirestore,
  writeBatch,
  doc,
  setDoc,
  query,
  limit,
  startAfter,
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBT-XGEmMCVcyvXNPOnH1yPjMGVPE_FbIc",
  authDomain: "gen-lang-client-0873869765.firebaseapp.com",
  projectId: "gen-lang-client-0873869765",
  storageBucket: "gen-lang-client-0873869765.firebasestorage.app",
  messagingSenderId: "489181722279",
  appId: "1:489181722279:web:94e63847be0551a3e18d82",
};

const FIRESTORE_DB_ID = "ai-studio-yellowarmy-552658e2-543a-44b0-85b3-f73ed9c2607d";

function getServerDb() {
  const appInstance = !getApps().length ? initializeApp(firebaseConfig) : getApp();
  return getFirestore(appInstance, FIRESTORE_DB_ID);
}

/**
 * YEARLY ORGANIZATIONAL RESET SERVICE
 *
 * Requirements:
 * 1. Automatically starts a fresh operational year every January 1 (Asia/Dhaka timezone).
 * 2. Permanently removes previous year operational data (projects, meetings, activities, notifications, broadcasts, assessments).
 * 3. EXPLICITLY PROTECTS volunteer accounts and user profiles (users/{uid}, volunteers/{id}) from EVER being deleted.
 * 4. Completely idempotent: safe to run multiple times without affecting current year operational data.
 * 5. Handles large numbers of documents safely in cursor-paginated batches until all previous year records are deleted.
 * 6. Logs all reset operations to Firestore in systemAuditLogs.
 */

// EXPLICIT IMMUTABLE SAFETY BLACKLIST - MUST NEVER BE DELETED BY YEARLY RESET
export const PROTECTED_PERMANENT_COLLECTIONS = Object.freeze([
  'users',
  'volunteers',
  'systemAuditLogs',
]);

// OPERATIONAL YEAR-SPECIFIC COLLECTIONS SUBJECT TO ANNUAL RESET
export const OPERATIONAL_COLLECTIONS = Object.freeze([
  'projects',
  'activityLogs',
  'notifications',
  'radioBroadcasts',
  'radioComments',
  'needAssessments',
]);

export interface YearlyResetResult {
  success: boolean;
  clearedYear: number;
  currentYear: number;
  deletedCounts: Record<string, number>;
  totalDeleted: number;
  executionTimestamp: string;
  error?: string;
}

/**
 * Gets current date & time in Asia/Dhaka timezone
 */
export function getDhakaDateTime(): { year: number; month: number; day: number; dateStr: string; fullDate: Date } {
  const now = new Date();
  const dhakaStr = now.toLocaleString('en-US', { timeZone: 'Asia/Dhaka' });
  const dhakaDate = new Date(dhakaStr);
  return {
    year: dhakaDate.getFullYear(),
    month: dhakaDate.getMonth() + 1, // 1-indexed (1 = January)
    day: dhakaDate.getDate(),
    dateStr: dhakaStr,
    fullDate: dhakaDate,
  };
}

/**
 * Checks if a document belongs to a previous operational year
 */
export function isDocumentFromPreviousYear(data: any, currentYear: number): boolean {
  // 1. Explicit operationalYear field
  if (typeof data.operationalYear === 'number') {
    return data.operationalYear < currentYear;
  }

  // 2. Date fields: createdAt, startingTime, timestamp, closingTime
  const dateCandidates = [
    data.createdAt,
    data.startingTime,
    data.timestamp,
    data.closingTime,
  ];

  for (const dateVal of dateCandidates) {
    if (!dateVal) continue;
    try {
      const parsedDate = new Date(dateVal);
      if (!isNaN(parsedDate.getTime())) {
        const docYear = parsedDate.getFullYear();
        if (docYear > 1990 && docYear < currentYear) {
          return true;
        }
        if (docYear >= currentYear) {
          return false;
        }
      }
    } catch {}
  }

  return false;
}

// Concurrency lock to prevent duplicate concurrent reset executions
let isResetInProgress = false;

/**
 * Executes server-side yearly operational data purge in cursor-paginated batches
 */
export async function executeYearlyOperationalReset(
  targetYearToClear?: number
): Promise<YearlyResetResult> {
  if (isResetInProgress) {
    throw new Error('Yearly operational reset is already in progress. Please wait.');
  }

  isResetInProgress = true;
  const dhaka = getDhakaDateTime();
  const currentYear = dhaka.year;
  const previousYear = targetYearToClear || currentYear - 1;

  console.log(`[Yearly Reset] Starting organizational purge for year: ${previousYear} (Current Dhaka Year: ${currentYear})`);

  const deletedCounts: Record<string, number> = {};
  let totalDeleted = 0;
  const db = getServerDb();

  try {
    for (const colName of OPERATIONAL_COLLECTIONS) {
      // Extra safety check against accidental permanent collection deletion
      if (PROTECTED_PERMANENT_COLLECTIONS.includes(colName)) {
        console.warn(`[Yearly Reset Security] BLOCKED attempt to delete protected collection: ${colName}`);
        continue;
      }

      deletedCounts[colName] = 0;
      let hasMore = true;
      let lastVisibleDoc: any = null;

      // Cursor-based pagination loop: safely walks through all documents in the collection
      while (hasMore) {
        const colRef = collection(db, colName);
        const q = lastVisibleDoc
          ? query(colRef, startAfter(lastVisibleDoc), limit(250))
          : query(colRef, limit(250));

        const snapshot = await getDocs(q);

        if (snapshot.empty) {
          hasMore = false;
          break;
        }

        lastVisibleDoc = snapshot.docs[snapshot.docs.length - 1];

        const batch = writeBatch(db);
        let batchCount = 0;

        snapshot.forEach((docSnap) => {
          const docData = docSnap.data();
          if (isDocumentFromPreviousYear(docData, currentYear)) {
            batch.delete(doc(db, colName, docSnap.id));
            batchCount++;
          }
        });

        if (batchCount > 0) {
          await batch.commit();
          deletedCounts[colName] += batchCount;
          totalDeleted += batchCount;
          console.log(`[Yearly Reset] Deleted ${batchCount} old documents from ${colName}`);
        }

        // If fewer documents than limit were returned, we have reached the end of the collection
        if (snapshot.size < 250) {
          hasMore = false;
        }
      }
    }

    const result: YearlyResetResult = {
      success: true,
      clearedYear: previousYear,
      currentYear,
      deletedCounts,
      totalDeleted,
      executionTimestamp: new Date().toISOString(),
    };

    // Log the reset result in Firestore system audit collection
    try {
      const auditId = `reset-${previousYear}-${Date.now()}`;
      await setDoc(doc(db, 'systemAuditLogs', auditId), {
        ...result,
        action: 'YEARLY_OPERATIONAL_RESET',
        timezone: 'Asia/Dhaka',
        executedAtDhaka: dhaka.dateStr,
      });
      console.log(`[Yearly Reset] Audit record created: ${auditId}`);
    } catch (auditErr) {
      console.warn('[Yearly Reset] Failed to write audit record:', auditErr);
    }

    return result;
  } catch (err: any) {
    console.error('[Yearly Reset Error] Failure during operational reset:', err);
    return {
      success: false,
      clearedYear: previousYear,
      currentYear,
      deletedCounts,
      totalDeleted,
      executionTimestamp: new Date().toISOString(),
      error: err?.message || 'Unknown error during yearly reset',
    };
  } finally {
    isResetInProgress = false;
  }
}
